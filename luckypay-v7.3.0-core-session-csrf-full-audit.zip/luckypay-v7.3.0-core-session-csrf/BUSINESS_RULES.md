# Luckypay V6 Business Rules

1. All wallet mutations use `wallet-service.js`.
2. Deposit methods are validated against current administrator settings.
3. Administrator authentication is owned by AuthManager and server auth-session-service.
4. Automatic refresh only loads the active page.
5. Dirty forms are never overwritten by automatic refresh; saving clears dirty state.
6. Historical version names, paths and reports are prohibited in the release package.
