# Security Notes

- Change both administrator passwords before first start.
- Use a random `SESSION_SECRET` of at least 32 characters.
- Configure `ALLOWED_ORIGINS` to the exact user-facing origin.
- Set `COOKIE_SECURE=true` only when HTTPS is active.
- Do not expose the API container port publicly.
- Keep `data`, `uploads`, and `.env` outside source-control backups.
- Enable Google Authenticator for administrator accounts.
- Review `audit_logs` after administrator or financial changes.
- Run the supplied audit and integration tests after every deployment.
