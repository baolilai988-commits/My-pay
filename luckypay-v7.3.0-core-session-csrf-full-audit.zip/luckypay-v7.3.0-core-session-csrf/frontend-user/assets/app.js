"use strict";
let me=null,language='en',receiving=false,refreshing=false,currentLucky=null,activeLuckyModal=null,luckyModalDismissed=new Set(),walletSettings={usdt:{},inr:{specialists:[]}},previousLuckyState={},previousOrderState={},memberStateStore={version:null,generatedAt:null,snapshot:null},settings={min_withdraw_amount:0,withdraw_fee_percent:0,withdraw_enabled:true,principal_withdraw_enabled:true,commission_withdraw_enabled:true,registration:{enabled:true,display_name:{show:true,required:true},phone:{show:true,required:true},email:{show:true,required:false},referral:{show:true,required:false}}};
const $=id=>document.getElementById(id);
const escapeHtml=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
const T={en:{home:'Home',orders:'Orders',wallet:'Wallet',bonus:'Bonus',profile:'Profile',deposit:'Deposit',withdraw:'Withdraw',available:'Available Principal',todayOrders:"Today's Orders",todayCommission:"Today's Commission",receiving:'Receiving',recentOrders:'Recent Orders',start:'Start',stop:'Stop'},hi:{home:'होम',orders:'ऑर्डर',wallet:'वॉलेट',bonus:'बोनस',profile:'प्रोफ़ाइल',deposit:'जमा करें',withdraw:'निकासी',available:'उपलब्ध मूलधन',todayOrders:'आज के ऑर्डर',todayCommission:'आज का कमीशन',receiving:'ऑर्डर प्राप्ति',recentOrders:'हाल के ऑर्डर',start:'शुरू करें',stop:'रोकें'},zh:{home:'首页',orders:'订单',wallet:'钱包',bonus:'奖励',profile:'我的',deposit:'充值',withdraw:'提款',available:'可用本金',todayOrders:'今日订单',todayCommission:'今日佣金',receiving:'接单状态',recentOrders:'最近订单',start:'开启',stop:'关闭'}};
function setText(id,v){const e=$(id);if(e)e.textContent=v}function toast(t){const e=$('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2600)}
let csrfToken='',csrfPromise=null;
async function ensureCsrf(force=false){
 if(force){csrfToken='';csrfPromise=null}
 if(csrfToken)return csrfToken;
 if(csrfPromise)return csrfPromise;
 csrfPromise=(async()=>{
  const r=await fetch('/api/csrf',{credentials:'same-origin',cache:'no-store'});
  const j=await r.json().catch(()=>({}));
  if(!r.ok||!j.csrf_token)throw Error(j.error||'Unable to initialize security token');
  csrfToken=j.csrf_token;
  return csrfToken
 })();
 try{return await csrfPromise}finally{csrfPromise=null}
}async function api(url,opt={},retried=false){const method=String(opt.method||'GET').toUpperCase(),headers={'Content-Type':'application/json',...(opt.headers||{})};if(!['GET','HEAD','OPTIONS'].includes(method))headers['X-CSRF-Token']=await ensureCsrf();const r=await fetch('/api'+url,{credentials:'same-origin',...opt,headers}),j=await r.json().catch(()=>({}));if(r.status===403&&j.error==='CSRF validation failed'&&!retried){await ensureCsrf(true);return api(url,opt,true)}if(!r.ok)throw Error(j.error||'Request failed');return j}
function applyRegistrationSettings(){const r=settings.registration||{};[['regNameWrap','regName',r.display_name],['regPhoneWrap','regPhone',r.phone],['regEmailWrap','regEmail',r.email],['regReferralWrap','regReferral',r.referral]].forEach(([w,i,c])=>{const wrap=$(w),input=$(i),show=c?.show!==false;if(wrap)wrap.classList.toggle('hidden',!show);if(input){input.required=c?.required===true;if(!show)input.value=''}});$('tabRegister').classList.toggle('hidden',r.enabled===false);if(r.enabled===false&&!$('registerForm').classList.contains('hidden'))authMode('login')}function authMode(m){$('loginForm').classList.toggle('hidden',m!=='login');$('registerForm').classList.toggle('hidden',m!=='register');$('tabLogin').classList.toggle('active',m==='login');$('tabRegister').classList.toggle('active',m==='register')}
async function login(){try{await api('/login',{method:'POST',body:JSON.stringify({username:$('loginUsername').value.trim(),password:$('loginPassword').value})});await boot()}catch(e){toast(e.message)}}
async function register(){if(settings.registration?.enabled===false)return toast('Registration is disabled');if(!$('agree').checked)return toast('Please accept the terms');try{await api('/register',{method:'POST',body:JSON.stringify({username:$('regUsername').value.trim(),display_name:$('regName').value.trim(),phone:$('regPhone').value.trim(),email:$('regEmail').value.trim(),password:$('regPassword').value,confirm_password:$('regConfirm').value,referral_code:$('regReferral').value.trim()})});await boot()}catch(e){toast(e.message)}}
async function logout(){try{await api('/logout',{method:'POST'})}catch{}luckyModalDismissed.clear();activeLuckyModal=null;location.reload()}
function formatIst(s){if(!s)return'-';return new Intl.DateTimeFormat(language==='hi'?'hi-IN':language==='zh'?'zh-CN':'en-IN',{timeZone:'Asia/Kolkata',dateStyle:'medium',timeStyle:'short'}).format(new Date(s))}
function levelName(){return me?.member_level?(language==='hi'?me.member_level.name_hi:language==='zh'?me.member_level.name_zh:me.member_level.name_en):'-'}
function applyTestMode(){const t=!!me?.is_test_account;$('testModeBadge')?.classList.toggle('hidden',!t)}function renderDashboard(d){me=d.user;receiving=!!me.receiving_enabled;setText('accountDisplayName',me.display_name||me.username);setText('accountUsername','@'+me.username);setText('accountId',String(me.id).padStart(6,'0'));setText('accountLevel',levelName());setText('accountCreated',formatIst(me.created_at));setText('accountStatus',me.status);setText('accountStatusText',me.status);setText('balanceValue',money(me.balance_inr));setText('lockedValue',money(me.order_locked_inr));setText('commissionWalletValue',money(me.commission_wallet_inr));setText('usdtValue',Number(me.reward_usdt||0).toFixed(2)+' USDT');setText('todayOrders',d.today_orders);setText('todayCommission',money(d.today_commission));setText('receivingState',receiving?'ON':'OFF');setText('receivingHint','Minimum '+money(d.min_receiving_balance));setText('receivingButton',T[language][receiving?'stop':'start']);setText('walletInr',money(me.balance_inr));setText('walletLocked',money(me.order_locked_inr));setText('walletCommission',money(me.commission_wallet_inr));setText('walletUsdt',Number(me.reward_usdt||0).toFixed(2));setText('profileUsername',me.username);setText('profileMemberId',String(me.id).padStart(6,'0'));setText('profileLevel',levelName());setText('profileStatus',me.status);setText('profileName',me.display_name);setText('profilePhone',me.phone||'-');setText('profileReferral',me.referral_code||'-');setText('profileCreated',formatIst(me.created_at));applyTestMode();calculateWithdraw()}
function accountSnapshot(o){try{return JSON.parse(o.payment_account_snapshot||'{}')}catch{return{}}}function mask(v){v=String(v||'');return v.length>6?v.slice(0,2)+'••••'+v.slice(-4):v}
function orderCard(o){const snap=accountSnapshot(o),remark=o.payment_account_remark||snap.remark||'Account',id=escapeHtml(o.id);let actions='';if(o.status==='PENDING')actions=`<button class="secondary" onclick="acceptOrder('${id}')">${o.order_type==='LUCKY'?'Join Now':'Accept'}</button>`;if(o.order_type!=='LUCKY'&&o.status==='PROCESSING')actions+=` <button class="primary" onclick="confirmOrder('${id}')">Confirm</button>`;return `<div class="item orderCompact ${o.order_type==='BONUS'?'bonus':o.order_type==='LUCKY'?'lucky':''}"><div class="row"><b>${id}</b><span class="accountRemarkBadge">${escapeHtml(remark)}</span></div><div class="row"><span class="badge">${escapeHtml(o.order_type)}</span>${o.order_type==='LUCKY'?`<span class="progress">${Number(o.series_current||1)}/${Number(o.series_total||1)}</span>`:''}</div><div class="orderMeta"><span>Amount ${money(o.amount_inr)}</span><span>Commission ${money(o.commission_inr)}</span><span>Reward ${Number(o.extra_reward_usdt||0)} USDT</span><span>${escapeHtml(o.status)}</span></div><div class="orderAccount">Collection Account: <b>${escapeHtml(remark)}</b> · ${escapeHtml(o.payment_account_type||snap.type||'-')} · ${escapeHtml(mask(snap.account_value||''))}</div><div class="row"><span class="muted">${escapeHtml(o.payment_method||'-')}</span><span>${actions}</span></div></div>`}
function renderOrders(rows){const html=rows.length?rows.map(orderCard).join(''):'<div class="empty">No orders</div>';$('orderList').innerHTML=html;$('recentOrders').innerHTML=rows.slice(0,3).length?rows.slice(0,3).map(orderCard).join(''):'<div class="empty">No orders</div>';const special=rows.filter(x=>x.order_type==='BONUS');$('bonusList').innerHTML=special.length?special.map(orderCard).join(''):'<div class="empty">No bonus or lucky orders</div>'}
async function acceptOrder(id){if(me?.is_test_account)return toast('TEST MODE: real financial actions are disabled');try{const x=await api('/orders/'+id+'/accept',{method:'POST'});toast(x.status==='PARTICIPATING'?'Joined successfully':'Order accepted');await refresh()}catch(e){console.error('Order acceptance failed',e);toast(e.message||'Unable to accept this order')}}async function confirmOrder(id){if(me?.is_test_account)return toast('TEST MODE: real financial actions are disabled');if(!confirm('Confirm that this order is completed?'))return;try{await api('/orders/'+id+'/confirm',{method:'POST'});toast('Order completed');await refresh()}catch(e){toast(e.message)}}
function ledgerLabel(type){
 const labels={
  MANUAL_CREDIT:'Manual Credit',
  ORDER_PRINCIPAL_DEBIT:'Order Principal',
  ORDER_COMMISSION:'Order Commission',
  LUCKY_SERIES_COMMISSION:'Lucky Series Commission',
  LUCKY_SERIES_REWARD:'Lucky Series Reward',
  LUCKY_STAGE_FREEZE:'Stage Principal Frozen',
  LUCKY_STAGE_LOCK:'Stage Amount Locked',
  LUCKY_STAGE_RELEASE:'Stage Principal Returned',
  LUCKY_STAGE_UNLOCK:'Stage Lock Released',
  LUCKY_CANCEL_RETURN:'Cancelled · Principal Returned',
  LUCKY_CANCEL_UNLOCK:'Cancelled · Lock Released',
  WITHDRAWAL_DEBIT:'Withdrawal',
  WITHDRAWAL_REFUND:'Withdrawal Refund',
  DEPOSIT_CREDIT:'Deposit Credit'
 };
 return labels[type]||String(type||'Wallet Entry').replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function ledgerDate(v){
 if(!v)return '';
 try{return new Date(v).toLocaleString('en-IN',{timeZone:'Asia/Kolkata',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}
 catch{return ''}
}
function renderLedger(rows){
 $('ledgerList').innerHTML=rows.length?rows.map(x=>{
  const positive=Number(x.amount)>=0;
  const amount=x.wallet_type==='USDT'?`${positive?'+':''}${Number(x.amount).toLocaleString('en-IN',{maximumFractionDigits:2})} USDT`:`${positive?'+':''}${money(x.amount)}`;
  return `<div class="ledgerEntry">
   <div class="ledgerMain">
    <div class="ledgerTitle" title="${escapeHtml(ledgerLabel(x.entry_type))}">${escapeHtml(ledgerLabel(x.entry_type))}</div>
    <div class="ledgerMeta">
     <span class="ledgerRef">${escapeHtml(x.reference_id||'System')}</span>
     ${x.created_at?`<span class="ledgerTime">${escapeHtml(ledgerDate(x.created_at))}</span>`:''}
    </div>
   </div>
   <div class="ledgerAmount ${positive?'ledgerCredit':'ledgerDebit'}">${escapeHtml(amount)}</div>
  </div>`;
 }).join(''):'<div class="empty">No wallet records</div>';
}
function renderRecords(id,rows,type){$(id).innerHTML=rows.length?rows.map(x=>`<div class="item row"><div><b>${escapeHtml(x.id)}</b><div class="muted">${escapeHtml(x.method)}${x.source_wallet?' · '+escapeHtml(x.source_wallet):''}</div></div><div>${money(x[type])} <span class="badge">${escapeHtml(x.status)}</span></div></div>`).join(''):'<div class="empty">No records</div>'}
function renderAccounts(rows){$('accountList').innerHTML=rows.length?rows.map(x=>`<div class="item row"><div><b>${escapeHtml(x.remark)}</b><div>${escapeHtml(x.account_type)} · ${escapeHtml(x.bank_name||x.provider||'')}</div><div class="muted">${escapeHtml(mask(x.account_value))}</div></div><span class="badge">${escapeHtml(x.status)}</span></div>`).join(''):'<div class="empty">No payment accounts</div>'}
function renderCompany(c){$('companyInfo').innerHTML=c.company_name?`<b>${escapeHtml(c.company_name)}</b><p>${escapeHtml(localized(c,'profile'))}</p><p>${escapeHtml(c.qualifications||'')}</p><p>${escapeHtml(c.office_info||'')}</p><p>${escapeHtml(c.partners||'')}</p>`:'<div class="empty">Company information has not been configured.</div>'}
function icon(t){return t==='telegram'?'✈':t==='whatsapp'?'◉':'💬'}function normalizeUrl(v){try{v=String(v||'').trim();const url=new URL(/^https?:\/\//i.test(v)?v:'https://'+v);return ['http:','https:'].includes(url.protocol)?url.href:'#'}catch{return'#'}}function trackContact(id){ensureCsrf().then(token=>fetch('/api/contacts/'+id+'/click',{method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':token},keepalive:true})).catch(()=>{})}
function renderContacts(rows){const list=(rows||[]).filter(x=>x.url);const item=x=>`<a class="supportChannel" href="${normalizeUrl(x.url)}" target="_blank" rel="noopener noreferrer" onclick="trackContact(${x.id});toggleSupportPanel(false)"><span class="supportChannelLeft"><span class="supportChannelIcon">${icon(x.contact_type)}</span><span>${language==='hi'?x.label_hi:x.label_en}</span></span><span>›</span></a>`;$('contactList').innerHTML=list.length?list.map(x=>`<div class="contact"><b>${language==='hi'?x.label_hi:x.label_en}</b><a class="secondary contactLink" href="${normalizeUrl(x.url)}" target="_blank" rel="noopener noreferrer" onclick="trackContact(${x.id})">Open</a></div>`).join(''):'<div class="empty">No contact methods.</div>';$('homeContacts').classList.toggle('hidden',!list.length);$('homeContactButtons').innerHTML=list.map(x=>`<a class="quickContactLink" href="${normalizeUrl(x.url)}" target="_blank" rel="noopener noreferrer" onclick="trackContact(${x.id})"><span class="supportIcon">${icon(x.contact_type)}</span>${language==='hi'?x.label_hi:x.label_en}</a>`).join('');$('supportFloat').classList.toggle('hidden',!list.length);$('supportPanelChannels').innerHTML=list.map(item).join('')}
function toggleSupportPanel(force){const show=typeof force==='boolean'?force:$('supportPanel').classList.contains('hidden');$('supportPanel').classList.toggle('hidden',!show);$('supportOverlay').classList.toggle('hidden',!show)}
function renderBanners(rows){if(!rows.length){$('carousel').classList.add('hidden');return}$('carousel').classList.remove('hidden');$('carousel').innerHTML=rows.map((x,i)=>{const img=(innerWidth<=780&&x.mobile_image_url?x.mobile_image_url:x.image_url)||x.image_url||'';return `<div class="slide ${i===0?'active':''}" style="background-image:url('${escapeHtml(img)}')"></div>`}).join('');clearInterval(window.bannerTimer);let i=0;window.bannerTimer=setInterval(()=>{const s=[...document.querySelectorAll('.slide')];if(!s.length)return;s.forEach(x=>x.classList.remove('active'));i=(i+1)%s.length;s[i].classList.add('active')},4500)}
function showLuckyModal(series){
 if(!series||!series.id||series.status!=='PENDING'||series.auto_popup!==true)return;
 if(activeLuckyModal?.id===series.id)return;
 if(luckyModalDismissed.has(series.id))return;

 const first=series.first_step_detail||(Array.isArray(series.steps)?series.steps.find(step=>Number(step.step_no)===1):null);
 activeLuckyModal=series;
 setText('luckyModalTitle',series.title||'Lucky Series Invitation');
 setText('luckyModalText','A Lucky Series has been assigned to your account. Joining does not require sufficient balance. Balance is checked only when you start the current stage.');
 $('luckyModalStats').innerHTML=[
  {label:'Stage',value:`1/${Number(series.total_steps||1)}`},
  {label:'Required',value:first?money(first.amount_inr):'-'},
  {label:'Commission',value:first?money(first.commission_inr):'-'},
  {label:'Reward',value:first?`${Number(first.extra_reward_usdt||0)} USDT`:'-'}
 ].map(item=>`<div class="luckyStat"><span>${escapeHtml(item.label)}</span><b>${escapeHtml(item.value)}</b></div>`).join('');
 const allowClose=series.allow_close===true;
 $('luckyCloseButton').classList.toggle('hidden',!allowClose);
 $('luckySecondaryButton').classList.toggle('hidden',!allowClose);
 $('luckyModal').classList.remove('hidden');
}
function closeLuckyModal(){
 if(!activeLuckyModal||activeLuckyModal.allow_close!==true)return;
 luckyModalDismissed.add(activeLuckyModal.id);
 $('luckyModal').classList.add('hidden');
 activeLuckyModal=null;
}
async function joinLuckyFromModal(){
 if(!activeLuckyModal)return;
 const id=activeLuckyModal.id;
 try{
  const result=await api('/lucky-series/'+id+'/join',{method:'POST'});
  toast(result.message);
  $('luckyModal').classList.add('hidden');
  activeLuckyModal=null;
  openPage('bonus');
  await refresh();
 }catch(error){
  console.error('Lucky modal join failed',error);
  toast(error.message||'Unable to join Lucky Series');
 }
}
function renderAnnouncements(rows){
 const list=(Array.isArray(rows)?rows:[]).filter(item=>['MARQUEE','BOTH'].includes(item.display_type));
 $('announcementMarquee').classList.toggle('hidden',!list.length);
 $('marqueeTrack').textContent=list.map(item=>'📢 '+localized(item,'content')).join(' • ');
}
function processOrderPopups(rows){
 /* V7.2.1: ordinary and welfare orders never create frontend popups.
    Orders remain fully available in the Orders page. */
 (Array.isArray(rows)?rows:[]).forEach(order=>{
  previousOrderState[order.id]=order.status;
 });
}
function luckyMemberStatus(series,current){
 if(series.status==='PENDING')return 'Invitation waiting';
 if(series.status==='PARTICIPATING'&&current?.status==='AVAILABLE')return 'Ready to start';
 if(series.status==='PARTICIPATING'&&current?.status==='IN_PROGRESS')return 'Waiting for platform settlement';
 if(series.status==='COMPLETED')return 'Completed';
 if(series.status==='CANCELLED')return 'Cancelled';
 return series.status||'-';
}
function luckySeriesCard(series){
 const steps=Array.isArray(series.steps)?series.steps:[];
 const completed=Array.isArray(series.completed_steps)?series.completed_steps:steps.filter(step=>step.status==='COMPLETED');
 const current=series.current_step_detail||steps.find(step=>Number(step.step_no)===Number(series.current_step))||null;
 const actions=series.actions?.member||{};
 const canStart=actions.can_start===true||current?.status==='AVAILABLE';
 const waiting=actions.waiting_for_admin===true||current?.status==='IN_PROGRESS';

 return `<div class="item lucky seriesCard">
  <div class="row">
   <div>
    <b>${escapeHtml(series.title||'Lucky Series')}</b>
    <div class="muted">${escapeHtml(luckyMemberStatus(series,current))}</div>
   </div>
   <span class="badge">${completed.length}/${Number(series.total_steps||steps.length||0)}</span>
  </div>

  ${completed.length?`<div class="settlementBox"><b>Settlement History</b>${completed.map(step=>`<div class="settlementRow">
   <div>
    <b>✓ Stage ${step.step_no} Completed</b>
    <small>${step.completed_at?new Date(step.completed_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'}):''}</small>
   </div>
   <div>
    <span>Amount ${money(step.amount_inr)}</span>
    <span>Commission ${money(step.commission_inr)}</span>
   </div>
  </div>`).join('')}</div>`:''}

  ${current?`<div class="currentStageBox">
   <div class="row">
    <b>Current Stage · ${current.step_no}/${Number(series.total_steps||steps.length||0)}</b>
    <span class="badge">${escapeHtml(current.status)}</span>
   </div>
   <div class="orderMeta">
    <span>Required ${money(current.amount_inr)}</span>
    <span>Commission ${money(current.commission_inr)}</span>
    <span>Reward ${Number(current.extra_reward_usdt||0)} USDT</span>
   </div>
   ${canStart?`<button class="primary" onclick="startLuckyStage('${escapeHtml(series.id)}')">Start Current Stage</button>`:''}
   ${waiting?'<div class="muted">The current stage has started. Please wait for the platform to complete settlement.</div>':''}
  </div>`:''}

  ${series.status==='PENDING'?`<button class="primary" onclick="joinLuckySeries('${escapeHtml(series.id)}')">Join Lucky Series</button>`:''}

  <details class="planDisclosure">
   <summary>View complete series plan</summary>
   ${(series.plan_summary||steps).map(step=>`<div class="item row">
    <span>Stage ${step.step_no}</span>
    <span>${money(step.amount_inr)} · Commission ${money(step.commission_inr)} · ${escapeHtml(step.status)}</span>
   </div>`).join('')}
  </details>
 </div>`;
}
function queueLuckyPopup(series){
 try{
  const actions=series?.actions?.member||{};
  if(series?.status!=='PENDING'||series?.auto_popup!==true||actions.can_join===false)return;
  showLuckyModal(series);
 }catch(error){
  console.error('Lucky popup preparation failed',error,series);
 }
}
function renderLuckySeries(rows){
 const list=$('luckySeriesList');
 if(!Array.isArray(rows)||!rows.length){
  list.innerHTML='<div class="empty">No lucky series</div>';
  return;
 }

 list.innerHTML=rows.map(series=>{
  try{return luckySeriesCard(series)}
  catch(error){
   console.error('Lucky member card render failed',error,series);
   return `<div class="item"><b>Lucky Series</b><div class="muted">Unable to display this series. Please contact support.</div></div>`;
  }
 }).join('');

 rows.forEach(series=>{
  queueLuckyPopup(series);
  try{
   const completed=Array.isArray(series.completed_steps)?series.completed_steps.length:0;
   const previous=previousLuckyState[series.id];

   if(previous&&completed>previous.completed){
    const last=series.completed_steps[series.completed_steps.length-1];
    enqueueOpsPopup({
     key:`lucky_stage_completed_${series.id}_${last.step_no}`,
     badge:'Stage Completed',
     title:`Stage ${last.step_no} Completed`,
     text:series.status==='COMPLETED'
      ?'All Lucky Series stages have been completed.'
      :'The current stage has been settled and the next stage is now available.',
     allowClose:true,
     action:'open-page',
     target:'bonus',
     actionLabel:'View Lucky Series',
     stats:[
      {label:'Principal Returned',value:money(last.amount_inr)},
      {label:'Commission',value:money(last.commission_inr)},
      {label:'Reward',value:`${Number(last.extra_reward_usdt||0)} USDT`}
     ]
    });
   }

   previousLuckyState[series.id]={
    status:series.status,
    completed,
    currentStep:Number(series.current_step||1)
   };
  }catch(error){
   console.error('Lucky completion popup preparation failed',error,series);
  }
 });
}
async function startLuckyStage(id){try{const x=await api('/lucky-series/'+id+'/start-current',{method:'POST'});toast(x.message);await refresh()}catch(e){console.error('Lucky stage start failed',e);toast(e.message||'Unable to start the current stage')}}
async function joinLuckySeries(id){
 try{
  const x=await api('/lucky-series/'+id+'/join',{method:'POST'});
  toast(x.message);
  openPage('bonus');
  await refresh();
 }catch(error){
  console.error('Lucky join failed',error);
  toast(error.message||'Unable to join Lucky Series');
  throw error;
 }
}
function safeRenderSection(name,renderer){
 try{renderer();return true}
 catch(error){
  console.error(`Member section render failed: ${name}`,error);
  return false;
 }
}
function applyMemberState(state){
 if(!state||!['7.0','7.1'].includes(state.schema_version)||!state.dashboard)throw Error('Invalid member state snapshot');

 memberStateStore={
  version:state.state_version||null,
  generatedAt:state.generated_at||null,
  snapshot:state
 };
 walletSettings=state.wallet_settings||{usdt:{},inr:{specialists:[]}};
 settings=state.settings||{};

 safeRenderSection('registration settings',()=>applyRegistrationSettings());

 const orders=state.orders?.orders||[];
 const series=state.lucky?.series||[];

 safeRenderSection('dashboard',()=>renderDashboard(state.dashboard));
 safeRenderSection('orders',()=>{
  renderOrders(orders);
  processOrderPopups(orders);
 });
 safeRenderSection('wallet ledger',()=>renderLedger(state.wallet?.ledger||[]));
 safeRenderSection('deposits',()=>renderRecords('depositList',state.deposits?.deposits||[],'requested_amount'));
 safeRenderSection('withdrawals',()=>renderRecords('withdrawalList',state.withdrawals?.withdrawals||[],'amount'));
 safeRenderSection('payment accounts',()=>renderAccounts(state.payment_accounts?.accounts||[]));
 safeRenderSection('company',()=>renderCompany(state.company||{}));
 safeRenderSection('contacts',()=>renderContacts(state.contacts?.contacts||[]));
 safeRenderSection('messages',()=>{
  const messages=state.messages?.messages||[];
  $('messageList').innerHTML=messages.length
   ?messages.map(item=>`<div class="item"><b>${escapeHtml(localized(item,'title'))}</b><p>${escapeHtml(localized(item,'body'))}</p></div>`).join('')
   :'<div class="empty">No messages</div>';
 });

 /* Banner and Lucky rendering are intentionally isolated.
    A Lucky data/rendering failure must never hide or clear the carousel. */
 safeRenderSection('banners',()=>renderBanners(state.banners?.banners||[]));
 safeRenderSection('announcements',()=>renderAnnouncements(state.announcements?.announcements||[]));
 safeRenderSection('Lucky Series',()=>renderLuckySeries(series));
 safeRenderSection('deposit configuration',()=>renderDepositMethod());
 safeRenderSection('withdraw rules',()=>setText(
  'withdrawRuleHint',
  `Minimum withdrawal: ${money(settings.min_withdraw_amount)} · Fee: ₹0.00`
 ));

 if(Array.isArray(state.errors)&&state.errors.length){
  console.warn('Member state loaded with optional section errors',state.errors);
 }
}
async function refresh(){
 if(refreshing)return;
 refreshing=true;
 try{
  const state=await api('/state');
  applyMemberState(state);
  $('networkBadge').classList.add('hidden');
 }catch(error){
  console.error('Member state refresh failed',error);
  $('networkBadge').classList.remove('hidden');
 }finally{refreshing=false}
}
async function boot(){try{await api('/me');$('auth').classList.add('hidden');$('app').classList.remove('hidden');$('bottom').classList.remove('hidden');await refresh();renderLanguage()}catch{}}
async function toggleReceiving(){if(me?.is_test_account)return toast('TEST MODE: real financial actions are disabled');try{await api('/receiving',{method:'POST',body:JSON.stringify({enabled:!receiving})});await refresh()}catch(e){toast(e.message)}}
function normalizeTelegramUrl(x){const raw=String(x||'').trim();if(!raw)return'#';if(/^https:\/\/t\.me\//i.test(raw))return raw;if(/^@/.test(raw))return'https://t.me/'+raw.slice(1);return raw}
function renderDepositMethod(){
 const inr=walletSettings.inr||{},usdt=walletSettings.usdt||{},usdtOption=$('depositUsdtOption');if(usdtOption){usdtOption.value='USDT_'+String(usdt.network||'TRC20').toUpperCase();usdtOption.textContent='USDT - '+String(usdt.network||'TRC20').toUpperCase();usdtOption.disabled=!usdt.enabled}const method=$('depositMethod').value,isInr=method==='INR';
 $('inrDepositPanel').classList.toggle('hidden',!isInr);$('usdtDepositPanel').classList.toggle('hidden',isInr);
 if(isInr){
  setText('inrDepositHours',inr.service_hours||'');setText('inrDepositInstructions',inr.instructions||'');
  $('inrSpecialistList').innerHTML=(inr.specialists||[]).filter(x=>x.enabled!==false).map(x=>`<a class="telegramSpecialist" href="${escapeHtml(normalizeTelegramUrl(x.url||x.username))}" target="_blank" rel="noopener noreferrer"><span><b>${escapeHtml(x.name||x.username||'Telegram Specialist')}</b><small>${x.username?'@'+escapeHtml(String(x.username).replace(/^@/,'')):''}</small></span><strong>${escapeHtml(inr.button_text||'Contact')}</strong></a>`).join('')||'<div class="empty">No recharge specialist is available.</div>';
  $('depositAmount').min=Number(inr.min_amount||0);$('depositSubmitButton').classList.add('hidden');
 }else{
  setText('usdtDepositNetwork','USDT · '+(usdt.network||''));setText('usdtDepositMinimum',usdt.min_amount?`Minimum ${usdt.min_amount} USDT`:'');
  setText('usdtDepositAddress',usdt.address||'-');setText('usdtDepositInstructions',usdt.instructions||'');
  $('copyUsdtAddressButton').classList.toggle('hidden',usdt.show_copy===false||!usdt.address);
  const qr=$('usdtDepositQr');qr.classList.toggle('hidden',!usdt.qr_image_url);if(usdt.qr_image_url)qr.src=usdt.qr_image_url;
  $('depositAmount').min=Number(usdt.min_amount||0);$('depositSubmitButton').classList.remove('hidden');
 }
}
async function copyUsdtAddress(){const address=walletSettings.usdt?.address||'';if(!address)return toast('USDT address is not configured');try{await navigator.clipboard.writeText(address);toast('USDT address copied')}catch{toast('Copy failed')}}

async function createDeposit(){if(me?.is_test_account)return toast('TEST MODE: real financial actions are disabled');const method=$('depositMethod').value;if(method==='INR')return toast('Please contact a Telegram recharge specialist');const cfg=walletSettings.usdt||{};if(!cfg.enabled)return toast('USDT recharge is currently unavailable');const amount=Number($('depositAmount').value);if(amount<Number(cfg.min_amount||0))return toast(`Minimum recharge is ${cfg.min_amount} USDT`);try{await api('/deposits',{method:'POST',body:JSON.stringify({method:'USDT_'+String(cfg.network||'TRC20').toUpperCase(),amount,reference_no:$('depositReference').value,proof_note:$('depositNote').value})});toast('Deposit submitted');await refresh()}catch(e){toast(e.message)}}
function selectedWithdrawBalance(){return $('withdrawSource').value==='COMMISSION'?Number(me?.commission_wallet_inr||0):Number(me?.balance_inr||0)}function setPercent(p){$('withdrawAmount').value=(selectedWithdrawBalance()*p).toFixed(2);calculateWithdraw()}function calculateWithdraw(){const available=selectedWithdrawBalance(),a=Number($('withdrawAmount')?.value||0);setText('withdrawSourceBalance',money(available));setText('withdrawFee',money(0));setText('withdrawReceive',money(a));setText('withdrawRemaining',money(Math.max(0,available-a)))}async function createWithdrawal(){if(me?.is_test_account)return toast('TEST MODE: real financial actions are disabled');try{const x=await api('/withdrawals',{method:'POST',body:JSON.stringify({source_wallet:$('withdrawSource').value,method:$('withdrawMethod').value,destination:$('withdrawDestination').value,amount:Number($('withdrawAmount').value)})});toast(`Withdrawal submitted · Fee ${money(x.fee)}`);$('withdrawAmount').value='';await refresh()}catch(e){toast(e.message)}}
async function addPaymentAccount(){if(me?.is_test_account)return toast('TEST MODE: real financial actions are disabled');try{await api('/payment-accounts',{method:'POST',body:JSON.stringify({remark:$('accountRemark').value,account_type:$('accountType').value,holder_name:$('holderName').value,bank_name:$('bankName').value,account_value:$('accountValue').value,ifsc:$('ifsc').value,provider:$('provider').value})});toast('Account submitted for review');$('accountRemark').value='';await refresh()}catch(e){toast(e.message)}}
function openPage(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$(id).classList.add('active');document.querySelectorAll('.bottom button').forEach(x=>x.classList.toggle('active',x.dataset.page===id));scrollTo({top:0,behavior:'smooth'})}function renderLanguage(){language=$('language').value;const dict=T[language]||T.en;document.querySelectorAll('[data-i18n]').forEach(x=>x.textContent=dict[x.dataset.i18n]||T.en[x.dataset.i18n]||x.textContent);setText('availableLabel',T[language].available);if(me)refresh()}
(async()=>{try{settings=await api('/settings');applyRegistrationSettings()}catch(e){console.warn(e)}})();Object.assign(window,{startLuckyStage,authMode,login,register,logout,openPage,toggleReceiving,acceptOrder,confirmOrder,createDeposit,setPercent,calculateWithdraw,createWithdrawal,addPaymentAccount,toggleSupportPanel,trackContact,closeLuckyModal,joinLuckyFromModal,joinLuckySeries,renderLanguage,renderDepositMethod,copyUsdtAddress});$('withdrawAmount')?.addEventListener('input',calculateWithdraw);setInterval(refresh,5000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});boot();
