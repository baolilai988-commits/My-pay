# Luckypay Locked Business Rules

Status: **LOCKED**

These rules may not be changed by refactoring, cleanup, performance work, dependency updates, UI maintenance, database migration, or bug fixes. A rule change requires explicit product approval and a new baseline version.

## Authentication
1. Administrator Session survives F5 while valid.
2. Administrator refresh restores the exact current page.
3. CSRF remains enabled for state-changing requests.
4. Member and administrator access remain role-separated.

## Ordinary orders
1. A member may only accept an eligible assigned order.
2. Accepting checks available principal.
3. Sufficient principal moves from available to locked principal.
4. Completion settles through the central wallet service.
5. Insufficient principal shows required, available, and shortfall amounts.
6. Ordinary-order popup and Lucky popup remain independent.

## Lucky Series
1. Administrator assigns a Lucky Series to a specific member.
2. New series status is `PENDING`.
3. `auto_popup` controls automatic invitation.
4. `allow_close` controls whether the invitation may close.
5. Joining does not check or freeze principal.
6. Starting the current stage checks and freezes that stage amount.
7. Only the current available stage may start.
8. Completion settles principal, commission, and USDT reward through wallet-service.
9. The next stage unlocks only after the current stage completes.
10. The invitation shows Stage 1 amount, commission, reward, and progress.
11. Lucky popup existence and trigger behavior are mandatory release gates.

## Wallets and funds
1. Every wallet change goes through `wallet-service`.
2. Every wallet change writes a ledger entry.
3. Multi-step fund changes run in a database transaction.
4. Test accounts never affect real reports.
5. Test-account simulated wallets also use wallet-service.

## Wallet settings
1. USDT network, address, QR, instructions, and minimum are administrator-configurable.
2. INR Telegram specialists are administrator-configurable.
3. Member frontend reads settings dynamically.
4. Recharge networks may not be hard-coded.

## Member frontend
1. Member information renders after login.
2. Enabled banners render in the homepage carousel.
3. Home, Orders, Wallet, Bonus, and Profile remain available.
4. Existing HTML, CSS, wording, buttons, and interaction require explicit approval to change.
5. Offline badge appears only after an actual state-fetch failure.

## Administrator frontend
1. Existing navigation, icons, layouts, and controls are protected.
2. Live refresh refreshes only the active page.
3. Editing fields are not overwritten by auto refresh.
4. Manual refresh never returns to Dashboard.
5. Existing HTML, CSS, buttons, and interaction require explicit approval to change.

## Release policy
A release is forbidden when any locked rule, protected frontend hash, required DOM element, required API, required database field, integration flow, or mandatory popup check fails.
