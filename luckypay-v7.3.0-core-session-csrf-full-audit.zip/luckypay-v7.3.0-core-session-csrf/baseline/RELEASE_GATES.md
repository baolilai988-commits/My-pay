# Mandatory Release Gates

A release package must not be produced when any gate fails.

1. Protected frontend hashes match unless an explicit approval file is supplied.
2. Required member/admin pages, buttons, DOM elements, and modals exist.
3. Every cataloged frontend request has a backend route.
4. Every contract database table and field exists.
5. JavaScript syntax and duplicate-function checks pass.
6. Session, CSRF, page restoration, and refresh checks pass.
7. Lucky popup DOM, CSS, trigger, join, start, and settlement checks pass.
8. Carousel, member information, and wallet-settings checks pass.
9. Ordinary order and Lucky Series database integration tests pass.
10. Wallet changes use wallet-service and create ledger records.
11. Test accounts stay isolated from real reports.
12. Source changes are compared with the baseline snapshot.
13. `npm test` and `npm run audit` pass inside Docker.
