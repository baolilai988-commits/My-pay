# V7.2.0 Frontend Popup Conflict Audit

The frontend conflict was confirmed: Lucky invitations, announcements, and ordinary-order notifications shared one modal, one queue, one active-popup variable, and shared sessionStorage suppression keys.

V7.2 gives Lucky a dedicated modal and state:

- `luckyModal`
- `activeLuckyModal`
- `showLuckyModal`
- `closeLuckyModal`
- `joinLuckyFromModal`

Lucky no longer enters `opsPopupQueue` and no longer uses `ops_popup_seen_*`. An announcement can no longer block the Lucky invitation. The shared popup remains for announcements and ordinary orders.

Automated checks passed for dedicated Lucky modal DOM/CSS, direct Lucky join action, lifecycle rules, administrator completion controls, API/database contracts, baseline comparison, and the mandatory release gate.

A browser test after deployment is still required for final runtime confirmation.
