# Luckypay V7.1.0 — Lucky Series Rebuild

V7.1.0 completely rebuilds the Lucky Series module without changing ordinary orders, wallet rules, recharge/withdrawal logic, administrator layout, or the protected HTML/CSS design.

## Rebuilt Lucky flow

```text
Administrator creates series
→ Member receives automatic invitation
→ Member joins without balance validation
→ Stage 1 becomes AVAILABLE
→ Member starts Stage 1
→ Stage amount is validated and locked
→ Administrator completes current stage
→ Principal is returned
→ Commission and USDT reward are credited
→ Next stage becomes AVAILABLE
→ Final stage completes the whole series
```

## Administrator controls

The Lucky management card now always shows:

- series/member status
- current stage
- stage amount
- commission
- USDT reward
- locked principal
- completion control
- cancellation/refund control
- reason when completion is not yet available

The completion button is enabled only when the member has started the current stage (`IN_PROGRESS`). It is no longer silently absent.

## Failure isolation

Member banner rendering and Lucky rendering are isolated. A malformed Lucky record or Lucky rendering failure cannot clear or hide the homepage carousel.

## Verification

```bash
cd backend-api
npm run baseline:compare
npm run release:gate
npm test
```

See `AI_AUDIT_REPORT_V7.1.0.md` and `DEPLOYMENT.md`.
