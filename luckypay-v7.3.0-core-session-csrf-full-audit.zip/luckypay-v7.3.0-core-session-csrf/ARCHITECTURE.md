# Luckypay V6 Architecture

- `auth-session-service.js`: server Session lifecycle.
- `settings-service.js`: all configurable business values and deposit validation.
- `wallet-service.js`: the only service permitted to mutate wallet balances.
- `auth-manager.js`: browser authentication and CSRF lifecycle.
- `refresh-manager.js`: current-page refresh, dirty-form protection and refresh serialization.
- `settings-client.js`: administrator settings API boundary.

Routes validate HTTP input and orchestrate transactions; they do not own configuration defaults or wallet arithmetic.
