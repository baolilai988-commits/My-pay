"use strict";
const db=require('../lib/db');

const SERIES_STATUS=new Set(['PENDING','PARTICIPATING','COMPLETED','CANCELLED']);
const STEP_STATUS=new Set(['LOCKED','AVAILABLE','IN_PROGRESS','COMPLETED','CANCELLED']);

function normalizeSeries(row){
 if(!row)return null;
 const series={...row};
 series.status=SERIES_STATUS.has(String(series.status))?String(series.status):'PENDING';
 series.current_step=Math.max(1,Number(series.current_step||1));
 series.total_steps=Math.max(1,Number(series.total_steps||1));
 series.auto_popup=Number(series.auto_popup||0)===1;
 series.allow_close=Number(series.allow_close||0)===1;
 return series;
}

function normalizeStep(row){
 const step={...row};
 step.step_no=Math.max(1,Number(step.step_no||1));
 step.amount_inr=Number(step.amount_inr||0);
 step.commission_inr=Number(step.commission_inr||0);
 step.extra_reward_usdt=Number(step.extra_reward_usdt||0);
 step.locked_amount=Number(step.locked_amount||0);
 step.status=STEP_STATUS.has(String(step.status))?String(step.status):'LOCKED';
 return step;
}

function actionState(series,current){
 const terminal=['COMPLETED','CANCELLED'].includes(series.status);
 const pending=series.status==='PENDING';
 const participating=series.status==='PARTICIPATING';
 const available=participating&&current?.status==='AVAILABLE';
 const inProgress=participating&&current?.status==='IN_PROGRESS';

 let adminHint='No action available';
 if(pending)adminHint='Waiting for the member to join';
 else if(available)adminHint='Member joined; waiting for the member to start the current stage';
 else if(inProgress)adminHint='Current stage is in progress and can be completed by the administrator';
 else if(series.status==='COMPLETED')adminHint='All stages completed';
 else if(series.status==='CANCELLED')adminHint='Series cancelled';

 return{
  member:{
   can_join:pending,
   can_start:available,
   waiting_for_admin:inProgress,
   terminal
  },
  admin:{
   can_complete:inProgress,
   can_cancel:!terminal,
   complete_reason:inProgress?'READY':pending?'MEMBER_NOT_JOINED':available?'STAGE_NOT_STARTED':'NOT_AVAILABLE',
   hint:adminHint
  }
 };
}

function enrichSeries(row){
 const series=normalizeSeries(row);
 const steps=db.prepare('SELECT * FROM lucky_series_steps WHERE series_id=? ORDER BY step_no').all(series.id).map(normalizeStep);
 const current=steps.find(step=>step.step_no===series.current_step)||null;
 const completed=steps.filter(step=>step.status==='COMPLETED');

 series.steps=steps;
 series.completed_steps=completed;
 series.current_step_detail=current;
 series.first_step_detail=steps.find(step=>step.step_no===1)||null;
 series.locked_count=steps.filter(step=>step.status==='LOCKED').length;
 series.progress={completed:completed.length,total:series.total_steps};
 series.plan_summary=steps.map(step=>({
  step_no:step.step_no,
  amount_inr:step.amount_inr,
  commission_inr:step.commission_inr,
  extra_reward_usdt:step.extra_reward_usdt,
  status:step.status
 }));
 series.actions=actionState(series,current);
 return series;
}

function getMemberSeries(seriesId,userId){
 const row=db.prepare('SELECT * FROM lucky_series WHERE id=? AND user_id=?').get(seriesId,userId);
 return row?enrichSeries(row):null;
}

function getAdminSeries(seriesId){
 const row=db.prepare(`SELECT l.*,u.username,u.display_name
  FROM lucky_series l JOIN users u ON u.id=l.user_id
  WHERE l.id=?`).get(seriesId);
 return row?enrichSeries(row):null;
}

function listMemberSeries(userId){
 return db.prepare('SELECT * FROM lucky_series WHERE user_id=? ORDER BY created_at DESC')
  .all(userId).map(enrichSeries);
}

function listAdminSeries(){
 return db.prepare(`SELECT l.*,u.username,u.display_name
  FROM lucky_series l JOIN users u ON u.id=l.user_id
  WHERE u.is_test_account=0 ORDER BY l.created_at DESC`).all().map(enrichSeries);
}

module.exports={
 SERIES_STATUS,STEP_STATUS,
 enrichSeries,getMemberSeries,getAdminSeries,listMemberSeries,listAdminSeries
};
