"use strict";
function persist(req){return new Promise((resolve,reject)=>req.session.save(err=>err?reject(err):resolve()))}
async function establish(req,user){await new Promise((resolve,reject)=>req.session.regenerate(err=>err?reject(err):resolve()));req.session.user={id:user.id,role:user.role,username:user.username,admin_role:user.admin_role};await persist(req)}
async function setAdminChallenge(req,user){req.session.admin_challenge={id:user.id,username:user.username,admin_role:user.admin_role,expires:Date.now()+5*60*1000};await persist(req)}
function clearChallenge(req){delete req.session.admin_challenge}
module.exports={persist,establish,setAdminChallenge,clearChallenge};
