"use strict";
const crypto=require('crypto');
const db=require('../lib/db');
const config=require('../config');
const {publicUser}=require('./common');
const settings=require('./settings-service');
const {listMemberSeries}=require('./lucky-series-service');
const {now}=require('../lib/utils');

function safeSection(name,reader,fallback,errors){
 try{return reader()}
 catch(error){
  console.error(`Member state section failed: ${name}`,error);
  errors.push({section:name,code:'SECTION_UNAVAILABLE'});
  return fallback;
 }
}

function dashboard(userId){
 const user=db.prepare('SELECT * FROM users WHERE id=?').get(userId);
 if(!user)throw Object.assign(new Error('Member account not found'),{statusCode:401});
 const totals=db.prepare(`SELECT
  COUNT(*) today_orders,
  COALESCE(SUM(CASE WHEN status='COMPLETED' THEN commission_inr ELSE 0 END),0) today_commission
  FROM orders
  WHERE user_id=?
  AND date(datetime(created_at),'+5 hours','+30 minutes')=date(datetime('now'),'+5 hours','+30 minutes')`).get(user.id);
 return{
  user:publicUser(user),
  today_orders:user.is_test_account
   ?Number(user.test_bonus_completed||0)+Number(user.test_lucky_completed||0)
   :Number(totals.today_orders),
  today_commission:user.is_test_account
   ?Number(user.test_today_commission||0)
   :Number(totals.today_commission),
  today_income:user.is_test_account
   ?Number(user.test_today_income||0)
   :Number(totals.today_commission),
  min_receiving_balance:config.minReceivingBalance
 };
}

function stateFingerprint(userId){
 const row=db.prepare(`SELECT
  (SELECT COALESCE(MAX(updated_at),'') FROM http_sessions) session_updated,
  (SELECT COALESCE(MAX(created_at),'') FROM orders WHERE user_id=?) order_updated,
  (SELECT COALESCE(MAX(COALESCE(completed_at,joined_at,created_at)),'') FROM lucky_series WHERE user_id=?) lucky_updated,
  (SELECT COALESCE(MAX(updated_at),'') FROM system_settings) settings_updated,
  (SELECT COALESCE(MAX(id),0) FROM wallet_ledger WHERE user_id=?) ledger_id,
  (SELECT COALESCE(MAX(id),0) FROM messages WHERE user_id IS NULL OR user_id=?) message_id
 `).get(userId,userId,userId,userId);
 return crypto.createHash('sha256').update(JSON.stringify(row)).digest('hex').slice(0,24);
}

function buildMemberState(userId){
 const errors=[];
 const generatedAt=now();
 const critical=dashboard(userId);

 const state={
  schema_version:'7.1',
  generated_at:generatedAt,
  state_version:stateFingerprint(userId),
  dashboard:critical,
  orders:safeSection('orders',()=>({
   orders:db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(userId)
  }),{orders:[]},errors),
  lucky:safeSection('lucky',()=>({series:listMemberSeries(userId)}),{series:[]},errors),
  wallet:safeSection('wallet',()=>({
   ledger:db.prepare('SELECT * FROM wallet_ledger WHERE user_id=? ORDER BY id DESC LIMIT 300').all(userId)
  }),{ledger:[]},errors),
  deposits:safeSection('deposits',()=>({
   deposits:db.prepare('SELECT * FROM deposits WHERE user_id=? ORDER BY created_at DESC').all(userId)
  }),{deposits:[]},errors),
  withdrawals:safeSection('withdrawals',()=>({
   withdrawals:db.prepare('SELECT * FROM withdrawals WHERE user_id=? ORDER BY created_at DESC').all(userId)
  }),{withdrawals:[]},errors),
  payment_accounts:safeSection('payment_accounts',()=>({
   accounts:db.prepare('SELECT * FROM payment_accounts WHERE user_id=? ORDER BY id DESC').all(userId)
  }),{accounts:[]},errors),
  company:safeSection('company',()=>db.prepare('SELECT * FROM company_profile WHERE id=1').get()||{}, {},errors),
  contacts:safeSection('contacts',()=>({
   contacts:db.prepare('SELECT * FROM contacts WHERE enabled=1 ORDER BY sort_order,id').all()
  }),{contacts:[]},errors),
  messages:safeSection('messages',()=>({
   messages:db.prepare('SELECT * FROM messages WHERE user_id IS NULL OR user_id=? ORDER BY id DESC LIMIT 300').all(userId)
  }),{messages:[]},errors),
  banners:safeSection('banners',()=>({
   banners:db.prepare(`SELECT * FROM banners
    WHERE enabled=1
    AND (start_at IS NULL OR start_at<=?)
    AND (end_at IS NULL OR end_at>=?)
    ORDER BY sort_order,id`).all(generatedAt,generatedAt)
  }),{banners:[]},errors),
  announcements:safeSection('announcements',()=>({
   announcements:db.prepare(`SELECT * FROM announcements
    WHERE enabled=1
    AND (start_at IS NULL OR start_at<=?)
    AND (end_at IS NULL OR end_at>=?)
    ORDER BY sort_order,id DESC`).all(generatedAt,generatedAt)
  }),{announcements:[]},errors),
  settings:safeSection('settings',()=>settings.publicSettings(),{},errors),
  wallet_settings:safeSection('wallet_settings',()=>settings.walletSettings(),{usdt:{},inr:{specialists:[]}},errors),
  errors
 };
 state.complete=errors.length===0;
 return state;
}

module.exports={buildMemberState};
