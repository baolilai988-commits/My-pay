"use strict";
const db=require('../lib/db');
const {now}=require('../lib/utils');
const {WALLETS}=require('../domain/constants');

function getUser(userId){
 const user=db.prepare('SELECT * FROM users WHERE id=?').get(userId);
 if(!user)throw Error('User not found');
 return user;
}
function walletInfo(walletKey){
 const info=WALLETS[String(walletKey||'').toUpperCase()];
 if(!info)throw Error('Unsupported wallet');
 return info;
}
function writeLedger({userId,wallet,entryType,amount,before,after,referenceType='',referenceId='',note='',operator='SYSTEM'}){
 db.prepare(`INSERT INTO wallet_ledger(
  user_id,wallet_type,entry_type,amount,before_amount,after_amount,
  reference_type,reference_id,note,operator,created_at
 ) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(
  userId,wallet,entryType,amount,before,after,referenceType,referenceId,note,operator,now()
 );
}
function changeWallet({userId,walletKey,amount,entryType,referenceType='',referenceId='',note='',operator='SYSTEM',allowNegative=false}){
 const info=walletInfo(walletKey),user=getUser(userId),before=Number(user[info.field]||0),delta=Number(amount),after=before+delta;
 if(!Number.isFinite(delta)||delta===0)throw Error('Invalid wallet amount');
 if(!allowNegative&&after<0)throw Error('Insufficient wallet balance');
 db.prepare(`UPDATE users SET ${info.field}=? WHERE id=?`).run(after,userId);
 writeLedger({userId,wallet:info.ledger,entryType,amount:delta,before,after,referenceType,referenceId,note,operator});
 return{before,after,amount:delta};
}
function credit(args){return changeWallet({...args,amount:Math.abs(Number(args.amount))})}
function debit(args){return changeWallet({...args,amount:-Math.abs(Number(args.amount))})}
function lockPrincipal({userId,amount,referenceType,referenceId,note,operator='SYSTEM'}){
 const value=Number(amount);if(!(value>0))throw Error('Invalid principal amount');
 const user=getUser(userId),principal=Number(user.balance_inr),locked=Number(user.order_locked_inr);
 if(principal<value)throw Object.assign(Error('Insufficient principal'),{code:'INSUFFICIENT_PRINCIPAL',required:value,available:principal,shortfall:value-principal});
 db.prepare('UPDATE users SET balance_inr=balance_inr-?,order_locked_inr=order_locked_inr+? WHERE id=?').run(value,value,userId);
 writeLedger({userId,wallet:'INR',entryType:'PRINCIPAL_LOCK',amount:-value,before:principal,after:principal-value,referenceType,referenceId,note,operator});
 writeLedger({userId,wallet:'LOCKED',entryType:'LOCKED_CREDIT',amount:value,before:locked,after:locked+value,referenceType,referenceId,note,operator});
 return{principalBefore:principal,principalAfter:principal-value,lockedBefore:locked,lockedAfter:locked+value};
}
function releasePrincipal({userId,amount,referenceType,referenceId,note,operator='SYSTEM'}){
 const value=Number(amount);if(!(value>0))throw Error('Invalid locked amount');
 const user=getUser(userId),principal=Number(user.balance_inr),locked=Number(user.order_locked_inr);
 if(locked<value)throw Error('Locked balance mismatch');
 db.prepare('UPDATE users SET balance_inr=balance_inr+?,order_locked_inr=order_locked_inr-? WHERE id=?').run(value,value,userId);
 writeLedger({userId,wallet:'INR',entryType:'PRINCIPAL_RELEASE',amount:value,before:principal,after:principal+value,referenceType,referenceId,note,operator});
 writeLedger({userId,wallet:'LOCKED',entryType:'LOCKED_DEBIT',amount:-value,before:locked,after:locked-value,referenceType,referenceId,note,operator});
 return{principalBefore:principal,principalAfter:principal+value,lockedBefore:locked,lockedAfter:locked-value};
}
function consumeLocked({userId,amount,referenceType,referenceId,note,operator='SYSTEM'}){
 const value=Number(amount);if(!(value>0))throw Error('Invalid locked amount');
 const user=getUser(userId),locked=Number(user.order_locked_inr);
 if(locked<value)throw Error('Locked balance mismatch');
 db.prepare('UPDATE users SET order_locked_inr=order_locked_inr-? WHERE id=?').run(value,userId);
 writeLedger({userId,wallet:'LOCKED',entryType:'LOCKED_CONSUME',amount:-value,before:locked,after:locked-value,referenceType,referenceId,note,operator});
 return{before:locked,after:locked-value};
}
module.exports={getUser,credit,debit,lockPrincipal,releasePrincipal,consumeLocked,changeWallet,writeLedger};
