"use strict";
const nodeEnv=process.env.NODE_ENV||'development';
const allowedOrigins=String(process.env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
module.exports={
 port:Number(process.env.PORT||3000),
 dbPath:process.env.DB_PATH||'/app/data/luckypay.db',
 sessionSecret:process.env.SESSION_SECRET||'replace-me',
 adminUsername:process.env.ADMIN_USERNAME||'admin',
 adminPassword:process.env.ADMIN_PASSWORD||'ChangeMe123!',
 uploadRoot:process.env.UPLOAD_ROOT||'/app/uploads',
 timezone:'Asia/Kolkata',
 minReceivingBalance:Number(process.env.MIN_RECEIVING_BALANCE||5000),
 defaultMinWithdrawAmount:Number(process.env.MIN_WITHDRAW_AMOUNT||500),
 nodeEnv,
 allowedOrigins,
 cookieSecure:String(process.env.COOKIE_SECURE||'false')==='true',
 sessionHours:Number(process.env.SESSION_HOURS||8),
 trustProxy:Number(process.env.TRUST_PROXY||1)
};
