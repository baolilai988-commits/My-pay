"use strict";const bcrypt=require('bcryptjs');
const r=require('express').Router();
const db=require('../lib/db');
const {admin,permission}=require('../lib/auth');
const {publicUser,ledger,message,audit}=require('../services/common');const walletService=require('../services/wallet-service');const settingsService=require('../services/settings-service');
const {now,makeId}=require('../lib/utils');
const config=require('../config');
const multer=require('multer');
const fs=require('fs');
const path=require('path');
r.use(admin);
r.use((req,res,next)=>{const path=req.path;let key='content';if(path.startsWith('/users')||path.startsWith('/levels')||path.startsWith('/test-accounts'))key='users';else if(path.startsWith('/orders'))key='orders';else if(path.startsWith('/payment-accounts'))key='payment_accounts';else if(path.startsWith('/deposits'))key='deposits';else if(path.startsWith('/withdrawals'))key='withdrawals';else if(path.startsWith('/reports'))key='reports';else if(path.startsWith('/settings'))key='settings';else if(path.startsWith('/audit-logs'))key='audit';else if(path.startsWith('/dashboard'))key='read_only';const mw=permission(key);return mw(req,res,next)});
const bannerDir=path.join(config.uploadRoot,'banners');fs.mkdirSync(bannerDir,{recursive:true});
const upload=multer({storage:multer.diskStorage({destination:(_,__,cb)=>cb(null,bannerDir),filename:(_,f,cb)=>cb(null,`banner-${Date.now()}-${Math.random().toString(16).slice(2)}${path.extname(f.originalname).toLowerCase()}`)}),limits:{fileSize:8*1024*1024},fileFilter:(_,f,cb)=>['image/jpeg','image/png','image/webp'].includes(f.mimetype)?cb(null,true):cb(new Error('Only JPG, PNG and WEBP are allowed'))});
r.get('/dashboard',(req,res)=>{
 const today="date(datetime('now'),'+5 hours','+30 minutes')";
 const createdToday="date(datetime(created_at),'+5 hours','+30 minutes')="+today;
 const depositToday="date(datetime(COALESCE(d.reviewed_at,d.created_at)),'+5 hours','+30 minutes')="+today;
 const withdrawalToday="date(datetime(COALESCE(w.reviewed_at,w.created_at)),'+5 hours','+30 minutes')="+today;
 res.json({
  total_users:db.prepare("SELECT COUNT(*) c FROM users WHERE role='user' AND is_test_account=0").get().c,
  today_users:db.prepare(`SELECT COUNT(*) c FROM users WHERE role='user' AND is_test_account=0 AND ${createdToday}`).get().c,
  total_orders:db.prepare("SELECT COUNT(*) c FROM orders o JOIN users u ON u.id=o.user_id WHERE u.is_test_account=0").get().c,
  today_orders:db.prepare(`SELECT COUNT(*) c FROM orders o JOIN users u ON u.id=o.user_id WHERE u.is_test_account=0 AND date(datetime(o.created_at),'+5 hours','+30 minutes')=${today}`).get().c,
  pending_deposits:db.prepare("SELECT COUNT(*) c FROM deposits d JOIN users u ON u.id=d.user_id WHERE u.is_test_account=0 AND d.status='PENDING'").get().c,
  pending_withdrawals:db.prepare("SELECT COUNT(*) c FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE u.is_test_account=0 AND w.status='PENDING'").get().c,
  receiving_users:db.prepare("SELECT COUNT(*) c FROM users WHERE role='user' AND is_test_account=0 AND receiving_enabled=1").get().c,
  today_deposit_count:db.prepare(`SELECT COUNT(*) c FROM deposits d JOIN users u ON u.id=d.user_id WHERE u.is_test_account=0 AND d.status='COMPLETED' AND ${depositToday}`).get().c,
  today_deposit_users:db.prepare(`SELECT COUNT(DISTINCT d.user_id) c FROM deposits d JOIN users u ON u.id=d.user_id WHERE u.is_test_account=0 AND d.status='COMPLETED' AND d.credited_amount>0 AND ${depositToday}`).get().c,
  today_deposit_amount:db.prepare(`SELECT COALESCE(SUM(d.credited_amount),0) s FROM deposits d JOIN users u ON u.id=d.user_id WHERE u.is_test_account=0 AND d.status='COMPLETED' AND ${depositToday}`).get().s,
  today_withdrawal_amount:db.prepare(`SELECT COALESCE(SUM(w.amount),0) s FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE u.is_test_account=0 AND w.status='COMPLETED' AND ${withdrawalToday}`).get().s
 });
});
r.get('/members/search',(req,res)=>{const q=String(req.query.q||'').trim();if(!q)return res.json({users:[]});res.json({users:db.prepare("SELECT id,username,display_name,status FROM users WHERE role='user' AND is_test_account=0 AND (username LIKE ? COLLATE NOCASE OR display_name LIKE ? COLLATE NOCASE) ORDER BY username LIMIT 20").all(`%${q}%`,`%${q}%`)})});
r.get('/users',(req,res)=>res.json({users:db.prepare("SELECT * FROM users WHERE role='user' AND is_test_account=0 ORDER BY id DESC").all().map(publicUser)}));
r.put('/users/:id',(req,res)=>{db.prepare("UPDATE users SET status=?,member_level_id=?,receiving_blocked=?,receiving_enabled=CASE WHEN ?=1 OR ?!='ACTIVE' THEN 0 ELSE receiving_enabled END WHERE id=? AND role='user'").run(req.body.status,Number(req.body.member_level_id),req.body.receiving_blocked?1:0,req.body.receiving_blocked?1:0,req.body.status,req.params.id);audit(req,'UPDATE_USER','USER',req.params.id,req.body);res.json({ok:true,message:'用户保存成功'})});
r.post('/users/:id/credit',(req,res)=>{const tx=db.transaction(()=>{const u=db.prepare("SELECT * FROM users WHERE id=? AND role='user' AND is_test_account=0").get(req.params.id);if(!u)throw Error('User not found');const amount=Number(req.body.amount),bonus=Number(req.body.bonus||0);if(!(amount>0)||bonus<0)throw Error('Invalid amount');const total=amount+bonus,id=makeId('DEP');db.prepare("INSERT INTO deposits(id,user_id,method,requested_amount,actual_amount,bonus_amount,credited_amount,reference_no,proof_note,status,created_at,reviewed_at,reviewed_by) VALUES(?,?,?,?,?,?,?,?,?,'COMPLETED',?,?,?)").run(id,u.id,'INR',amount,amount,bonus,total,req.body.reference_no||'',req.body.note||'',now(),now(),req.session.user.id);const result=walletService.credit({userId:u.id,walletKey:'PRINCIPAL',amount:total,entryType:'MANUAL_CREDIT',referenceType:'DEPOSIT',referenceId:id,note:req.body.note||'',operator:req.session.user.username});message(u.id,'DEPOSIT','Balance credited','बैलेंस जमा हुआ',`₹${total.toFixed(2)} credited.`,`₹${total.toFixed(2)} जमा हुआ।`);return{deposit_id:id,before:result.before,amount,bonus,total,after:result.after}});try{res.json({ok:true,...tx(),message:'上分成功'})}catch(e){res.status(400).json({error:e.message})}});
r.post('/users/:id/adjust',(req,res)=>{const tx=db.transaction(()=>{const u=db.prepare("SELECT * FROM users WHERE id=? AND role='user' AND is_test_account=0").get(req.params.id);if(!u)throw Error('User not found');const type=String(req.body.wallet_type||'INR').toUpperCase(),amount=Number(req.body.amount),map={INR:'PRINCIPAL',COMMISSION:'COMMISSION',USDT:'USDT'},walletKey=map[type];if(!amount||!walletKey)throw Error('Invalid adjustment');walletService.changeWallet({userId:u.id,walletKey,amount,entryType:'ADMIN_ADJUST',referenceType:'ADMIN_ADJUST',referenceId:makeId('ADJ'),note:req.body.note||'',operator:req.session.user.username})});try{tx();res.json({ok:true,message:'调账成功'})}catch(e){res.status(400).json({error:e.message})}});

function testAccountRow(id){
 return db.prepare(`SELECT u.*,l.name_zh AS level_name
  FROM users u LEFT JOIN member_levels l ON l.id=u.member_level_id
  WHERE u.id=? AND u.role='user' AND u.is_test_account=1`).get(id)
}
function nonNegativeNumber(value,name){
 const n=Number(value||0);if(!Number.isFinite(n)||n<0)throw Error(`${name} 必须是非负数`);return n
}
function nonNegativeInteger(value,name){
 const n=Number(value||0);if(!Number.isInteger(n)||n<0)throw Error(`${name} 必须是非负整数`);return n
}
function insertSimulatedTestData(userId,body,adminId){
 const bonusCount=nonNegativeInteger(body.test_bonus_completed,'福利单完成数量');
 const luckyCount=nonNegativeInteger(body.test_lucky_completed,'幸运阶段完成数量');
 const bonusAmount=nonNegativeNumber(body.bonus_amount||10000,'福利单金额');
 const bonusCommission=nonNegativeNumber(body.bonus_commission||500,'福利单佣金');
 const luckyTotal=Math.max(1,nonNegativeInteger(body.lucky_total_steps||3,'幸运连单阶段数'));
 const luckyAmount=nonNegativeNumber(body.lucky_step_amount||10000,'幸运阶段金额');
 const luckyCommission=nonNegativeNumber(body.lucky_step_commission||500,'幸运阶段佣金');

 const orderQ=db.prepare(`INSERT INTO orders(
  id,user_id,order_type,amount_inr,commission_rate,commission_inr,extra_reward_usdt,
  status,note,created_by,created_at,accepted_at,confirmed_at,completed_at
 ) VALUES(?,?,?,?,0,?,0,'COMPLETED','SIMULATED TEST DATA',?,?,?,?,?)`);
 for(let i=0;i<bonusCount;i++){
  const id=makeId('TBO'),ts=now();
  orderQ.run(id,userId,'BONUS',bonusAmount,bonusCommission,adminId,ts,ts,ts,ts);
 }

 if(luckyCount>0){
  const total=Math.max(luckyTotal,luckyCount),seriesId=makeId('TLS'),ts=now();
  db.prepare(`INSERT INTO lucky_series(
   id,user_id,title,status,current_step,total_steps,auto_popup,allow_close,note,created_by,created_at,joined_at,completed_at
  ) VALUES(?,?,'Simulated Lucky Series',?, ?, ?,0,1,'SIMULATED TEST DATA',?,?,?,?)`)
  .run(seriesId,userId,luckyCount>=total?'COMPLETED':'PARTICIPATING',Math.min(luckyCount+1,total),total,adminId,ts,ts,luckyCount>=total?ts:null);
  const stepQ=db.prepare(`INSERT INTO lucky_series_steps(
   series_id,step_no,amount_inr,commission_inr,commission_rate,extra_reward_usdt,
   status,accepted_at,completed_at,locked_amount
  ) VALUES(?,?,?,?,0,0,?,?,?,0)`);
  for(let step=1;step<=total;step++){
   const completed=step<=luckyCount;
   const status=completed?'COMPLETED':step===luckyCount+1?'AVAILABLE':'LOCKED';
   stepQ.run(seriesId,step,luckyAmount,luckyCommission,status,completed?ts:null,completed?ts:null);
  }
 }
}
r.get('/test-accounts',(req,res)=>{
 const accounts=db.prepare(`SELECT u.*,l.name_zh AS level_name
  FROM users u LEFT JOIN member_levels l ON l.id=u.member_level_id
  WHERE u.role='user' AND u.is_test_account=1 ORDER BY u.id DESC`).all();
 res.json({accounts})
});
r.post('/test-accounts',(req,res)=>{
 try{
  const b=req.body||{},username=String(b.username||'').trim(),password=String(b.password||''),displayName=String(b.display_name||'').trim();
  if(!/^[A-Za-z0-9_.-]{4,32}$/.test(username))throw Error('测试账号必须是4-32位字母、数字、点、横线或下划线');
  if(password.length<6)throw Error('测试账号密码至少6位');
  if(!displayName)throw Error('请输入测试账号名称');
  const levelId=Number(b.member_level_id);
  if(!db.prepare('SELECT id FROM member_levels WHERE id=? AND enabled=1').get(levelId))throw Error('会员等级不存在或未启用');
  if(db.prepare('SELECT id FROM users WHERE username=? COLLATE NOCASE').get(username))throw Error('账号已存在');
  const tx=db.transaction(()=>{
   const referral='TEST'+makeId('').replace(/[^A-Z0-9]/gi,'').slice(-8).toUpperCase();
   const principal=nonNegativeNumber(b.balance_inr,'模拟本金');
   const commission=nonNegativeNumber(b.commission_wallet_inr,'模拟彩金');
   const usdt=nonNegativeNumber(b.reward_usdt,'模拟USDT');
   const q=db.prepare(`INSERT INTO users(
    username,password_hash,display_name,referral_code,role,status,member_level_id,
    balance_inr,commission_wallet_inr,reward_usdt,is_test_account,
    test_today_commission,test_today_income,test_bonus_completed,test_lucky_completed,created_at
   ) VALUES(?,?,?,?,'user','ACTIVE',?,0,0,0,1,?,?,?,?,?)`).run(
    username,bcrypt.hashSync(password,12),displayName,referral,levelId,
    nonNegativeNumber(b.test_today_commission,'今日佣金'),
    nonNegativeNumber(b.test_today_income,'今日收益'),
    nonNegativeInteger(b.test_bonus_completed,'福利单完成数量'),
    nonNegativeInteger(b.test_lucky_completed,'幸运阶段完成数量'),
    now()
   );
   const userId=q.lastInsertRowid;
   for(const [walletKey,amount] of [['PRINCIPAL',principal],['COMMISSION',commission],['USDT',usdt]]){
    if(amount>0)walletService.credit({
     userId,walletKey,amount,entryType:'TEST_ACCOUNT_INITIAL',
     referenceType:'TEST_ACCOUNT',referenceId:String(userId),
     note:'Initial simulated test-account balance',operator:req.session.user.username
    });
   }
   insertSimulatedTestData(userId,b,req.session.user.id);
   return userId
  });
  const id=tx();audit(req,'CREATE_TEST_ACCOUNT','USER',id,{username,member_level_id:levelId});
  res.json({ok:true,id,account:testAccountRow(id),message:'测试账号创建成功'})
 }catch(e){res.status(400).json({error:e.message})}
});
r.put('/test-accounts/:id',(req,res)=>{
 try{
  const id=Number(req.params.id),existing=testAccountRow(id);if(!existing)throw Error('测试账号不存在');
  const b=req.body||{},status=String(b.status||existing.status).toUpperCase();
  if(!['ACTIVE','DISABLED','SUSPENDED'].includes(status))throw Error('测试账号状态无效');
  const values={
   balance_inr:nonNegativeNumber(b.balance_inr??existing.balance_inr,'模拟本金'),
   commission_wallet_inr:nonNegativeNumber(b.commission_wallet_inr??existing.commission_wallet_inr,'模拟彩金'),
   reward_usdt:nonNegativeNumber(b.reward_usdt??existing.reward_usdt,'模拟USDT'),
   test_today_commission:nonNegativeNumber(b.test_today_commission??existing.test_today_commission,'今日佣金'),
   test_today_income:nonNegativeNumber(b.test_today_income??existing.test_today_income,'今日收益'),
   test_bonus_completed:nonNegativeInteger(b.test_bonus_completed??existing.test_bonus_completed,'福利单完成数量'),
   test_lucky_completed:nonNegativeInteger(b.test_lucky_completed??existing.test_lucky_completed,'幸运阶段完成数量')
  };
  const tx=db.transaction(()=>{
   const walletTargets=[
    ['PRINCIPAL',values.balance_inr-Number(existing.balance_inr||0)],
    ['COMMISSION',values.commission_wallet_inr-Number(existing.commission_wallet_inr||0)],
    ['USDT',values.reward_usdt-Number(existing.reward_usdt||0)]
   ];
   for(const [walletKey,delta] of walletTargets){
    if(delta!==0)walletService.changeWallet({
     userId:id,walletKey,amount:delta,entryType:'TEST_ACCOUNT_ADJUST',
     referenceType:'TEST_ACCOUNT',referenceId:String(id),
     note:'Simulated test-account balance update',operator:req.session.user.username,
     allowNegative:false
    });
   }
   db.prepare(`UPDATE users SET
    test_today_commission=?,test_today_income=?,test_bonus_completed=?,test_lucky_completed=?,
    status=?,receiving_enabled=0 WHERE id=? AND role='user' AND is_test_account=1`)
   .run(values.test_today_commission,values.test_today_income,values.test_bonus_completed,
    values.test_lucky_completed,status,id);
  });
  tx();
  audit(req,'UPDATE_TEST_ACCOUNT','USER',id,{before:{status:existing.status,balance_inr:existing.balance_inr,commission_wallet_inr:existing.commission_wallet_inr,reward_usdt:existing.reward_usdt},after:{status,...values}});
  res.json({ok:true,account:testAccountRow(id),message:'测试账号保存成功'})
 }catch(e){res.status(400).json({error:e.message})}
});
r.delete('/test-accounts/:id',(req,res)=>{
 try{
  const id=Number(req.params.id),existing=testAccountRow(id);if(!existing)throw Error('测试账号不存在');
  const tx=db.transaction(()=>{
   const series=db.prepare('SELECT id FROM lucky_series WHERE user_id=?').all(id).map(x=>x.id);
   const delSteps=db.prepare('DELETE FROM lucky_series_steps WHERE series_id=?');
   series.forEach(x=>delSteps.run(x));
   db.prepare('DELETE FROM lucky_series WHERE user_id=?').run(id);
   db.prepare('DELETE FROM wallet_ledger WHERE user_id=?').run(id);
   db.prepare('DELETE FROM messages WHERE user_id=?').run(id);
   db.prepare('DELETE FROM payment_accounts WHERE user_id=?').run(id);
   db.prepare('DELETE FROM deposits WHERE user_id=?').run(id);
   db.prepare('DELETE FROM withdrawals WHERE user_id=?').run(id);
   db.prepare('DELETE FROM orders WHERE user_id=?').run(id);
   db.prepare('DELETE FROM users WHERE id=? AND role=\'user\' AND is_test_account=1').run(id);
  });
  tx();audit(req,'DELETE_TEST_ACCOUNT','USER',id,{username:existing.username});
  res.json({ok:true,message:'测试账号已删除'})
 }catch(e){res.status(400).json({error:e.message})}
});

r.get('/levels',(req,res)=>res.json({levels:db.prepare('SELECT * FROM member_levels ORDER BY sort_order,id').all()}));
r.put('/levels/:id',(req,res)=>{db.prepare('UPDATE member_levels SET name_zh=?,name_en=?,name_hi=?,daily_limit_inr=?,commission_rate=?,enabled=?,sort_order=? WHERE id=?').run(req.body.name_zh,req.body.name_en,req.body.name_hi,Number(req.body.daily_limit_inr),Number(req.body.commission_rate),req.body.enabled?1:0,Number(req.body.sort_order),req.params.id);res.json({ok:true,message:'会员等级保存成功'})});
r.get('/orders',(req,res)=>res.json({orders:db.prepare('SELECT o.*,u.username,u.display_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC').all()}));
r.get('/users/:id/payment-accounts',(req,res)=>{const eligible=String(req.query.eligible||'')==='1';const sql=`SELECT * FROM payment_accounts WHERE user_id=? ${eligible?"AND status='VERIFIED' AND receiving_enabled=1":''} ORDER BY is_default DESC,id DESC`;res.json({accounts:db.prepare(sql).all(req.params.id)})});
r.post('/orders',(req,res)=>{try{const b=req.body,u=db.prepare("SELECT * FROM users WHERE id=? AND role='user' AND is_test_account=0").get(Number(b.user_id));if(!u)throw Error('User not found');const amount=Number(b.amount_inr),rate=Number(b.commission_rate||0),fixed=Number(b.commission_inr||0),reward=Number(b.extra_reward_usdt||0);if(!(amount>0)||rate<0||fixed<0||reward<0)throw Error('Invalid order amounts');const commission=fixed>0?fixed:Number((amount*rate/100).toFixed(2));if(!(commission>0))throw Error('Fixed commission or commission rate is required');const acct=db.prepare('SELECT * FROM payment_accounts WHERE id=? AND user_id=?').get(Number(b.payment_account_id),u.id);if(!acct)throw Error('Please select a payment account belonging to this user');if(acct.status!=='VERIFIED'||!acct.receiving_enabled)throw Error('Selected payment account is not eligible');const snapshot=JSON.stringify({remark:acct.remark,type:acct.account_type,holder_name:acct.holder_name,bank_name:acct.bank_name,account_value:acct.account_value,ifsc:acct.ifsc,provider:acct.provider});const id=makeId(b.order_type==='LUCKY'?'LUK':b.order_type==='BONUS'?'BON':'ORD');db.prepare('INSERT INTO orders(id,user_id,order_type,amount_inr,commission_rate,commission_inr,extra_reward_usdt,payment_method,payment_account_id,payment_account_remark,payment_account_type,payment_account_snapshot,series_current,series_total,status,note,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,u.id,b.order_type,amount,rate,commission,reward,acct.account_type,acct.id,acct.remark,acct.account_type,snapshot,b.series_current||null,b.series_total||null,'PENDING',b.note||'',req.session.user.id,now());message(u.id,'ORDER','New order assigned','नया ऑर्डर मिला',b.order_type==='LUCKY'?'A Lucky Event invitation was assigned.':'A new order was assigned.',b.order_type==='LUCKY'?'एक लकी इवेंट आमंत्रण दिया गया है।':'एक नया ऑर्डर दिया गया है।');res.json({ok:true,id,commission_inr:commission,message:'订单派发成功'})}catch(e){res.status(400).json({error:e.message})}});
r.post('/orders/:id/cancel',(req,res)=>{const tx=db.transaction(()=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);if(!o||['COMPLETED','CANCELLED'].includes(o.status))throw Error('Order cannot be cancelled');const u=db.prepare('SELECT * FROM users WHERE id=?').get(o.user_id);if(o.order_type!=='LUCKY'&&o.status==='PROCESSING'){const amount=Number(o.amount_inr);walletService.releasePrincipal({userId:u.id,amount,referenceType:'ORDER',referenceId:o.id,note:'Order cancelled; principal returned'})}db.prepare("UPDATE orders SET status='CANCELLED' WHERE id=?").run(o.id)});try{tx();res.json({ok:true,message:'订单已取消'})}catch(e){res.status(400).json({error:e.message})}});
r.post('/orders/:id/complete',(req,res)=>{const tx=db.transaction(()=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);if(!o)throw Error('Order not found');if(!['PARTICIPATING','PROCESSING'].includes(o.status))throw Error('Order cannot be completed');const u=db.prepare('SELECT * FROM users WHERE id=?').get(o.user_id),comm=Number(o.commission_inr),reward=Number(o.extra_reward_usdt);if(o.order_type!=='LUCKY')walletService.consumeLocked({userId:u.id,amount:Number(o.amount_inr),referenceType:'ORDER',referenceId:o.id,note:'Order principal consumed',operator:req.session.user.username});if(comm>0){walletService.credit({userId:u.id,walletKey:'COMMISSION',amount:comm,entryType:'ORDER_COMMISSION',referenceType:'ORDER',referenceId:o.id,note:'Commission credited',operator:req.session.user.username});db.prepare('UPDATE users SET commission_total_inr=commission_total_inr+? WHERE id=?').run(comm,u.id)}if(reward>0)walletService.credit({userId:u.id,walletKey:'USDT',amount:reward,entryType:'ORDER_REWARD',referenceType:'ORDER',referenceId:o.id,note:'Reward credited',operator:req.session.user.username});db.prepare("UPDATE orders SET status='COMPLETED',completed_at=? WHERE id=?").run(now(),o.id)});try{tx();res.json({ok:true,message:'订单完成并已结算'})}catch(e){res.status(400).json({error:e.message})}});
r.get('/payment-accounts',(req,res)=>res.json({accounts:db.prepare('SELECT p.*,u.username FROM payment_accounts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC').all()}));
r.put('/payment-accounts/:id/review',(req,res)=>{const status=req.body.status;if(!['VERIFIED','REJECTED','FROZEN'].includes(status))return res.status(400).json({error:'Invalid status'});db.prepare('UPDATE payment_accounts SET status=?,receiving_enabled=?,reviewed_at=?,reviewed_by=?,reject_reason=? WHERE id=?').run(status,status==='VERIFIED'?1:0,now(),req.session.user.id,req.body.reject_reason||'',req.params.id);res.json({ok:true,message:'支付账户状态已保存'})});
r.put('/payment-accounts/:id/receiving',(req,res)=>{db.prepare('UPDATE payment_accounts SET receiving_enabled=? WHERE id=?').run(req.body.enabled?1:0,req.params.id);res.json({ok:true,message:'账户接单开关已保存'})});
r.get('/deposits',(req,res)=>res.json({deposits:db.prepare('SELECT d.*,u.username,u.display_name FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC').all()}));
r.post('/deposits/manual',(req,res)=>{const id=makeId('DEP');db.prepare("INSERT INTO deposits(id,user_id,method,requested_amount,reference_no,proof_note,status,created_at) VALUES(?,?,?,?,?,?,'PENDING',?)").run(id,req.body.user_id,req.body.method,Number(req.body.requested_amount),req.body.reference_no||'',req.body.proof_note||'',now());res.json({ok:true,id,message:'充值订单创建成功'})});
r.post('/deposits/:id/credit',(req,res)=>{const tx=db.transaction(()=>{const d=db.prepare('SELECT * FROM deposits WHERE id=?').get(req.params.id);if(!d||d.status!=='PENDING')throw Error('Deposit cannot be credited');const actual=Number(req.body.actual_amount),bonus=Number(req.body.bonus_amount||0),credited=actual+bonus;if(!(actual>0)||bonus<0)throw Error('Invalid deposit amount');db.prepare("UPDATE deposits SET actual_amount=?,bonus_amount=?,credited_amount=?,status='COMPLETED',reviewed_at=?,reviewed_by=? WHERE id=? AND status='PENDING'").run(actual,bonus,credited,now(),req.session.user.id,d.id);return walletService.credit({userId:d.user_id,walletKey:'PRINCIPAL',amount:credited,entryType:'DEPOSIT_CREDIT',referenceType:'DEPOSIT',referenceId:d.id,note:'Deposit approved',operator:req.session.user.username})});try{const x=tx();res.json({ok:true,before:x.before,credited:x.amount,after:x.after,message:'充值上分成功'})}catch(e){res.status(400).json({error:e.message})}});
r.post('/deposits/:id/reject',(req,res)=>{db.prepare("UPDATE deposits SET status='REJECTED',reviewed_at=?,reviewed_by=?,reject_reason=? WHERE id=? AND status='PENDING'").run(now(),req.session.user.id,req.body.reason||'',req.params.id);res.json({ok:true,message:'充值订单已拒绝'})});
r.get('/withdrawals',(req,res)=>res.json({withdrawals:db.prepare('SELECT w.*,u.username,u.display_name FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC').all()}));
r.put('/withdrawals/:id/status',(req,res)=>{const tx=db.transaction(()=>{const w=db.prepare('SELECT * FROM withdrawals WHERE id=?').get(req.params.id);if(!w)throw Error('Withdrawal not found');const status=String(req.body.status||'');if(!['APPROVED','PROCESSING','COMPLETED','REJECTED'].includes(status))throw Error('Invalid status');if(status==='REJECTED'&&!['REJECTED','COMPLETED'].includes(w.status)){const u=db.prepare('SELECT * FROM users WHERE id=?').get(w.user_id),source=String(w.source_wallet||'PRINCIPAL').toUpperCase();walletService.credit({userId:u.id,walletKey:source==='COMMISSION'?'COMMISSION':'PRINCIPAL',amount:Number(w.amount),entryType:'WITHDRAW_RETURN',referenceType:'WITHDRAWAL',referenceId:w.id,note:'Withdrawal rejected and returned'})}db.prepare('UPDATE withdrawals SET status=?,reviewed_at=?,reviewed_by=?,reject_reason=? WHERE id=?').run(status,now(),req.session.user.id,req.body.reason||'',w.id)});try{tx();res.json({ok:true,message:'提款状态保存成功'})}catch(e){res.status(400).json({error:e.message})}});
r.get('/reports/deposits-daily',(req,res)=>res.json({rows:db.prepare("SELECT date(datetime(COALESCE(reviewed_at,created_at)),'+5 hours','+30 minutes') report_date,COUNT(*) orders_count,COUNT(DISTINCT user_id) users_count,COALESCE(SUM(requested_amount),0) requested_total,COALESCE(SUM(actual_amount),0) actual_total,COALESCE(SUM(bonus_amount),0) bonus_total,COALESCE(SUM(credited_amount),0) credited_total FROM deposits WHERE status='COMPLETED' GROUP BY report_date ORDER BY report_date DESC LIMIT 365").all()}));
r.post('/uploads/banner',upload.single('image'),(req,res)=>{if(!req.file)return res.status(400).json({error:'Image required'});res.json({ok:true,url:`/uploads/banners/${req.file.filename}`})});
r.get('/banners',(req,res)=>res.json({banners:db.prepare('SELECT * FROM banners ORDER BY sort_order,id').all()}));
r.post('/banners',(req,res)=>{const b=req.body,q=db.prepare('INSERT INTO banners(position,title_en,title_hi,subtitle_en,subtitle_hi,button_en,button_hi,target,theme,sort_order,enabled,start_at,end_at,image_url,mobile_image_url,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(b.position||'HOME',b.title_en,b.title_hi,b.subtitle_en||'',b.subtitle_hi||'',b.button_en||'',b.button_hi||'',b.target||'',b.theme||'purple',Number(b.sort_order||0),b.enabled?1:0,b.start_at||null,b.end_at||null,b.image_url||'',b.mobile_image_url||'',now());res.json({ok:true,id:q.lastInsertRowid,message:'轮播图保存成功'})});
r.put('/banners/:id',(req,res)=>{const b=req.body;db.prepare('UPDATE banners SET position=?,title_en=?,title_hi=?,subtitle_en=?,subtitle_hi=?,button_en=?,button_hi=?,target=?,theme=?,sort_order=?,enabled=?,start_at=?,end_at=?,image_url=?,mobile_image_url=? WHERE id=?').run(b.position,b.title_en,b.title_hi,b.subtitle_en||'',b.subtitle_hi||'',b.button_en||'',b.button_hi||'',b.target||'',b.theme||'purple',Number(b.sort_order||0),b.enabled?1:0,b.start_at||null,b.end_at||null,b.image_url||'',b.mobile_image_url||'',req.params.id);res.json({ok:true,message:'轮播图保存成功'})});
r.delete('/banners/:id',(req,res)=>{db.prepare('DELETE FROM banners WHERE id=?').run(req.params.id);res.json({ok:true,message:'轮播图已删除'})});
r.put('/company',(req,res)=>{const b=req.body;db.prepare('UPDATE company_profile SET company_name=?,profile_en=?,profile_hi=?,qualifications=?,office_info=?,partners=?,updated_at=? WHERE id=1').run(b.company_name||'',b.profile_en||'',b.profile_hi||'',b.qualifications||'',b.office_info||'',b.partners||'',now());res.json({ok:true,message:'公司资料保存成功'})});
r.get('/contacts',(req,res)=>res.json({contacts:db.prepare('SELECT * FROM contacts ORDER BY sort_order,id').all()}));
r.put('/contacts/:id',(req,res)=>{db.prepare('UPDATE contacts SET label_en=?,label_hi=?,url=?,enabled=?,sort_order=? WHERE id=?').run(req.body.label_en,req.body.label_hi,req.body.url||'',req.body.enabled?1:0,Number(req.body.sort_order||0),req.params.id);res.json({ok:true,message:'联系方式保存成功'})});
r.get('/announcements',(req,res)=>res.json({announcements:db.prepare('SELECT * FROM announcements ORDER BY sort_order,id DESC').all()}));
r.post('/announcements',(req,res)=>{const b=req.body,q=db.prepare(`INSERT INTO announcements(
 title_en,title_hi,title_zh,content_en,content_hi,content_zh,display_type,sort_order,enabled,start_at,end_at,
 button_en,button_hi,button_zh,image_url,auto_popup,allow_close,target,created_at,updated_at
) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
 b.title_en||'',b.title_hi||'',b.title_zh||'',b.content_en||'',b.content_hi||'',b.content_zh||'',
 b.display_type||'MARQUEE',Number(b.sort_order||0),b.enabled?1:0,b.start_at||null,b.end_at||null,
 b.button_en||'View More',b.button_hi||'और देखें',b.button_zh||'查看更多',b.image_url||'',
 b.auto_popup===false?0:1,b.allow_close===false?0:1,b.target||'',now(),now()
);res.json({ok:true,id:q.lastInsertRowid,message:'公告保存成功'})});
r.put('/announcements/:id',(req,res)=>{const b=req.body;db.prepare(`UPDATE announcements SET
 title_en=?,title_hi=?,title_zh=?,content_en=?,content_hi=?,content_zh=?,display_type=?,sort_order=?,enabled=?,
 start_at=?,end_at=?,button_en=?,button_hi=?,button_zh=?,image_url=?,auto_popup=?,allow_close=?,target=?,updated_at=?
 WHERE id=?`).run(
 b.title_en||'',b.title_hi||'',b.title_zh||'',b.content_en||'',b.content_hi||'',b.content_zh||'',
 b.display_type||'MARQUEE',Number(b.sort_order||0),b.enabled?1:0,b.start_at||null,b.end_at||null,
 b.button_en||'View More',b.button_hi||'और देखें',b.button_zh||'查看更多',b.image_url||'',
 b.auto_popup===false?0:1,b.allow_close===false?0:1,b.target||'',now(),req.params.id
);res.json({ok:true,message:'公告保存成功'})});
r.delete('/announcements/:id',(req,res)=>{db.prepare('DELETE FROM announcements WHERE id=?').run(req.params.id);res.json({ok:true,message:'公告已删除'})});

r.get('/wallet-settings',(req,res)=>res.json(settingsService.walletSettings()));
r.put('/wallet-settings',(req,res)=>{try{const before=settingsService.walletSettings(),after=settingsService.saveWalletSettings(req.body||{});audit(req,'UPDATE_WALLET_SETTINGS','SYSTEM_SETTINGS','wallet-settings',{before,after});res.json({ok:true,message:'钱包与充值设置保存成功'})}catch(e){res.status(400).json({error:e.message})}});
r.get('/settings',(req,res)=>res.json({min_withdraw_amount:Number(db.setting('min_withdraw_amount','500')),withdraw_enabled:db.setting('withdraw_enabled','true')==='true',principal_withdraw_enabled:db.setting('principal_withdraw_enabled','true')==='true',commission_withdraw_enabled:db.setting('commission_withdraw_enabled','true')==='true',withdraw_fee_percent:0,registration_enabled:db.setting('registration_enabled','true')==='true',register_show_display_name:db.setting('register_show_display_name','true')==='true',register_require_display_name:db.setting('register_require_display_name','true')==='true',register_show_phone:db.setting('register_show_phone','true')==='true',register_require_phone:db.setting('register_require_phone','true')==='true',register_show_email:db.setting('register_show_email','true')==='true',register_require_email:db.setting('register_require_email','false')==='true',register_show_referral:db.setting('register_show_referral','true')==='true',register_require_referral:db.setting('register_require_referral','false')==='true'}));
r.put('/settings',(req,res)=>{const bool=v=>v?'true':'false',vals={min_withdraw_amount:String(Math.max(0,Number(req.body.min_withdraw_amount||0))),withdraw_enabled:bool(req.body.withdraw_enabled),principal_withdraw_enabled:bool(req.body.principal_withdraw_enabled),commission_withdraw_enabled:bool(req.body.commission_withdraw_enabled),registration_enabled:bool(req.body.registration_enabled),register_show_display_name:bool(req.body.register_show_display_name),register_require_display_name:bool(req.body.register_show_display_name&&req.body.register_require_display_name),register_show_phone:bool(req.body.register_show_phone),register_require_phone:bool(req.body.register_show_phone&&req.body.register_require_phone),register_show_email:bool(req.body.register_show_email),register_require_email:bool(req.body.register_show_email&&req.body.register_require_email),register_show_referral:bool(req.body.register_show_referral),register_require_referral:bool(req.body.register_show_referral&&req.body.register_require_referral)};const q=db.prepare('INSERT INTO system_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at');Object.entries(vals).forEach(([k,v])=>q.run(k,v,now()));res.json({ok:true,message:'系统与注册设置保存成功'})});
r.post('/messages',(req,res)=>{const b=req.body;if(b.user_id)message(Number(b.user_id),b.category||'SYSTEM',b.title_en,b.title_hi,b.body_en,b.body_hi);else db.prepare("SELECT id FROM users WHERE role='user' AND is_test_account=0").all().forEach(u=>message(u.id,b.category||'SYSTEM',b.title_en,b.title_hi,b.body_en,b.body_hi));res.json({ok:true,message:'站内信发送成功'})});
r.get('/audit-logs',(req,res)=>res.json({logs:db.prepare('SELECT a.*,u.username admin_username FROM audit_logs a LEFT JOIN users u ON u.id=a.admin_id ORDER BY a.id DESC LIMIT 500').all()}));
r.use((err,req,res,next)=>{if(err?.code==='LIMIT_FILE_SIZE')return res.status(400).json({error:'图片不能超过8MB'});if(err)return res.status(400).json({error:err.message||'上传失败'});next()});
module.exports=r;
