"use strict";
const r=require('express').Router();
const db=require('../lib/db');
const {auth,admin,permission}=require('../lib/auth');
const {now,makeId}=require('../lib/utils');
const {message,audit}=require('../services/common');
const wallet=require('../services/wallet-service');
const {
 getMemberSeries,getAdminSeries,listMemberSeries,listAdminSeries
}=require('../services/lucky-series-service');

function apiError(res,error){
 const status=Number(error.statusCode||400);
 res.status(status).json({ok:false,error:error.message||'Lucky Series operation failed',code:error.code||'LUCKY_OPERATION_FAILED'});
}

function requireMember(userId){
 const user=db.prepare("SELECT * FROM users WHERE id=? AND role='user'").get(userId);
 if(!user)throw Object.assign(new Error('会员账号不存在'),{code:'MEMBER_NOT_FOUND'});
 return user;
}
function requireActiveMember(userId){
 const user=requireMember(userId);
 if(user.status!=='ACTIVE')throw Object.assign(new Error('会员账号当前不可用'),{code:'MEMBER_UNAVAILABLE'});
 return user;
}

function requireSeries(seriesId,userId=null){
 const series=userId===null
  ?db.prepare('SELECT * FROM lucky_series WHERE id=?').get(seriesId)
  :db.prepare('SELECT * FROM lucky_series WHERE id=? AND user_id=?').get(seriesId,userId);
 if(!series)throw Object.assign(new Error('幸运连单不存在'),{code:'SERIES_NOT_FOUND'});
 return series;
}

function requireCurrentStep(series,status){
 const step=db.prepare('SELECT * FROM lucky_series_steps WHERE series_id=? AND step_no=?').get(series.id,series.current_step);
 if(!step)throw Object.assign(new Error('当前阶段数据不存在'),{code:'CURRENT_STEP_MISSING'});
 if(status&&step.status!==status){
  const error=new Error(`当前阶段状态为 ${step.status}，无法执行该操作`);
  error.code='INVALID_STEP_STATUS';
  throw error;
 }
 return step;
}

function lockCurrentStep(user,series,step){
 const amount=Number(step.amount_inr);
 if(!(amount>0))throw Object.assign(new Error('当前阶段金额无效'),{code:'INVALID_STAGE_AMOUNT'});
 try{
  wallet.lockPrincipal({
   userId:user.id,
   amount,
   referenceType:'LUCKY_SERIES',
   referenceId:series.id,
   note:`Lucky stage ${step.step_no} principal locked`
  });
 }catch(error){
  if(error.code==='INSUFFICIENT_PRINCIPAL'){
   const e=new Error(`当前阶段余额不足。需要 ₹${error.required.toFixed(2)}，可用 ₹${error.available.toFixed(2)}，还差 ₹${error.shortfall.toFixed(2)}`);
   e.code='INSUFFICIENT_PRINCIPAL';
   e.required=error.required;
   e.available=error.available;
   e.shortfall=error.shortfall;
   throw e;
  }
  throw error;
 }
 db.prepare(`UPDATE lucky_series_steps
  SET status='IN_PROGRESS',locked_amount=?,accepted_at=?,cancelled_at=''
  WHERE id=? AND status='AVAILABLE'`).run(amount,now(),step.id);
}

function settleCurrentStep(req,series,step,user){
 const locked=Number(step.locked_amount||0);
 const commission=Number(step.commission_inr||0);
 const reward=Number(step.extra_reward_usdt||0);

 if(locked>0)wallet.releasePrincipal({
  userId:user.id,amount:locked,
  referenceType:'LUCKY_SERIES',referenceId:series.id,
  note:`Lucky stage ${step.step_no} principal returned`
 });
 if(commission>0){
  wallet.credit({
   userId:user.id,walletKey:'COMMISSION',amount:commission,
   entryType:'LUCKY_SERIES_COMMISSION',
   referenceType:'LUCKY_SERIES',referenceId:series.id,
   note:`Lucky stage ${step.step_no} commission credited`
  });
  db.prepare('UPDATE users SET commission_total_inr=commission_total_inr+? WHERE id=?').run(commission,user.id);
 }
 if(reward>0)wallet.credit({
  userId:user.id,walletKey:'USDT',amount:reward,
  entryType:'LUCKY_SERIES_REWARD',
  referenceType:'LUCKY_SERIES',referenceId:series.id,
  note:`Lucky stage ${step.step_no} USDT reward credited`
 });

 const completedAt=now();
 db.prepare(`UPDATE lucky_series_steps
  SET status='COMPLETED',locked_amount=0,completed_at=?
  WHERE id=? AND status='IN_PROGRESS'`).run(completedAt,step.id);

 const finalStage=Number(series.current_step)>=Number(series.total_steps);
 if(finalStage){
  db.prepare(`UPDATE lucky_series
   SET status='COMPLETED',completed_at=?
   WHERE id=? AND status='PARTICIPATING'`).run(completedAt,series.id);
 }else{
  const nextStep=Number(series.current_step)+1;
  db.prepare(`UPDATE lucky_series
   SET current_step=?
   WHERE id=? AND status='PARTICIPATING'`).run(nextStep,series.id);
  const unlocked=db.prepare(`UPDATE lucky_series_steps
   SET status='AVAILABLE'
   WHERE series_id=? AND step_no=? AND status='LOCKED'`).run(series.id,nextStep);
  if(unlocked.changes!==1)throw Object.assign(new Error('下一阶段解锁失败，结算已回滚'),{code:'NEXT_STAGE_UNLOCK_FAILED'});
 }

 audit(req,'COMPLETE_LUCKY_STEP','LUCKY_SERIES',series.id,{
  step:step.step_no,
  final_stage:finalStage,
  principal_released:locked,
  commission,
  reward
 });
 return{finalStage,locked,commission,reward};
}

/* Member APIs */
r.get('/lucky-series',auth,(req,res)=>{
 try{res.json({ok:true,series:listMemberSeries(req.session.user.id)})}
 catch(error){apiError(res,error)}
});

r.get('/lucky-series/:id',auth,(req,res)=>{
 try{
  const series=getMemberSeries(req.params.id,req.session.user.id);
  if(!series)throw Object.assign(new Error('幸运连单不存在'),{code:'SERIES_NOT_FOUND'});
  res.json({ok:true,series});
 }catch(error){apiError(res,error)}
});

r.post('/lucky-series/:id/join',auth,(req,res)=>{
 try{
  const result=db.transaction(()=>{
   const series=requireSeries(req.params.id,req.session.user.id);
   if(series.status!=='PENDING')throw Object.assign(new Error('当前幸运连单不能重复参加'),{code:'SERIES_NOT_PENDING'});
   requireActiveMember(req.session.user.id);

   const first=db.prepare('SELECT * FROM lucky_series_steps WHERE series_id=? AND step_no=1').get(series.id);
   if(!first)throw Object.assign(new Error('幸运连单缺少第一阶段'),{code:'FIRST_STAGE_MISSING'});

   db.prepare(`UPDATE lucky_series
    SET status='PARTICIPATING',current_step=1,joined_at=?,completed_at=NULL
    WHERE id=? AND status='PENDING'`).run(now(),series.id);
   db.prepare(`UPDATE lucky_series_steps
    SET status=CASE WHEN step_no=1 THEN 'AVAILABLE' ELSE 'LOCKED' END,
        accepted_at='',completed_at=NULL,cancelled_at='',locked_amount=0
    WHERE series_id=? AND status<>'COMPLETED'`).run(series.id);

   return getMemberSeries(series.id,req.session.user.id);
  })();

  res.json({
   ok:true,
   status:'PARTICIPATING',
   message:'幸运连单参加成功。参加时不会检查余额，请在余额充足后开始第一阶段。',
   series:result
  });
 }catch(error){apiError(res,error)}
});

r.post('/lucky-series/:id/start-current',auth,(req,res)=>{
 try{
  const result=db.transaction(()=>{
   const series=requireSeries(req.params.id,req.session.user.id);
   if(series.status!=='PARTICIPATING')throw Object.assign(new Error('请先参加幸运连单'),{code:'SERIES_NOT_PARTICIPATING'});
   const user=requireActiveMember(req.session.user.id);
   const step=requireCurrentStep(series,'AVAILABLE');

   if(user.is_test_account){
    db.prepare(`UPDATE lucky_series_steps
     SET status='IN_PROGRESS',accepted_at=?,locked_amount=0
     WHERE id=? AND status='AVAILABLE'`).run(now(),step.id);
   }else{
    lockCurrentStep(user,series,step);
   }
   return getMemberSeries(series.id,user.id);
  })();

  res.json({
   ok:true,
   message:`第 ${result.current_step} 阶段已开始，等待平台确认完成`,
   series:result
  });
 }catch(error){apiError(res,error)}
});

/* Administrator APIs */
r.get('/admin/lucky-series',admin,permission('lucky_series'),(req,res)=>{
 try{res.json({ok:true,series:listAdminSeries()})}
 catch(error){apiError(res,error)}
});

r.get('/admin/lucky-series/:id',admin,permission('lucky_series'),(req,res)=>{
 try{
  const series=getAdminSeries(req.params.id);
  if(!series)throw Object.assign(new Error('幸运连单不存在'),{code:'SERIES_NOT_FOUND'});
  res.json({ok:true,series});
 }catch(error){apiError(res,error)}
});

r.post('/admin/lucky-series',admin,permission('lucky_series'),(req,res)=>{
 try{
  const result=db.transaction(()=>{
   const body=req.body||{};
   const steps=Array.isArray(body.steps)?body.steps:[];
   const username=String(body.username||'').trim();
   const user=db.prepare(`SELECT * FROM users
    WHERE username=? COLLATE NOCASE AND role='user' AND is_test_account=0`).get(username);

   if(!user)throw Object.assign(new Error('真实会员账号不存在'),{code:'MEMBER_NOT_FOUND'});
   if(user.status!=='ACTIVE')throw Object.assign(new Error('会员账号当前不可用'),{code:'MEMBER_UNAVAILABLE'});
   if(!steps.length)throw Object.assign(new Error('至少需要一个幸运阶段'),{code:'STEPS_REQUIRED'});
   if(steps.length>20)throw Object.assign(new Error('幸运阶段最多 20 个'),{code:'TOO_MANY_STEPS'});

   const normalized=steps.map((raw,index)=>{
    const amount=Number(raw.amount_inr);
    const fixed=Number(raw.commission_inr||0);
    const rate=Number(raw.commission_rate||0);
    const reward=Number(raw.extra_reward_usdt||0);
    if(!(amount>0))throw Object.assign(new Error(`第 ${index+1} 阶段金额无效`),{code:'INVALID_STAGE_AMOUNT'});
    if(fixed<0||rate<0||reward<0)throw Object.assign(new Error(`第 ${index+1} 阶段数据不能为负数`),{code:'NEGATIVE_STAGE_VALUE'});
    if(fixed<=0&&rate<=0)throw Object.assign(new Error(`第 ${index+1} 阶段必须设置佣金`),{code:'COMMISSION_REQUIRED'});
    const commission=fixed>0?fixed:Number((amount*rate/100).toFixed(2));
    return{...raw,amount,rate,reward,commission};
   });

   const id=makeId('LKS');
   const createdAt=now();
   db.prepare(`INSERT INTO lucky_series(
    id,user_id,title,status,current_step,total_steps,auto_popup,allow_close,note,created_by,created_at
   ) VALUES(?,?,?,'PENDING',1,?,?,?,?,?,?)`).run(
    id,user.id,String(body.title||'Lucky Series').trim()||'Lucky Series',
    normalized.length,body.auto_popup===false?0:1,body.allow_close===false?0:1,
    String(body.note||''),req.session.user.id,createdAt
   );

   const insert=db.prepare(`INSERT INTO lucky_series_steps(
    series_id,step_no,amount_inr,commission_inr,commission_rate,extra_reward_usdt,
    payment_account_id,payment_account_remark,payment_account_snapshot,status,locked_amount
   ) VALUES(?,?,?,?,?,?,?,?,?,'LOCKED',0)`);

   normalized.forEach((step,index)=>{
    let account=null;
    if(step.payment_account_id){
     account=db.prepare(`SELECT * FROM payment_accounts
      WHERE id=? AND user_id=? AND status='VERIFIED' AND receiving_enabled=1`)
      .get(step.payment_account_id,user.id);
    }
    insert.run(
     id,index+1,step.amount,step.commission,step.rate,step.reward,
     account?.id||null,account?.remark||'',
     account?JSON.stringify({
      type:account.account_type,
      remark:account.remark,
      account_value:account.account_value,
      bank_name:account.bank_name,
      ifsc:account.ifsc,
      provider:account.provider
     }):''
    );
   });

   message(
    user.id,'ORDER',
    'Lucky series invitation','लकी सीरीज़ निमंत्रण',
    'A new Lucky Series is available.','एक नई लकी सीरीज़ उपलब्ध है।'
   );
   audit(req,'CREATE_LUCKY_SERIES','LUCKY_SERIES',id,{
    username:user.username,steps:normalized.length,
    auto_popup:body.auto_popup!==false,allow_close:body.allow_close!==false
   });

   return getAdminSeries(id);
  })();

  res.json({
   ok:true,
   id:result.id,
   username:result.username,
   message:`幸运连单已派发给 ${result.username}`,
   series:result
  });
 }catch(error){apiError(res,error)}
});

r.post('/admin/lucky-series/:id/complete-step',admin,permission('lucky_series'),(req,res)=>{
 try{
  const result=db.transaction(()=>{
   const series=requireSeries(req.params.id);
   if(series.status!=='PARTICIPATING')throw Object.assign(new Error('会员尚未参加或连单已结束'),{code:'SERIES_NOT_PARTICIPATING'});
   const step=requireCurrentStep(series,'IN_PROGRESS');
   const user=requireMember(series.user_id);
   const settlement=settleCurrentStep(req,series,step,user);
   return{settlement,series:getAdminSeries(series.id)};
  })();

  res.json({
   ok:true,
   final_stage:result.settlement.finalStage,
   message:result.settlement.finalStage
    ?'最后阶段已完成结算，幸运连单已全部完成'
    :'当前阶段已完成结算，下一阶段已解锁',
   series:result.series
  });
 }catch(error){apiError(res,error)}
});

r.post('/admin/lucky-series/:id/cancel',admin,permission('lucky_series'),(req,res)=>{
 try{
  const result=db.transaction(()=>{
   const series=requireSeries(req.params.id);
   if(['COMPLETED','CANCELLED'].includes(series.status)){
    throw Object.assign(new Error('已完成或已取消的幸运连单不能再次取消'),{code:'SERIES_TERMINAL'});
   }

   const inProgress=db.prepare(`SELECT * FROM lucky_series_steps
    WHERE series_id=? AND status='IN_PROGRESS' ORDER BY step_no LIMIT 1`).get(series.id);

   let released=0;
   if(inProgress&&Number(inProgress.locked_amount||0)>0){
    const user=requireMember(series.user_id);
    released=Number(inProgress.locked_amount);
    wallet.releasePrincipal({
     userId:user.id,amount:released,
     referenceType:'LUCKY_SERIES',referenceId:series.id,
     note:`Lucky series cancelled at stage ${inProgress.step_no}; principal returned`
    });
   }

   const cancelledAt=now();
   db.prepare(`UPDATE lucky_series_steps
    SET status='CANCELLED',locked_amount=0,cancelled_at=?
    WHERE series_id=? AND status IN ('LOCKED','AVAILABLE','IN_PROGRESS')`)
    .run(cancelledAt,series.id);
   db.prepare(`UPDATE lucky_series
    SET status='CANCELLED',completed_at=?
    WHERE id=?`).run(cancelledAt,series.id);

   audit(req,'CANCEL_LUCKY_SERIES','LUCKY_SERIES',series.id,{principal_released:released});
   return{released,series:getAdminSeries(series.id)};
  })();

  res.json({
   ok:true,
   message:result.released>0
    ?`幸运连单已取消，已退回冻结本金 ₹${result.released.toFixed(2)}`
    :'幸运连单已取消',
   series:result.series
  });
 }catch(error){apiError(res,error)}
});

module.exports=r;
