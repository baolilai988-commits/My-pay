"use strict";
const r=require('express').Router();const db=require('../lib/db');const {now}=require('../lib/utils');const settings=require('../services/settings-service');
r.get('/banners',(req,res)=>res.json({banners:db.prepare("SELECT * FROM banners WHERE enabled=1 AND (start_at IS NULL OR start_at<=?) AND (end_at IS NULL OR end_at>=?) ORDER BY sort_order,id").all(now(),now())}));
r.get('/announcements',(req,res)=>res.json({announcements:db.prepare("SELECT * FROM announcements WHERE enabled=1 AND (start_at IS NULL OR start_at<=?) AND (end_at IS NULL OR end_at>=?) ORDER BY sort_order,id DESC").all(now(),now())}));
r.get('/company',(req,res)=>res.json(db.prepare('SELECT * FROM company_profile WHERE id=1').get()));
r.get('/contacts',(req,res)=>res.json({contacts:db.prepare('SELECT * FROM contacts WHERE enabled=1 ORDER BY sort_order,id').all()}));
r.post('/contacts/:id/click',(req,res)=>{db.prepare('UPDATE contacts SET click_count=click_count+1 WHERE id=?').run(req.params.id);res.json({ok:true})});

r.get('/wallet-settings',(req,res)=>res.json(settings.walletSettings()));

r.get('/settings',(req,res)=>res.json(settings.publicSettings()));
module.exports=r;
