"use strict";
const express=require('express'),session=require('express-session'),path=require('path'),fs=require('fs');
const config=require('./config');
const VERSION=require('./version');
const db=require('./lib/db');
const SQLiteSessionStore=require('./lib/session-store');
const {sanitizeRequest,securityHeaders,corsGuard,issueCsrf,csrfProtection}=require('./lib/security');

function createApp(){
 const app=express();

 const healthHandler=(req,res)=>res.status(200).json({
  ok:true,
  version:VERSION,
  service:'luckypay-api',
  timezone:config.timezone,
  time:new Date().toISOString()
 });

 app.get('/health',healthHandler);
 app.get('/api/health',healthHandler);
 app.set('trust proxy',config.trustProxy);
 app.use(securityHeaders);
 app.use(corsGuard);
 app.use(express.json({limit:'2mb'}));
 app.use(express.urlencoded({extended:true,limit:'2mb'}));
 app.use(sanitizeRequest);
 app.use(session({
  secret:config.sessionSecret,
  store:new SQLiteSessionStore(db,config.sessionHours*3600*1000),
  resave:false,
  saveUninitialized:false,
  rolling:true,
  unset:'destroy',
  name:'luckypay.sid',
  proxy:config.trustProxy>0,
  cookie:{
   httpOnly:true,
   sameSite:'lax',
   secure:config.cookieSecure,
   path:'/',
   maxAge:config.sessionHours*3600*1000
  }
 }));
 app.get('/api/csrf',(req,res)=>{
  const csrf_token=issueCsrf(req);
  req.session.save(err=>err?res.status(500).json({error:'Unable to persist security session'}):res.json({csrf_token}));
 });
app.use('/api',csrfProtection);
 fs.mkdirSync(config.uploadRoot,{recursive:true});
 app.use('/uploads',express.static(config.uploadRoot,{fallthrough:false,maxAge:'1h'}));
 app.use('/api',require('./routes/auth'));
 app.use('/api',require('./routes/public'));
 app.use('/api',require('./routes/user'));
 app.use('/api/admin',require('./routes/admin-security'));
 app.use('/api',require('./routes/lucky-series'));
 app.use('/api/admin',require('./routes/admin'));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Internal server error'})});
 return app;
}
if(require.main===module){
 createApp().listen(config.port,()=>console.log(`Luckypay V${VERSION} API on ${config.port}`));
}
module.exports={createApp,db};
