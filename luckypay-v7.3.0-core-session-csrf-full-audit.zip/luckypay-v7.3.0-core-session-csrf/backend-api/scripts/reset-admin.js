"use strict";
const bcrypt=require('bcryptjs');
const db=require('../src/lib/db');
const username=process.argv[2]||process.env.ADMIN_USERNAME;
const password=process.argv[3]||process.env.ADMIN_PASSWORD;
const secondary=process.argv[4]||process.env.ADMIN_SECONDARY_PASSWORD;
if(!username||!password||!secondary){console.error('Usage: npm run reset-admin -- <username> <login-password> <secondary-password>');process.exit(1)}
if(password.length<8||secondary.length<8||password===secondary){console.error('Passwords must be at least 8 characters and different.');process.exit(1)}
const admin=db.prepare("SELECT id FROM users WHERE username=? COLLATE NOCASE AND role='admin'").get(username)||db.prepare("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1").get();
if(!admin){console.error('No administrator account found.');process.exit(1)}
db.prepare("UPDATE users SET username=?,password_hash=?,secondary_password_hash=?,status='ACTIVE',admin_role='superadmin' WHERE id=?").run(username,bcrypt.hashSync(password,12),bcrypt.hashSync(secondary,12),admin.id);
console.log(`Administrator credentials reset for: ${username}`);
