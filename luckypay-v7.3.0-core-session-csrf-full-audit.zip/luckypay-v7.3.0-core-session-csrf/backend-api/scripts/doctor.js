"use strict";
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..');
const required=[
 'VERSION','.env.example','docker-compose.yml','nginx/default.conf',
 'frontend-user/index.html','frontend-user/assets/app.js',
 'frontend-admin/index.html','frontend-admin/assets/app.js',
 'backend-api/package.json','backend-api/src/app.js'
];
let failed=false;
for(const rel of required){
 const ok=fs.existsSync(path.join(root,rel));
 console.log(`${ok?'OK  ':'FAIL'} ${rel}`);
 if(!ok)failed=true;
}
const version=fs.readFileSync(path.join(root,'VERSION'),'utf8').trim();
const pkg=JSON.parse(fs.readFileSync(path.join(root,'backend-api/package.json'),'utf8'));
if(pkg.version!==version){console.error(`FAIL version mismatch: VERSION=${version}, package=${pkg.version}`);failed=true}
else console.log(`OK   version ${version}`);
if(!fs.existsSync(path.join(root,'.env')))console.warn('WARN .env not found; copy .env.example before deployment');
process.exit(failed?1:0);
