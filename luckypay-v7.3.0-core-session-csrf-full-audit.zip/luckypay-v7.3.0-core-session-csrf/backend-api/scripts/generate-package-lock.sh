#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
npm install --package-lock-only --ignore-scripts --no-audit --no-fund
echo "package-lock.json generated. Future Docker builds will use npm ci."
