"use strict";
const required=['SESSION_SECRET','ADMIN_USERNAME','ADMIN_PASSWORD','ADMIN_SECONDARY_PASSWORD'];
const bad=required.filter(k=>!process.env[k]||/^(CHANGE|REPLACE)_/i.test(process.env[k]));
if(bad.length){console.error(`Unsafe or missing environment variables: ${bad.join(', ')}`);process.exit(1)}
if(String(process.env.SESSION_SECRET).length<32){console.error('SESSION_SECRET must be at least 32 characters');process.exit(1)}
if(String(process.env.ADMIN_PASSWORD).length<8||String(process.env.ADMIN_SECONDARY_PASSWORD).length<8){console.error('Administrator passwords must be at least 8 characters');process.exit(1)}
if(process.env.NODE_ENV==='production'&&process.env.COOKIE_SECURE!=='true'){console.error('COOKIE_SECURE=true is required in production');process.exit(1)}
console.log('Environment validation passed');
