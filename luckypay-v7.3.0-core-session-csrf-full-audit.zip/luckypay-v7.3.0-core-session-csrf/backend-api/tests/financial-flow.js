"use strict";
const assert=require('assert');
const fs=require('fs');
const os=require('os');
const path=require('path');
const {spawn}=require('child_process');

const VERSION='7.3.0';
const port=41000+Math.floor(Math.random()*1000);
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'luckypay-financial-'));
const dbPath=path.join(dir,'financial.db');
const env={
 ...process.env,
 PORT:String(port),
 DB_PATH:dbPath,
 UPLOAD_ROOT:path.join(dir,'uploads'),
 SESSION_SECRET:'financial-flow-secret-48-characters-minimum-123456789',
 NODE_ENV:'test',
 COOKIE_SECURE:'false',
 ALLOWED_ORIGINS:`http://127.3.0.1:${port}`,
 ADMIN_USERNAME:'admin',
 ADMIN_PASSWORD:'AdminLogin123!',
 ADMIN_SECONDARY_PASSWORD:'AdminSecond123!'
};
const child=spawn(process.execPath,['src/app.js'],{cwd:path.join(__dirname,'..'),env,stdio:['ignore','pipe','pipe']});
let log='';child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);

function client(){
 let cookie='',csrf='';
 return{
  async request(url,opt={}){
   const method=opt.method||'GET',headers={...(opt.headers||{})};
   if(cookie)headers.Cookie=cookie;
   if(!['GET','HEAD','OPTIONS'].includes(method))headers['X-CSRF-Token']=csrf;
   const res=await fetch(`http://127.3.0.1:${port}${url}`,{...opt,headers});
   const setCookie=res.headers.get('set-cookie');if(setCookie)cookie=setCookie.split(';')[0];
   const body=await res.json().catch(()=>({}));
   return{res,body};
  },
  async csrf(){const x=await this.request('/api/csrf');assert.equal(x.res.status,200);csrf=x.body.csrf_token}
 }
}
const json=data=>({headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
async function wait(){
 for(let i=0;i<120;i++){
  try{const r=await fetch(`http://127.3.0.1:${port}/api/health`);if(r.ok)return}catch{}
  await new Promise(r=>setTimeout(r,100));
 }
 throw Error('server did not start\n'+log);
}

(async()=>{
 const member=client(),admin=client();
 let db;
 try{
  await wait();
  await member.csrf();
  let x=await member.request('/api/register',{method:'POST',...json({
   username:'flowmember',password:'secret12',confirm_password:'secret12',
   display_name:'Flow Member',phone:'9888888888'
  })});
  assert.equal(x.res.status,200);
  x=await member.request('/api/me');assert.equal(x.res.status,200);
  const userId=x.body.user.id;

  await admin.csrf();
  x=await admin.request('/api/admin-login/start',{method:'POST',...json({
   username:'admin',password:'AdminLogin123!',secondary_password:'AdminSecond123!'
  })});
  assert.equal(x.res.status,200);

  // Credit real principal through the administrator API and wallet service.
  x=await admin.request(`/api/admin/users/${userId}/credit`,{method:'POST',...json({amount:50000,bonus:0,note:'financial flow test'})});
  assert.equal(x.res.status,200);

  const Database=require('better-sqlite3');
  db=new Database(dbPath);
  const now=new Date().toISOString();

  // Real ordinary-order database flow.
  db.prepare(`INSERT INTO orders(
   id,user_id,order_type,amount_inr,commission_rate,commission_inr,extra_reward_usdt,
   status,note,created_by,created_at
  ) VALUES('FLOW-ORDER',?,'NORMAL',10000,0,500,2,'PENDING','financial flow',1,?)`).run(userId,now);

  x=await member.request('/api/orders/FLOW-ORDER/accept',{method:'POST',...json({})});
  assert.equal(x.res.status,200);assert.equal(x.body.status,'PROCESSING');
  let user=db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  assert.equal(Number(user.balance_inr),40000);
  assert.equal(Number(user.order_locked_inr),10000);

  x=await member.request('/api/orders/FLOW-ORDER/confirm',{method:'POST',...json({})});
  assert.equal(x.res.status,200);
  user=db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  assert.equal(Number(user.order_locked_inr),0);
  assert.equal(Number(user.commission_wallet_inr),500);
  assert.equal(Number(user.reward_usdt),2);
  assert.equal(db.prepare("SELECT status FROM orders WHERE id='FLOW-ORDER'").get().status,'COMPLETED');
  assert(db.prepare("SELECT COUNT(*) c FROM wallet_ledger WHERE reference_id='FLOW-ORDER'").get().c>=4);

  // Real Lucky Series flow: create -> visible -> join without balance check -> start -> settle -> next stage.
  x=await admin.request('/api/admin/lucky-series',{method:'POST',...json({
   username:'flowmember',title:'Flow Lucky',auto_popup:true,allow_close:true,
   steps:[
    {amount_inr:12000,commission_inr:600,extra_reward_usdt:3},
    {amount_inr:15000,commission_inr:750,extra_reward_usdt:4}
   ]
  })});
  assert.equal(x.res.status,200);const seriesId=x.body.id;assert(seriesId);

  x=await member.request('/api/state');
  assert.equal(x.res.status,200);
  assert.equal(x.body.schema_version,'7.1');
  assert(x.body.dashboard?.user);
  assert(Array.isArray(x.body.orders?.orders));
  assert(Array.isArray(x.body.banners?.banners));
  assert(x.body.wallet_settings);
  const series=x.body.lucky.series.find(s=>s.id===seriesId);
  assert(series);assert.equal(series.status,'PENDING');
  assert.equal(series.auto_popup,1);
  assert(series.first_step_detail);assert.equal(Number(series.first_step_detail.amount_inr),12000);

  // Joining must not change any wallet.
  const beforeJoin=db.prepare('SELECT balance_inr,order_locked_inr FROM users WHERE id=?').get(userId);
  x=await member.request(`/api/lucky-series/${seriesId}/join`,{method:'POST',...json({})});
  assert.equal(x.res.status,200);assert.equal(x.body.status,'PARTICIPATING');
  const afterJoin=db.prepare('SELECT balance_inr,order_locked_inr FROM users WHERE id=?').get(userId);
  assert.deepEqual(afterJoin,beforeJoin);

  x=await member.request(`/api/lucky-series/${seriesId}/start-current`,{method:'POST',...json({})});
  assert.equal(x.res.status,200);
  user=db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  assert.equal(Number(user.balance_inr),28000);
  assert.equal(Number(user.order_locked_inr),12000);

  x=await admin.request(`/api/admin/lucky-series/${seriesId}/complete-step`,{method:'POST',...json({})});
  assert.equal(x.res.status,200);
  user=db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  assert.equal(Number(user.balance_inr),40000);
  assert.equal(Number(user.order_locked_inr),0);
  assert.equal(Number(user.commission_wallet_inr),1100);
  assert.equal(Number(user.reward_usdt),5);

  const state=db.prepare('SELECT status,current_step FROM lucky_series WHERE id=?').get(seriesId);
  assert.equal(state.status,'PARTICIPATING');assert.equal(state.current_step,2);
  x=await member.request('/api/state');
  assert.equal(x.res.status,200);
  const refreshed=x.body.lucky.series.find(s=>s.id===seriesId);
  assert.equal(refreshed.current_step,2);
  assert.equal(refreshed.current_step_detail.step_no,2);
  assert.equal(refreshed.current_step_detail.status,'AVAILABLE');
  const step2=db.prepare('SELECT status FROM lucky_series_steps WHERE series_id=? AND step_no=2').get(seriesId);
  assert.equal(step2.status,'AVAILABLE');
  assert(db.prepare("SELECT COUNT(*) c FROM wallet_ledger WHERE reference_id=?").get(seriesId).c>=4);

  console.log('Real database financial flow passed: ordinary order and Lucky Series');
  process.exitCode=0;
 }catch(e){
  console.error(e);console.error(log);process.exitCode=1;
 }finally{
  if(db)db.close();
  child.kill('SIGTERM');
  setTimeout(()=>fs.rmSync(dir,{recursive:true,force:true}),300);
 }
})();
