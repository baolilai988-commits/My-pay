# Funds integration scenarios

1. Joining the first lucky stage freezes principal:
   - available principal decreases by stage amount
   - order locked increases by the same amount
   - two wallet ledger entries are created
2. Completing a stage:
   - locked principal returns to available principal
   - locked balance decreases
   - commission enters commission wallet
   - USDT reward enters reward wallet
   - next stage changes to AVAILABLE
3. Cancelling:
   - any IN_PROGRESS locked principal is returned
   - series becomes CANCELLED
4. Test account:
   - database triggers block deposits, withdrawals, payment accounts, real orders and real lucky series
5. Dashboard:
   - all real metrics filter `is_test_account=0`
