"use strict";
const assert=require('assert');
const fs=require('fs');
const os=require('os');
const path=require('path');
const {spawn}=require('child_process');

const VERSION='7.3.0';
const port=39000+Math.floor(Math.random()*1000);
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'luckypay-test-'));
const dbPath=path.join(dir,'test.db');
const env={
 ...process.env,
 PORT:String(port),
 DB_PATH:dbPath,
 UPLOAD_ROOT:path.join(dir,'uploads'),
 SESSION_SECRET:'integration-test-secret-48-characters-minimum-123456789',
 NODE_ENV:'test',
 COOKIE_SECURE:'false',
 ALLOWED_ORIGINS:`http://127.3.0.1:${port}`,
 ADMIN_USERNAME:'admin',
 ADMIN_PASSWORD:'AdminLogin123!',
 ADMIN_SECONDARY_PASSWORD:'AdminSecond123!'
};
const child=spawn(process.execPath,['src/app.js'],{cwd:path.join(__dirname,'..'),env,stdio:['ignore','pipe','pipe']});
let serverLog='';child.stdout.on('data',d=>serverLog+=d);child.stderr.on('data',d=>serverLog+=d);

function client(){
 let cookie='',csrf='';
 return{
  async request(url,opt={}){
   const method=opt.method||'GET',headers={...(opt.headers||{})};
   if(cookie)headers.Cookie=cookie;
   if(!['GET','HEAD','OPTIONS'].includes(method))headers['X-CSRF-Token']=csrf;
   const res=await fetch(`http://127.3.0.1:${port}${url}`,{...opt,headers});
   const raw=res.headers.get('set-cookie');if(raw)cookie=raw.split(';')[0];
   const body=await res.json().catch(()=>({}));
   return{res,body};
  },
  async csrf(){const x=await this.request('/api/csrf');assert.equal(x.res.status,200);csrf=x.body.csrf_token;assert(csrf);return csrf},
  get cookie(){return cookie}
 }
}
async function wait(){
 for(let i=0;i<100;i++){
  try{const r=await fetch(`http://127.3.0.1:${port}/api/health`);if(r.ok)return}catch{}
  await new Promise(r=>setTimeout(r,100));
 }
 throw Error('server did not start\n'+serverLog);
}
function json(data){return{headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}}
(async()=>{
 const member=client(),admin=client();
 try{
  await wait();

  let x=await member.request('/health');
  assert.equal(x.res.status,200);assert.equal(x.body.version,VERSION);
  x=await member.request('/api/health');
  assert.equal(x.res.status,200);assert.equal(x.body.version,VERSION);

  await member.csrf();
  x=await member.request('/api/register',{method:'POST',...json({username:'member01',password:'secret12',confirm_password:'secret12',display_name:'Member',phone:'9999999999'})});
  assert.equal(x.res.status,200);
  x=await member.request('/api/me');assert.equal(x.res.status,200);assert.equal(x.body.user.username,'member01');

  await admin.csrf();
  x=await admin.request('/api/admin-login/start',{method:'POST',...json({username:'admin',password:'AdminLogin123!',secondary_password:'AdminSecond123!'})});
  assert.equal(x.res.status,200);
  x=await admin.request('/api/me');assert.equal(x.res.status,200);assert.equal(x.body.user.role,'admin');

  x=await admin.request('/api/admin/test-accounts',{method:'POST',...json({
   username:'test001',password:'secret12',display_name:'Test Account',member_level_id:1,
   balance_inr:1000,commission_wallet_inr:200,reward_usdt:5,
   test_today_commission:50,test_today_income:75,test_bonus_completed:2,
   bonus_amount:10000,bonus_commission:500,test_lucky_completed:1,
   lucky_total_steps:3,lucky_step_amount:12000,lucky_step_commission:600
  })});
  assert.equal(x.res.status,200);const testId=x.body.id;assert(testId);

  x=await admin.request('/api/admin/test-accounts');
  assert.equal(x.res.status,200);assert.equal(x.body.accounts.length,1);
  assert.equal(x.body.accounts[0].username,'test001');

  x=await admin.request(`/api/admin/test-accounts/${testId}`,{method:'PUT',...json({
   balance_inr:1500,commission_wallet_inr:300,reward_usdt:8,
   test_today_commission:80,test_today_income:100,
   test_bonus_completed:2,test_lucky_completed:1,status:'ACTIVE'
  })});
  assert.equal(x.res.status,200);assert.equal(Number(x.body.account.balance_inr),1500);

  x=await admin.request('/api/admin/dashboard');
  assert.equal(x.res.status,200);
  assert.equal(x.body.total_users,1,'test accounts must be excluded from real user totals');

  x=await admin.request('/api/admin/wallet-settings');
  assert.equal(x.res.status,200);
  x=await member.request('/api/wallet-settings');
  assert.equal(x.res.status,200);

  x=await admin.request(`/api/admin/test-accounts/${testId}`,{method:'DELETE'});
  assert.equal(x.res.status,200);
  x=await admin.request('/api/admin/test-accounts');
  assert.equal(x.body.accounts.length,0);

  const Database=require('better-sqlite3'),db=new Database(dbPath,{readonly:true});
  const migrations=db.prepare('SELECT version,name FROM schema_migrations ORDER BY version').all();
  assert.deepEqual(migrations.map(x=>x.version),[1,2]);
  assert.equal(db.prepare("SELECT COUNT(*) c FROM users WHERE is_test_account=1").get().c,0);
  db.close();

  console.log('Integration tests passed');
  process.exitCode=0;
 }catch(e){
  console.error(e);
  console.error(serverLog);
  process.exitCode=1;
 }finally{
  child.kill('SIGTERM');
  setTimeout(()=>fs.rmSync(dir,{recursive:true,force:true}),200);
 }
})();
