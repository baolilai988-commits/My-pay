"use strict";
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.join(__dirname,'../..');
const folders=['frontend-user','frontend-admin','backend-api/src','nginx','tests'];
const files=[];
function walk(dir){
 for(const name of fs.readdirSync(dir)){
  const full=path.join(dir,name),st=fs.statSync(full);
  if(st.isDirectory())walk(full);
  else{
   const rel=path.relative(root,full).replace(/\\/g,'/');
   const data=fs.readFileSync(full);
   files.push({path:rel,sha256:crypto.createHash('sha256').update(data).digest('hex'),size:data.length});
  }
 }
}
for(const folder of folders)walk(path.join(root,folder));
files.sort((a,b)=>a.path.localeCompare(b.path));
const version=fs.readFileSync(path.join(root,'VERSION'),'utf8').trim();
const out={baseline_version:version,created_at:new Date().toISOString(),files};
fs.writeFileSync(path.join(root,'baseline/BASELINE_SNAPSHOT.json'),JSON.stringify(out,null,2)+'\n');
console.log(`Baseline snapshot saved: ${files.length} files`);
