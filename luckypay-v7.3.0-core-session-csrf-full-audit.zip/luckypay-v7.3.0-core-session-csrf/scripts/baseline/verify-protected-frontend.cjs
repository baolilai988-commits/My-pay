"use strict";
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.join(__dirname,'../..');
const lock=JSON.parse(fs.readFileSync(path.join(root,'baseline/PROTECTED_FRONTEND_HASHES.json'),'utf8'));
const approvalPath=path.join(root,'baseline/FRONTEND_CHANGE_APPROVAL.json');
const approvals=fs.existsSync(approvalPath)?new Set(JSON.parse(fs.readFileSync(approvalPath,'utf8')).approved_files||[]):new Set();
const failures=[];
for(const [rel,meta] of Object.entries(lock.protected_files)){
 const full=path.join(root,rel);
 if(!fs.existsSync(full)){failures.push(`${rel}: missing`);continue}
 const hash=crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
 if(hash!==meta.sha256&&!approvals.has(rel))failures.push(`${rel}: protected hash changed`);
}
if(failures.length)throw Error(failures.join('\n'));
console.log(`Protected frontend passed: ${Object.keys(lock.protected_files).length} files`);
