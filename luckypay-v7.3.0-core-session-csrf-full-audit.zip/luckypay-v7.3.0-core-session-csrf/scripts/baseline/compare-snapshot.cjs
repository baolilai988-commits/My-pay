"use strict";
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.join(__dirname,'../..');
const baseline=JSON.parse(fs.readFileSync(path.join(root,'baseline/BASELINE_SNAPSHOT.json'),'utf8'));
const allowedFile=path.join(root,'baseline/APPROVED_CHANGES.json');
const allowed=fs.existsSync(allowedFile)?new Set(JSON.parse(fs.readFileSync(allowedFile,'utf8')).allowed_files||[]):new Set();
const current=new Map();
const folders=['frontend-user','frontend-admin','backend-api/src','nginx','tests'];
function walk(dir){
 for(const name of fs.readdirSync(dir)){
  const full=path.join(dir,name),st=fs.statSync(full);
  if(st.isDirectory())walk(full);
  else{
   const rel=path.relative(root,full).replace(/\\/g,'/');
   const data=fs.readFileSync(full);
   current.set(rel,crypto.createHash('sha256').update(data).digest('hex'));
  }
 }
}
for(const folder of folders)walk(path.join(root,folder));
const original=new Map(baseline.files.map(x=>[x.path,x.sha256]));
const changed=[],added=[],removed=[];
for(const [file,hash] of current){
 if(!original.has(file))added.push(file);
 else if(original.get(file)!==hash)changed.push(file);
}
for(const file of original.keys())if(!current.has(file))removed.push(file);
const unapproved=[...changed,...added,...removed].filter(x=>!allowed.has(x));
console.log(JSON.stringify({changed,added,removed,approved:[...allowed]},null,2));
if(unapproved.length)throw Error(`Unapproved baseline differences: ${unapproved.join(', ')}`);
console.log('Baseline comparison passed');
