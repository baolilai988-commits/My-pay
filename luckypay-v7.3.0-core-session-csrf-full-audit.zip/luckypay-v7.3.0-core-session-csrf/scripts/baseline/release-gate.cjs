"use strict";
const {spawnSync}=require('child_process'),path=require('path');
const root=path.join(__dirname,'../..');
const commands=[
 ['node',['scripts/baseline/verify-protected-frontend.cjs']],
 ['node',['scripts/baseline/verify-feature-contracts.cjs']],
 ['node',['tests/static-check.js']],
 ['node',['tests/route-order-check.js']],
 ['node',['tests/lucky-ui-flow-check.js']],
 ['node',['tests/wallet-service-check.js']],
 ['node',['tests/v61-page-state-check.js']],
 ['node',['tests/v62-global-export-check.cjs']],
 ['node',['tests/v63-lucky-popup-mandatory-check.cjs']],
 ['node',['tests/v63-runtime-state-check.cjs']],
 ['node',['tests/v63-order-balance-check.cjs']],
 ['node',['tests/v63-release-gate-check.cjs']],
 ['node',['tests/v631-interoperability-check.cjs']],
 ['node',['tests/v7-unified-member-state-check.cjs']],
 ['node',['tests/v7-state-database-contract-check.cjs']],
 ['node',['tests/v71-lucky-rebuild-check.cjs']],
 ['node',['tests/v72-dedicated-lucky-modal-check.cjs']],
 ['node',['tests/v721-lucky-only-popup-check.cjs']],
 ['node',['tests/v730-core-session-csrf-check.cjs']]
];
for(const [cmd,args] of commands){
 const r=spawnSync(cmd,args,{cwd:root,stdio:'inherit'});
 if(r.status!==0)process.exit(r.status||1);
}
console.log('MANDATORY RELEASE GATE PASSED');
