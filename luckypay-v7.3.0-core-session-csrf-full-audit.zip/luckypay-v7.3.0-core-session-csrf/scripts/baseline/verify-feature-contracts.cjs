"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'../..');
const catalog=JSON.parse(fs.readFileSync(path.join(root,'baseline/FRONTEND_FEATURE_CATALOG.json'),'utf8'));
const contract=JSON.parse(fs.readFileSync(path.join(root,'baseline/API_DATABASE_CONTRACT.json'),'utf8'));
const memberHtml=fs.readFileSync(path.join(root,'frontend-user/index.html'),'utf8');
const memberJs=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const adminHtml=fs.readFileSync(path.join(root,'frontend-admin/index.html'),'utf8');
const adminJs=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');
const dbJs=fs.readFileSync(path.join(root,'backend-api/src/lib/db.js'),'utf8')+'\n'+fs.readFileSync(path.join(root,'backend-api/src/lib/session-store.js'),'utf8');
const routeText=fs.readdirSync(path.join(root,'backend-api/src/routes'))
 .filter(x=>x.endsWith('.js')).map(x=>fs.readFileSync(path.join(root,'backend-api/src/routes',x),'utf8')).join('\n');

const failures=[];
for(const id of catalog.member.mandatory_dom)if(!memberHtml.includes(`id="${id}"`))failures.push(`member DOM missing: ${id}`);
for(const fn of catalog.member.mandatory_runtime)if(!memberJs.includes(fn))failures.push(`member runtime missing: ${fn}`);
for(const id of catalog.admin.mandatory_pages)if(!adminHtml.includes(`id="${id}"`))failures.push(`admin page missing: ${id}`);
for(const fn of catalog.admin.mandatory_runtime)if(!adminJs.includes(fn))failures.push(`admin runtime missing: ${fn}`);

for(const [table,fields] of Object.entries(contract.database)){
 if(!dbJs.includes(`CREATE TABLE IF NOT EXISTS ${table}`))failures.push(`database table missing: ${table}`);
 for(const field of fields){
  const tableStart=dbJs.indexOf(`CREATE TABLE IF NOT EXISTS ${table}`);
  const next=dbJs.indexOf('CREATE TABLE IF NOT EXISTS ',tableStart+10);
  const block=dbJs.slice(tableStart,next<0?dbJs.length:next);
  if(!new RegExp(`\\b${field}\\b`).test(block)&&!dbJs.includes(`column('${table}','${field}'`))failures.push(`database field missing: ${table}.${field}`);
 }
}

const routeExpectations=[
 ['/orders/:id/accept',"r.post('/orders/:id/accept'"],
 ['/lucky-series/:id/join',"r.post('/lucky-series/:id/join'"],
 ['/lucky-series/:id/start-current',"r.post('/lucky-series/:id/start-current'"],
 ['/admin/lucky-series',"r.post('/admin/lucky-series'"],
 ['/admin/lucky-series/:id/complete-step',"r.post('/admin/lucky-series/:id/complete-step'"],
 ['/admin/wallet-settings',"r.get('/wallet-settings'"],
 ['/admin/test-accounts',"r.get('/test-accounts'"]
];
for(const [pathName,needle] of routeExpectations)if(!routeText.includes(needle))failures.push(`backend route missing for ${pathName}`);

if(failures.length)throw Error(failures.join('\n'));
console.log(`Feature/API/database contracts passed: ${contract.contracts.length} critical contracts`);
