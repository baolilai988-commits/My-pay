#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
STAMP="$(date +%F_%H-%M-%S)"
DEST="${1:-./backups}"
mkdir -p "$DEST"
FILES=(data uploads .env VERSION)
EXISTING=()
for item in "${FILES[@]}"; do
  [[ -e "$item" ]] && EXISTING+=("$item")
done
if [[ ${#EXISTING[@]} -eq 0 ]]; then
  echo "Nothing to back up."
  exit 1
fi
tar -czf "$DEST/luckypay-v6-backup-$STAMP.tar.gz" "${EXISTING[@]}"
echo "$DEST/luckypay-v6-backup-$STAMP.tar.gz"
