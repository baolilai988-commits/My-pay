#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/backend-api"
npm run baseline:compare
npm run release:gate
npm test
cd "$ROOT/.."
zip -qr "luckypay-v7.0.0-verified.zip" "luckypay-v7.0.0"
echo "Verified release created: luckypay-v7.0.0-verified.zip"
