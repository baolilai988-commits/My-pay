"use strict";
(function(){
 let csrfToken='',csrfPromise=null,authenticated=false,restorePromise=null;

 async function csrf(force=false){
  if(force){csrfToken='';csrfPromise=null}
  if(csrfToken)return csrfToken;
  if(csrfPromise)return csrfPromise;
  csrfPromise=(async()=>{
   const response=await fetch('/api/csrf',{
    credentials:'same-origin',
    cache:'no-store',
    headers:{'Accept':'application/json'}
   });
   const body=await response.json().catch(()=>({}));
   if(!response.ok||!body.csrf_token){
    const error=Error(body.error||'Unable to initialize security token');
    error.status=response.status;
    throw error;
   }
   csrfToken=body.csrf_token;
   return csrfToken;
  })();
  try{return await csrfPromise}finally{csrfPromise=null}
 }

 async function parseResponse(response){
  const type=response.headers.get('content-type')||'';
  if(type.includes('application/json'))return response.json().catch(()=>({}));
  const text=await response.text().catch(()=>'');
  return{text};
 }

 async function request(url,opt={},retried=false){
  const method=String(opt.method||'GET').toUpperCase();
  const headers=new Headers(opt.headers||{});
  const body=opt.body;
  const isFormData=typeof FormData!=='undefined'&&body instanceof FormData;

  headers.set('Accept','application/json');
  if(body!==undefined&&!isFormData&&!headers.has('Content-Type')){
   headers.set('Content-Type','application/json');
  }
  if(!['GET','HEAD','OPTIONS'].includes(method)){
   headers.set('X-CSRF-Token',await csrf());
  }

  let response;
  try{
   response=await fetch('/api'+url,{
    ...opt,
    method,
    body,
    headers,
    credentials:'same-origin',
    cache:'no-store'
   });
  }catch(cause){
   const error=Error('Network unavailable');
   error.code='NETWORK';
   error.cause=cause;
   throw error;
  }

  const payload=await parseResponse(response);
  if(response.status===403&&payload.error==='CSRF validation failed'&&!retried){
   await csrf(true);
   return request(url,opt,true);
  }

  if(!response.ok){
   const error=Error(payload.error||payload.text||'Request failed');
   error.status=response.status;
   error.code=response.status===401?'AUTH_EXPIRED':'HTTP_ERROR';
   throw error;
  }

  if(!['GET','HEAD','OPTIONS'].includes(method)){
   window.dispatchEvent(new CustomEvent('luckypay:mutation-success',{detail:{url,method}}));
  }
  return payload;
 }

 async function verifySession(){
  const result=await request('/me');
  const valid=result.user?.role==='admin';
  authenticated=valid;
  if(!valid){
   const error=Error('Administrator Session was not established');
   error.code='AUTH_EXPIRED';
   throw error;
  }
  return result;
 }

 async function restore(retries=3){
  if(restorePromise)return restorePromise;
  restorePromise=(async()=>{
   for(let attempt=0;attempt<retries;attempt++){
    try{
     await verifySession();
     return true;
    }catch(error){
     if(error.code==='AUTH_EXPIRED'||error.status===401||error.status===403)break;
     if(attempt<retries-1)await new Promise(resolve=>setTimeout(resolve,500*(attempt+1)));
    }
   }
   authenticated=false;
   return false;
  })();
  try{return await restorePromise}finally{restorePromise=null}
 }

 async function login(credentials){
  const result=await request('/admin-login/start',{
   method:'POST',
   body:JSON.stringify(credentials)
  });
  if(!result.requires_totp){
   await csrf(true);
   await verifySession();
  }
  return result;
 }

 async function verifyTotp(code){
  const result=await request('/admin-login/verify',{
   method:'POST',
   body:JSON.stringify({code})
  });
  await csrf(true);
  await verifySession();
  return result;
 }

 async function upload(url,formData){
  if(!(formData instanceof FormData))throw Error('Upload body must be FormData');
  return request(url,{method:'POST',body:formData});
 }

 async function logout(){
  try{await request('/logout',{method:'POST'})}
  finally{
   authenticated=false;
   csrfToken='';
   csrfPromise=null;
   restorePromise=null;
  }
 }

 function isAuthenticated(){return authenticated}
 function expire(){
  authenticated=false;
  csrfToken='';
  csrfPromise=null;
  restorePromise=null;
 }

 window.AuthManager=Object.freeze({
  request,upload,csrf,restore,login,verifyTotp,logout,isAuthenticated,expire
 });
})();
