"use strict";
(function(){const loaders=new Map(),dirty=new Set();let activePage='dashboard',timer=null,running=false,generation=0;
 function register(name,loader){loaders.set(name,loader)}function setActivePage(name){activePage=name}function markDirty(name=activePage){dirty.add(name)}function clearDirty(name=activePage){dirty.delete(name)}function isDirty(name=activePage){return dirty.has(name)}
 async function refresh(name=activePage,{force=false}={}){if(running)return false;if(isDirty(name)&&!force)return false;const loader=loaders.get(name);if(!loader)return false;const run=++generation;running=true;try{await loader();return run===generation}catch(e){if(e.code==='AUTH_EXPIRED')throw e;console.warn('Refresh failed',name,e);return false}finally{if(run===generation)running=false}}
 function start(handler,ms=3000){stop();timer=setInterval(()=>{if(!document.hidden)handler()},ms)}function stop(){if(timer){clearInterval(timer);timer=null}}
 window.addEventListener('luckypay:mutation-success',()=>clearDirty(activePage));
 window.RefreshManager=Object.freeze({register,setActivePage,markDirty,clearDirty,isDirty,refresh,start,stop,get activePage(){return activePage}})})();
