"use strict";
const $=id=>document.getElementById(id);
const escapeHtml=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});let users=[],levels=[],busy=false,dispatchAccounts=[],telegramSpecialists=[];
function toast(t){const e=$('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2800)}function setText(id,v){const e=$(id);if(e)e.textContent=v}const api=(url,opt={})=>AuthManager.request(url,opt);const ensureCsrf=force=>AuthManager.csrf(force);
async function login(){try{const x=await AuthManager.login({username:$('loginUsername').value,password:$('loginPassword').value,secondary_password:$('loginSecondary').value});if(x.requires_totp){$('totpLoginBox').classList.remove('hidden');toast(x.message);return}showAdminApp()}catch(e){toast(e.message)}}async function verifyAdminTotp(){try{await AuthManager.verifyTotp($('loginTotp').value);showAdminApp()}catch(e){toast(e.message)}}async function logout(){try{await AuthManager.logout()}catch{}location.replace('/admin/')}
function validAdminPage(id){return !!id&&!!document.getElementById(id)&&document.getElementById(id).classList.contains('page')}
function pageFromLocation(){
 const hash=decodeURIComponent(location.hash.replace(/^#/,''));
 if(validAdminPage(hash))return hash;
 const saved=localStorage.getItem('luckypay_admin_page');
 return validAdminPage(saved)?saved:'dashboard'
}
function openPage(id,{updateUrl=true,refresh=true}={}){
 if(!validAdminPage(id))id='dashboard';
 localStorage.setItem('luckypay_admin_page',id);
 RefreshManager.setActivePage(id);
 document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
 $(id).classList.add('active');
 document.querySelectorAll('.side button[data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===id));
 setText('pageTitle',document.querySelector(`.side button[data-page="${id}"]`)?.textContent?.trim()||'');
 if(updateUrl&&location.hash!=='#'+id)history.pushState({page:id},'',location.pathname+location.search+'#'+encodeURIComponent(id));
 if(refresh&&AuthManager.isAuthenticated())load(false)
}
function options(){}

const memberFieldState={},memberSearchTimers={};
const memberFieldConfig={
 credit:{input:'creditUsername',list:'creditUserSuggestions',match:'creditUserMatch'},
 d:{input:'dUsername',list:'dUserSuggestions',match:'dUserMatch'},
 manualDep:{input:'manualDepUsername',list:'manualDepUserSuggestions',match:'manualDepUserMatch'},
 m:{input:'mUsername',list:'mUserSuggestions',match:'mUserMatch'}
};
async function searchMemberField(key,allowBlank=false){
 const c=memberFieldConfig[key];if(!c)return;
 clearTimeout(memberSearchTimers[key]);
 const q=$(c.input).value.trim();
 memberFieldState[key]=null;
 if(!q){
  $(c.list).innerHTML='';
  setText(c.match,allowBlank?'留空表示全部用户':'请输入完整会员账号');
  if(key==='d'){$('dPaymentAccount').innerHTML='<option value="">请先输入会员账号</option>';setText('dAccountHint','只显示已审核且允许接单的账户')}
  return;
 }
 setText(c.match,'正在查找...');
 memberSearchTimers[key]=setTimeout(async()=>{
  try{
   const x=await api('/admin/members/search?q='+encodeURIComponent(q));
   $(c.list).innerHTML=x.users.map(u=>`<option value="${escapeHtml(u.username)}">${escapeHtml(u.display_name||'-')} · ${escapeHtml(u.status)}</option>`).join('');
   const exact=x.users.find(u=>u.username.toLowerCase()===q.toLowerCase())||null;
   memberFieldState[key]=exact;
   setText(c.match,exact?`已匹配：${exact.username} · ${exact.display_name||'-'} · ${exact.status}`:(x.users.length?`找到 ${x.users.length} 个相近账号，请输入完整账号`:'没有找到会员账号'));
   if(key==='d'){
    if(exact)await loadDispatchAccounts();
    else{$('dPaymentAccount').innerHTML='<option value="">请先匹配完整会员账号</option>';setText('dAccountHint','请输入有效会员账号')}
   }
  }catch(e){setText(c.match,e.message)}
 },250);
}
async function requireMember(key,allowBlank=false){
 const c=memberFieldConfig[key],username=$(c.input).value.trim();
 if(allowBlank&&!username)return null;
 let user=memberFieldState[key];
 if(!user||user.username.toLowerCase()!==username.toLowerCase()){
  const x=await api('/admin/members/search?q='+encodeURIComponent(username));
  user=x.users.find(u=>u.username.toLowerCase()===username.toLowerCase())||null;
  memberFieldState[key]=user;
 }
 if(!user)throw new Error('会员账号不存在，请输入完整会员账号');
 if(user.status!=='ACTIVE')throw new Error('会员账号当前状态不可用');
 return user;
}

function renderUsers(){$('userRows').innerHTML=users.length?users.map(u=>`<tr><td>${u.id}</td><td>${u.username}<br><span class="muted">${u.display_name}</span></td><td>${u.member_level?.name_zh||''}</td><td>${money(u.balance_inr)}</td><td>${money(u.order_locked_inr)}</td><td>${money(u.commission_wallet_inr)}</td><td>${u.reward_usdt}</td><td>${u.receiving_enabled?'开启':'关闭'}</td><td>${u.status}</td><td><button class="secondary" onclick="editUser(${u.id})">编辑</button> <button class="primary" onclick="adjustUser(${u.id})">调账</button></td></tr>`).join(''):'<tr><td colspan="10">暂无用户</td></tr>'}
async function editUser(id){const u=users.find(x=>x.id===id),status=prompt('状态 ACTIVE/FROZEN/DISABLED',u.status);if(!status)return;const lv=prompt('等级ID：'+levels.map(x=>x.id+'='+x.name_zh).join('，'),u.member_level_id);if(!lv)return;try{const x=await api('/admin/users/'+id,{method:'PUT',body:JSON.stringify({status,member_level_id:Number(lv),receiving_blocked:confirm('是否禁止接单？')})});toast(x.message);await load()}catch(e){toast(e.message)}}async function adjustUser(id){const wallet_type=prompt('钱包 INR / COMMISSION / USDT','INR');if(!wallet_type)return;const amount=Number(prompt('增加正数，扣减负数','0'));if(!amount)return;try{const x=await api('/admin/users/'+id+'/adjust',{method:'POST',body:JSON.stringify({wallet_type,amount,note:prompt('原因','')||''})});toast(x.message);await load()}catch(e){toast(e.message)}}async function directCredit(){try{const u=await requireMember('credit'),amount=Number($('creditAmount').value),bonus=Number($('creditBonus').value||0);if(!(amount>0))throw new Error('请输入上分金额');const x=await api('/admin/users/'+u.id+'/credit',{method:'POST',body:JSON.stringify({amount,bonus,reference_no:$('creditReference').value,note:$('creditNote').value})});$('creditResult').classList.remove('hidden');$('creditResult').innerHTML=`<b>${escapeHtml(x.message)}</b><br>会员：${escapeHtml(u.username)}<br>单号：${escapeHtml(x.deposit_id)}<br>上分前：${money(x.before)}<br>上分后：${money(x.after)}`;toast(x.message);await load()}catch(e){toast(e.message)}}
function renderLevels(){const enabledLevels=levels.filter(l=>Number(l.enabled)===1);if($('taLevel')){$('taLevel').innerHTML=enabledLevels.length?enabledLevels.map(l=>`<option value="${l.id}">${l.name_zh} · 每日额度 ${money(l.daily_limit_inr)} · 佣金 ${Number(l.commission_rate).toFixed(2)}%</option>`).join(''):'<option value="">暂无可用会员等级</option>'; $('taLevel').disabled=!enabledLevels.length} $('levelCards').innerHTML=levels.map(l=>`<div class="card"><h3>${l.name_zh}</h3><div class="formgrid three"><input id="lz${l.id}" value="${l.name_zh}"><input id="le${l.id}" value="${l.name_en}"><input id="lh${l.id}" value="${l.name_hi}"><input id="ll${l.id}" type="number" value="${l.daily_limit_inr}"><input id="lr${l.id}" type="number" value="${l.commission_rate}"><input id="ls${l.id}" type="number" value="${l.sort_order}"></div><label><input id="len${l.id}" type="checkbox" ${l.enabled?'checked':''} style="width:auto"> 启用</label><br><button class="primary" onclick="saveLevel(${l.id})">保存</button></div>`).join('')}async function saveLevel(id){try{const x=await api('/admin/levels/'+id,{method:'PUT',body:JSON.stringify({name_zh:$('lz'+id).value,name_en:$('le'+id).value,name_hi:$('lh'+id).value,daily_limit_inr:Number($('ll'+id).value),commission_rate:Number($('lr'+id).value),sort_order:Number($('ls'+id).value),enabled:$('len'+id).checked})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderOrders(rows){$('orderRows').innerHTML=rows.length?rows.map(o=>`<tr><td>${o.id}</td><td>${o.username}</td><td>${o.payment_account_remark||'-'}</td><td>${o.order_type}</td><td>${money(o.amount_inr)}</td><td>${money(o.commission_inr)}</td><td>${o.extra_reward_usdt}</td><td>${o.series_current?o.series_current+'/'+o.series_total:'-'}</td><td>${o.status}</td><td>${o.created_at}</td><td>${!['COMPLETED','CANCELLED'].includes(o.status)?`<button class="danger" onclick="cancelOrder('${o.id}')">取消</button>`:''}${['PARTICIPATING','PROCESSING'].includes(o.status)?` <button class="primary" onclick="completeOrder('${o.id}')">完成结算</button>`:''}</td></tr>`).join(''):'<tr><td colspan="11">暂无订单</td></tr>'}
async function loadDispatchAccounts(){try{const u=await requireMember('d');const x=await api('/admin/users/'+u.id+'/payment-accounts?eligible=1');dispatchAccounts=x.accounts;$('dPaymentAccount').innerHTML=x.accounts.length?x.accounts.map(a=>`<option value="${a.id}">${a.remark}｜${a.account_type}｜${mask(a.account_value)}</option>`).join(''):'<option value="">没有可用的已审核账户</option>';setText('dAccountHint',x.accounts.length?`会员 ${u.username}：只显示已审核且允许接单的账户`:'该会员暂无可用收款账户')}catch(e){dispatchAccounts=[];$('dPaymentAccount').innerHTML='<option value="">请先匹配有效会员账号</option>';setText('dAccountHint',e.message)}}
function mask(v){v=String(v||'');return v.length>6?v.slice(0,2)+'••••'+v.slice(-4):v}
async function dispatchOrder(){try{const u=await requireMember('d');if(!$('dPaymentAccount').value)throw new Error('请选择该会员的收款账户');const x=await api('/admin/orders',{method:'POST',body:JSON.stringify({user_id:u.id,payment_account_id:Number($('dPaymentAccount').value),order_type:$('dType').value,amount_inr:Number($('dAmount').value),commission_rate:Number($('dRate').value),commission_inr:Number($('dCommission').value),extra_reward_usdt:Number($('dReward').value),series_current:null,series_total:null,note:$('dNote').value})});toast(x.message);await load()}catch(e){toast(e.message)}}
async function cancelOrder(id){if(!confirm('确认取消？'))return;try{const x=await api('/admin/orders/'+id+'/cancel',{method:'POST',body:'{}'});toast(x.message);await load()}catch(e){toast(e.message)}}async function completeOrder(id){if(!confirm('确认完成并结算佣金？'))return;try{const x=await api('/admin/orders/'+id+'/complete',{method:'POST',body:'{}'});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderAccounts(rows){$('accountRows').innerHTML=rows.length?rows.map(a=>`<tr><td>${a.username}</td><td>${a.remark}</td><td>${a.account_type}</td><td>${a.holder_name}</td><td>${a.bank_name||a.provider}</td><td>${a.account_value}</td><td>${a.receiving_enabled?'是':'否'}</td><td>${a.status}</td><td><button class="primary" onclick="reviewAccount(${a.id},'VERIFIED')">通过</button> <button class="danger" onclick="reviewAccount(${a.id},'REJECTED')">拒绝</button> <button class="secondary" onclick="toggleAccountReceiving(${a.id},${a.receiving_enabled?0:1})">${a.receiving_enabled?'停止接单':'允许接单'}</button></td></tr>`).join(''):'<tr><td colspan="9">暂无账户</td></tr>'}async function reviewAccount(id,status){try{const x=await api('/admin/payment-accounts/'+id+'/review',{method:'PUT',body:JSON.stringify({status,reject_reason:status==='REJECTED'?(prompt('拒绝原因','')||''):''})});toast(x.message);await load()}catch(e){toast(e.message)}}async function toggleAccountReceiving(id,enabled){try{const x=await api('/admin/payment-accounts/'+id+'/receiving',{method:'PUT',body:JSON.stringify({enabled:!!enabled})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderDeposits(rows){$('depositRows').innerHTML=rows.length?rows.map(d=>`<tr><td>${d.id}</td><td>${d.username}</td><td>${d.method}</td><td>${money(d.requested_amount)}</td><td>${money(d.actual_amount)}</td><td>${money(d.bonus_amount)}</td><td>${money(d.credited_amount)}</td><td>${d.status}</td><td>${d.status==='PENDING'?`<button class="primary" onclick="creditDeposit('${d.id}',${d.requested_amount})">审核上分</button> <button class="danger" onclick="rejectDeposit('${d.id}')">拒绝</button>`:''}</td></tr>`).join(''):'<tr><td colspan="9">暂无充值订单</td></tr>'}async function manualDeposit(){try{const u=await requireMember('manualDep'),amount=Number($('manualDepAmount').value);if(!(amount>0))throw new Error('请输入申请金额');const x=await api('/admin/deposits/manual',{method:'POST',body:JSON.stringify({user_id:u.id,method:$('manualDepMethod').value,requested_amount:amount,reference_no:$('manualDepRef').value})});toast(x.message);await load()}catch(e){toast(e.message)}}
async function creditDeposit(id,n){const actual=Number(prompt('实际到账',n));if(!(actual>0))return;try{const x=await api('/admin/deposits/'+id+'/credit',{method:'POST',body:JSON.stringify({actual_amount:actual,bonus_amount:Number(prompt('赠送','0')||0)})});toast(x.message);await load()}catch(e){toast(e.message)}}async function rejectDeposit(id){try{const x=await api('/admin/deposits/'+id+'/reject',{method:'POST',body:JSON.stringify({reason:prompt('原因','')||''})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderWithdrawals(rows){$('withdrawRows').innerHTML=rows.length?rows.map(w=>`<tr><td>${w.id}</td><td>${w.username}</td><td>${w.method}</td><td>${w.source_wallet==='COMMISSION'?'彩金钱包':'本金钱包'}</td><td>${money(w.amount)}</td><td>${money(w.fee)}</td><td>${money(w.receive_amount)}</td><td>${w.status}</td><td><select onchange="updateWithdrawal('${w.id}',this.value)"><option value="">操作</option><option>APPROVED</option><option>PROCESSING</option><option>COMPLETED</option><option>REJECTED</option></select></td></tr>`).join(''):'<tr><td colspan="9">暂无提款订单</td></tr>'}async function updateWithdrawal(id,status){if(!status)return;try{const x=await api('/admin/withdrawals/'+id+'/status',{method:'PUT',body:JSON.stringify({status,reason:status==='REJECTED'?(prompt('拒绝原因','')||''):''})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderReport(rows){$('reportRows').innerHTML=rows.length?rows.map(x=>`<tr><td>${x.report_date}</td><td>${x.orders_count}</td><td>${x.users_count}</td><td>${money(x.requested_total)}</td><td>${money(x.actual_total)}</td><td>${money(x.bonus_total)}</td><td>${money(x.credited_total)}</td></tr>`).join(''):'<tr><td colspan="7">暂无数据</td></tr>'}
function previewBannerFile(i,p){const f=i.files?.[0];if(!f)return;$(p).src=URL.createObjectURL(f);$(p).classList.remove('hidden')}async function uploadBannerFile(id){
 const file=$(id).files?.[0];
 if(!file)return'';
 const form=new FormData();
 form.append('image',file);
 const result=await AuthManager.upload('/admin/uploads/banner',form);
 if(!result.url)throw Error('上传成功但没有返回图片地址');
 return result.url;
}async function createBanner(){try{toast('正在上传图片...');const image_url=await uploadBannerFile('bImageFile');if(!image_url)throw Error('请选择电脑端图片');const mobile_image_url=await uploadBannerFile('bMobileImageFile');const chk=await fetch(image_url,{cache:'no-store'});if(!chk.ok)throw Error('图片上传后无法访问');const x=await api('/admin/banners',{method:'POST',body:JSON.stringify({position:'HOME',title_en:$('bTitleEn').value||'Luckypay',title_hi:$('bTitleHi').value||'लकिपे',subtitle_en:$('bSubtitleEn').value,subtitle_hi:$('bSubtitleHi').value,button_en:$('bButtonEn').value,button_hi:$('bButtonHi').value,target:$('bTarget').value,theme:$('bTheme').value,sort_order:Number($('bSort').value),enabled:$('bEnabled').value==='true',image_url,mobile_image_url})});toast(x.message);await load()}catch(e){toast(e.message)}}function renderBanners(rows){$('bannerCards').innerHTML=rows.length?rows.map(b=>`<div class="card row"><div class="row"><img class="bannerThumb" src="${b.image_url}"><div><b>${b.title_en}</b><div class="muted">排序${b.sort_order}</div><a href="${b.image_url}" target="_blank">打开图片检查</a></div></div><div><button class="secondary" onclick="toggleBanner(${b.id},${b.enabled?0:1})">${b.enabled?'停用':'启用'}</button> <button class="danger" onclick="deleteBanner(${b.id})">删除</button></div></div>`).join(''):'<div class="card">暂无轮播图</div>'}async function toggleBanner(id,en){try{const b=(await api('/admin/banners')).banners.find(x=>x.id===id);b.enabled=!!en;const x=await api('/admin/banners/'+id,{method:'PUT',body:JSON.stringify(b)});toast(x.message);await load()}catch(e){toast(e.message)}}async function deleteBanner(id){if(!confirm('确认删除轮播图？'))return;try{const x=await api('/admin/banners/'+id,{method:'DELETE'});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderCompany(c){$('cName').value=c.company_name||'';$('cProfileEn').value=c.profile_en||'';$('cProfileHi').value=c.profile_hi||'';$('cQualification').value=c.qualifications||'';$('cOffice').value=c.office_info||'';$('cPartners').value=c.partners||''}async function saveCompany(){try{const x=await api('/admin/company',{method:'PUT',body:JSON.stringify({company_name:$('cName').value,profile_en:$('cProfileEn').value,profile_hi:$('cProfileHi').value,qualifications:$('cQualification').value,office_info:$('cOffice').value,partners:$('cPartners').value})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderContacts(rows){$('contactCards').innerHTML=rows.map(c=>`<div class="card"><h3>${c.contact_type}</h3><div class="formgrid"><input id="ce${c.id}" value="${c.label_en}"><input id="ch${c.id}" value="${c.label_hi}"><input id="cu${c.id}" value="${c.url}"><input id="cs${c.id}" type="number" value="${c.sort_order}"></div><label><input id="cen${c.id}" type="checkbox" ${c.enabled?'checked':''} style="width:auto"> 启用</label><br><button class="primary" onclick="saveContact(${c.id})">保存</button></div>`).join('')}async function saveContact(id){try{const x=await api('/admin/contacts/'+id,{method:'PUT',body:JSON.stringify({label_en:$('ce'+id).value,label_hi:$('ch'+id).value,url:$('cu'+id).value,sort_order:Number($('cs'+id).value),enabled:$('cen'+id).checked})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderAnnouncements(rows){
 $('announcementCards').innerHTML=rows.length?rows.map(a=>`<div class="card">
  <div class="row"><div><b>${escapeHtml(a.title_zh||a.title_en||'公告')}</b><div class="muted">${escapeHtml(a.display_type)} · 自动弹出 ${a.auto_popup?'是':'否'} · 允许关闭 ${a.allow_close?'是':'否'}</div></div><span class="badge">${a.enabled?'启用':'停用'}</span></div>
  ${a.image_url?`<img class="bannerThumb" src="${escapeHtml(a.image_url)}">`:''}
  <p>${escapeHtml(a.content_zh||a.content_en||'')}</p>
  <div class="row"><button class="secondary" onclick="toggleAnnouncement(${a.id},${a.enabled?0:1})">${a.enabled?'停用':'启用'}</button><button class="danger" onclick="deleteAnnouncement(${a.id})">删除</button></div>
 </div>`).join(''):'<div class="card">暂无公告</div>'
}
async function createAnnouncement(){
 try{
  toast('正在保存公告...');
  const image_url=await uploadBannerFile('aImageFile');
  const x=await api('/admin/announcements',{method:'POST',body:JSON.stringify({
   title_zh:$('aTitleZh').value,title_en:$('aTitleEn').value,title_hi:$('aTitleHi').value,
   content_zh:$('aContentZh').value,content_en:$('aContentEn').value,content_hi:$('aContentHi').value,
   button_zh:$('aButtonZh').value||'查看更多',button_en:$('aButtonEn').value||'View More',button_hi:$('aButtonHi').value||'और देखें',
   target:$('aTarget').value,display_type:$('aType').value,sort_order:Number($('aSort').value||0),
   start_at:$('aStart').value||null,end_at:$('aEnd').value||null,enabled:$('aEnabled').value==='true',
   auto_popup:$('aAutoPopup').checked,allow_close:$('aAllowClose').checked,image_url
  })});
  toast(x.message);await load()
 }catch(e){toast(e.message)}
}
async function toggleAnnouncement(id,en){
 try{const a=(await api('/admin/announcements')).announcements.find(x=>x.id===id);a.enabled=!!en;const x=await api('/admin/announcements/'+id,{method:'PUT',body:JSON.stringify(a)});toast(x.message);await load()}catch(e){toast(e.message)}
}
async function deleteAnnouncement(id){if(!confirm('确认删除公告？'))return;try{const x=await api('/admin/announcements/'+id,{method:'DELETE'});toast(x.message);await load()}catch(e){toast(e.message)}}
async function sendMessage(){try{const u=await requireMember('m',true);const x=await api('/admin/messages',{method:'POST',body:JSON.stringify({user_id:u?u.id:null,category:$('mCategory').value,title_en:$('mTitleEn').value,title_hi:$('mTitleHi').value,body_en:$('mBodyEn').value,body_hi:$('mBodyHi').value})});toast(x.message)}catch(e){toast(e.message)}}
function renderLogs(rows){$('logRows').innerHTML=rows.length?rows.map(x=>`<tr><td>${x.created_at}</td><td>${x.admin_username||''}</td><td>${x.action}</td><td>${x.target_type} ${x.target_id}</td><td>${x.ip}</td><td>${x.detail}</td></tr>`).join(''):'<tr><td colspan="6">暂无日志</td></tr>'}

let luckyPaymentAccounts=[];
function snapshotLuckySteps(){
 const rows=[];
 document.querySelectorAll('#lsSteps .luckyStepCard').forEach((card,i)=>{
  rows.push({
   amount:$('lsa'+i)?.value||'',
   commission:$('lsc'+i)?.value||'',
   rate:$('lsr'+i)?.value||'',
   usdt:$('lsu'+i)?.value||'',
   payment:$('lsp'+i)?.value||''
  });
 });
 return rows;
}
function luckyAccountOptions(selected=''){
 const base='<option value="">不指定收款账户</option>';
 return base+luckyPaymentAccounts.map(a=>`<option value="${a.id}" ${String(a.id)===String(selected)?'selected':''}>${escapeHtml(a.remark||'未备注')}｜${escapeHtml(a.account_type||'')}｜${escapeHtml(mask(a.account_value||''))}</option>`).join('');
}
function buildLuckySteps(preserve=true){
 const box=$('lsSteps');if(!box)return;
 const previous=preserve?snapshotLuckySteps():[];
 const n=Math.max(1,Math.min(10,Number($('lsStepCount')?.value||1)));
 box.innerHTML=Array.from({length:n},(_,i)=>{
  const old=previous[i]||{};
  return `<div class="card luckyStepCard" data-step="${i+1}">
   <div class="row"><h4>第 ${i+1} 单</h4><span class="badge">STEP ${i+1}</span></div>
   <div class="formgrid three">
    <div><label>任务要求金额 INR</label><input id="lsa${i}" type="number" min="0.01" step="0.01" placeholder="例如 10000" value="${escapeHtml(old.amount||'')}"></div>
    <div><label>固定佣金 INR</label><input id="lsc${i}" type="number" min="0" step="0.01" placeholder="例如 500" value="${escapeHtml(old.commission||'')}"></div>
    <div><label>佣金比例 %</label><input id="lsr${i}" type="number" min="0" step="0.01" placeholder="例如 5" value="${escapeHtml(old.rate||'')}"></div>
    <div><label>USDT奖励</label><input id="lsu${i}" type="number" min="0" step="0.01" placeholder="例如 0" value="${escapeHtml(old.usdt||'')}"></div>
    <div><label>指定收款账户</label><select id="lsp${i}">${luckyAccountOptions(old.payment)}</select></div>
   </div>
  </div>`;
 }).join('');
}
async function loadLuckyPaymentAccounts(username){
 luckyPaymentAccounts=[];
 if(!username){buildLuckySteps(true);return}
 try{
  const x=await api('/admin/members/search?q='+encodeURIComponent(username));
  const exact=x.users.find(u=>u.username.toLowerCase()===username.toLowerCase());
  if(!exact){buildLuckySteps(true);return}
  const a=await api('/admin/users/'+exact.id+'/payment-accounts?eligible=1');
  luckyPaymentAccounts=a.accounts||[];
  buildLuckySteps(true);
 }catch(e){console.warn(e);buildLuckySteps(true)}
}
let luckyMemberTimer=null;
async function searchLuckyMember(){
 clearTimeout(luckyMemberTimer);
 const q=$('lsUsername').value.trim();
 setText('lsUserMatch',q?'正在查找...':'请输入完整会员账号');
 if(!q){$('lsUserSuggestions').innerHTML='';luckyPaymentAccounts=[];buildLuckySteps(true);return}
 luckyMemberTimer=setTimeout(async()=>{
  try{
   const x=await api('/admin/members/search?q='+encodeURIComponent(q));
   $('lsUserSuggestions').innerHTML=x.users.map(u=>`<option value="${escapeHtml(u.username)}">${escapeHtml(u.display_name||'-')}</option>`).join('');
   const exact=x.users.find(u=>u.username.toLowerCase()===q.toLowerCase());
   setText('lsUserMatch',exact?`已匹配：${exact.username} · ${exact.display_name||'-'} · ${exact.status}`:(x.users.length?`找到 ${x.users.length} 个相近账号`:'没有找到会员账号'));
   if(exact)await loadLuckyPaymentAccounts(exact.username);
   else{luckyPaymentAccounts=[];buildLuckySteps(true)}
  }catch(e){setText('lsUserMatch',e.message)}
 },250)
}
async function createLuckySeries(){
 try{
  const username=$('lsUsername').value.trim();
  if(!username)throw new Error('请输入完整会员账号');
  const n=Math.max(1,Math.min(10,Number($('lsStepCount').value||1)));
  const steps=Array.from({length:n},(_,i)=>{
   const amount=Number($('lsa'+i)?.value||0),fixed=Number($('lsc'+i)?.value||0),rate=Number($('lsr'+i)?.value||0);
   return {amount_inr:amount,commission_inr:fixed,commission_rate:rate,extra_reward_usdt:Number($('lsu'+i)?.value||0),payment_account_id:Number($('lsp'+i)?.value||0)||null}
  });
  steps.forEach((x,i)=>{
   if(!(x.amount_inr>0))throw new Error(`第 ${i+1} 单必须填写任务金额`);
   if(x.commission_inr<0||x.commission_rate<0||x.extra_reward_usdt<0)throw new Error(`第 ${i+1} 单金额不能为负数`);
   if(!(x.commission_inr>0)&&!(x.commission_rate>0))throw new Error(`第 ${i+1} 单必须填写固定佣金或佣金比例`);
  });
  const x=await api('/admin/lucky-series',{method:'POST',body:JSON.stringify({
   username,title:$('lsTitle').value.trim()||'Lucky Series',
   auto_popup:$('lsAutoPopup').checked,allow_close:$('lsAllowClose').checked,
   note:$('lsNote').value,steps
  })});
  toast(x.message);
  $('lsUsername').value='';$('lsTitle').value='Lucky Series';$('lsNote').value='';$('lsStepCount').value='3';
  luckyPaymentAccounts=[];setText('lsUserMatch','请输入完整会员账号');buildLuckySteps(false);await load()
 }catch(e){toast(e.message)}
}
async function createTestAccount(){try{if(!$('taLevel').value)throw new Error('请先在会员等级中启用至少一个等级');const x=await api('/admin/test-accounts',{method:'POST',body:JSON.stringify({username:$('taUsername').value.trim(),password:$('taPassword').value,display_name:$('taName').value.trim(),member_level_id:Number($('taLevel').value),balance_inr:Number($('taBalance').value||0),commission_wallet_inr:Number($('taCommissionWallet').value||0),reward_usdt:Number($('taUsdt').value||0),test_today_commission:Number($('taTodayCommission').value||0),test_today_income:Number($('taTodayIncome').value||0),test_bonus_completed:Number($('taBonusCompleted').value||0),bonus_amount:Number($('taBonusAmount').value||10000),bonus_commission:Number($('taBonusCommission').value||500),test_lucky_completed:Number($('taLuckyCompleted').value||0),lucky_total_steps:Number($('taLuckyTotal').value||3),lucky_step_amount:Number($('taLuckyAmount').value||10000),lucky_step_commission:Number($('taLuckyCommission').value||500)})});toast(x.message);await load()}catch(e){toast(e.message)}}
function renderTestAccounts(rows){$('testAccountCards').innerHTML=rows.length?rows.map(x=>`<div class="card"><div class="row"><div><b>${escapeHtml(x.username)}</b><div class="muted">${escapeHtml(x.display_name)} · ${escapeHtml(x.level_name||'-')} · TEST MODE</div></div><span class="badge">${x.status}</span></div><div class="stats"><div class="stat"><span>模拟本金</span><b>${money(x.balance_inr)}</b></div><div class="stat"><span>模拟彩金</span><b>${money(x.commission_wallet_inr)}</b></div><div class="stat"><span>今日佣金</span><b>${money(x.test_today_commission)}</b></div><div class="stat"><span>今日收益</span><b>${money(x.test_today_income)}</b></div></div><div class="muted">福利单完成 ${x.test_bonus_completed} · 幸运阶段完成 ${x.test_lucky_completed}</div><div class="row"><button class="secondary" onclick="editTestAccount(${x.id},${x.balance_inr},${x.commission_wallet_inr},${x.reward_usdt},${x.test_today_commission},${x.test_today_income},${x.test_bonus_completed},${x.test_lucky_completed},'${x.status}')">修改</button><button class="danger" onclick="deleteTestAccount(${x.id})">删除</button></div></div>`).join(''):'<div class="empty">暂无测试账号</div>'}
async function editTestAccount(id,b,c,u,tc,ti,bc,lc,status){const nb=Number(prompt('模拟本金',b));if(Number.isNaN(nb))return;const nc=Number(prompt('模拟彩金',c));if(Number.isNaN(nc))return;try{const x=await api('/admin/test-accounts/'+id,{method:'PUT',body:JSON.stringify({balance_inr:nb,commission_wallet_inr:nc,reward_usdt:u,test_today_commission:tc,test_today_income:ti,test_bonus_completed:bc,test_lucky_completed:lc,status})});toast(x.message);await load()}catch(e){toast(e.message)}}
async function deleteTestAccount(id){if(!confirm('确认删除测试账号？'))return;try{const x=await api('/admin/test-accounts/'+id,{method:'DELETE'});toast(x.message);await load()}catch(e){toast(e.message)}}
function luckyStatusLabel(series,current){
 if(series.status==='PENDING')return '等待会员参加';
 if(series.status==='PARTICIPATING'&&current?.status==='AVAILABLE')return '会员已参加，等待会员开始当前阶段';
 if(series.status==='PARTICIPATING'&&current?.status==='IN_PROGRESS')return '当前阶段进行中，可由后台完成结算';
 if(series.status==='COMPLETED')return '全部阶段已完成';
 if(series.status==='CANCELLED')return '已取消';
 return series.status||'未知状态';
}
function renderLuckySeries(rows){
 const container=$('luckySeriesCards');
 if(!Array.isArray(rows)||!rows.length){
  container.innerHTML='<div class="card">暂无幸运连单</div>';
  return;
 }
 container.innerHTML=rows.map(series=>{
  try{
   const steps=Array.isArray(series.steps)?series.steps:[];
   const completed=steps.filter(step=>step.status==='COMPLETED');
   const current=series.current_step_detail||steps.find(step=>Number(step.step_no)===Number(series.current_step))||null;
   const actions=series.actions?.admin||{};
   const canComplete=actions.can_complete===true;
   const canCancel=actions.can_cancel===true;
   const completeText=current?`完成第 ${current.step_no} 阶段并结算`:'完成当前阶段并结算';
   const completeReason=canComplete
    ?'当前阶段已经开始，可以完成结算'
    :series.status==='PENDING'
      ?'会员尚未参加'
      :current?.status==='AVAILABLE'
        ?'会员尚未开始当前阶段'
        :series.status==='COMPLETED'
          ?'所有阶段已经完成'
          :'当前阶段暂不能结算';

   return `<div class="card luckyAdminCard">
    <div class="row">
     <div>
      <b>${escapeHtml(series.title||'Lucky Series')}</b>
      <div class="muted">${escapeHtml(series.username||'-')} · ${escapeHtml(luckyStatusLabel(series,current))}</div>
     </div>
     <span class="badge">${completed.length}/${Number(series.total_steps||steps.length||0)}</span>
    </div>

    <div class="currentStageBox">
     <div class="row">
      <b>${current?`当前阶段：第 ${current.step_no} 阶段`:'当前阶段：-'}</b>
      <span class="badge">${escapeHtml(current?.status||series.status||'-')}</span>
     </div>
     ${current?`<div class="orderMeta">
      <span>金额 ${money(current.amount_inr)}</span>
      <span>佣金 ${money(current.commission_inr)}</span>
      <span>奖励 ${Number(current.extra_reward_usdt||0)} USDT</span>
      <span>冻结 ${money(current.locked_amount||0)}</span>
     </div>`:'<div class="muted">没有可执行阶段</div>'}
     <div class="muted">${escapeHtml(actions.hint||completeReason)}</div>
    </div>

    <div class="row luckyAdminActions">
     <button class="primary" ${canComplete?'':`disabled title="${escapeHtml(completeReason)}"`} onclick="completeLuckyStep('${escapeHtml(series.id)}')">${escapeHtml(completeText)}</button>
     <button class="danger" ${canCancel?'':`disabled title="该连单已结束"`} onclick="cancelLuckySeries('${escapeHtml(series.id)}')">取消并退回冻结本金</button>
    </div>

    ${completed.length?`<div class="settlementBox"><b>已结算阶段</b>${completed.map(step=>`<div class="item row">
     <span>✓ 第 ${step.step_no} 阶段 · ${money(step.amount_inr)}</span>
     <span>佣金 ${money(step.commission_inr)} · 奖励 ${Number(step.extra_reward_usdt||0)} USDT</span>
    </div>`).join('')}</div>`:''}

    <details>
     <summary>查看完整阶段计划</summary>
     ${steps.map(step=>`<div class="item row">
      <span>第 ${step.step_no} 阶段 · ${money(step.amount_inr)} · 佣金 ${money(step.commission_inr)}</span>
      <span class="badge">${escapeHtml(step.status)}</span>
     </div>`).join('')}
    </details>
   </div>`;
  }catch(error){
   console.error('Lucky administrator card render failed',error,series);
   return `<div class="card"><b>幸运连单数据异常</b><div class="muted">${escapeHtml(series?.id||'Unknown')}</div></div>`;
  }
 }).join('');
}
async function cancelLuckySeries(id){if(!confirm('确认取消该幸运连单？进行中阶段的冻结本金将退回。'))return;try{const x=await api('/admin/lucky-series/'+id+'/cancel',{method:'POST'});toast(x.message);await load()}catch(e){toast(e.message)}}
async function completeLuckyStep(id){
 if(!confirm('确认完成当前阶段并立即结算本金、佣金和奖励？'))return;
 try{
  const x=await api('/admin/lucky-series/'+id+'/complete-step',{method:'POST'});
  toast(x.message);
  await load();
 }catch(e){console.error('Complete Lucky stage failed',e);toast(e.message)}
}
async function loadAdmins(){try{const x=await api('/admin/admins');$('adRole').innerHTML=x.roles.map(r=>`<option value="${r.role_key}">${r.name_zh}</option>`).join('');$('adminCards').innerHTML=x.admins.map(a=>`<div class="card row"><div><b>${escapeHtml(a.username)}</b><div class="muted">${escapeHtml(a.display_name)} · ${a.admin_role} · Google验证 ${a.totp_enabled?'已开启':'未开启'}</div></div><span class="badge">${a.status}</span></div>`).join('')}catch(e){$('adminCards').innerHTML='<div class="card">仅超级管理员可查看</div>'}}
async function createAdminAccount(){try{const x=await api('/admin/admins',{method:'POST',body:JSON.stringify({username:$('adUsername').value,display_name:$('adName').value,admin_role:$('adRole').value,password:$('adPassword').value,secondary_password:$('adSecondary').value,totp_required:$('adTotpRequired').checked,reauth_secondary_password:$('reauthSecondary').value,totp_code:$('reauthTotp').value})});toast(x.message);await loadAdmins()}catch(e){toast(e.message)}}
async function resetAdminSecondary(){try{const id=Number($('resetAdminId').value),pwd=$('resetAdminSecondary').value;if(!id)throw new Error('请输入管理员ID');const x=await api('/admin/admins/'+id+'/reset-secondary',{method:'POST',body:JSON.stringify({new_secondary_password:pwd,reauth_secondary_password:$('resetReauthSecondary').value,totp_code:$('resetReauthTotp').value})});toast(x.message)}catch(e){toast(e.message)}}
async function setupTotp(){try{const x=await api('/admin/security/totp/setup',{method:'POST'});$('totpSetupBox').classList.remove('hidden');$('totpQr').src=x.qr;$('totpSecret').textContent=x.secret}catch(e){toast(e.message)}}
async function confirmTotp(){try{const x=await api('/admin/security/totp/confirm',{method:'POST',body:JSON.stringify({code:$('totpConfirmCode').value})});toast(x.message)}catch(e){toast(e.message)}}
async function changeSecondary(){try{const x=await api('/admin/security/change-secondary',{method:'POST',body:JSON.stringify({old_secondary_password:$('oldSecondary').value,new_secondary_password:$('newSecondary').value})});toast(x.message)}catch(e){toast(e.message)}}

function specialistRow(x={},index=0){return `<div class="specialistRow" data-specialist-index="${index}"><input data-field="name" placeholder="专员名称" value="${escapeHtml(x.name||'')}"><input data-field="username" placeholder="Telegram 用户名" value="${escapeHtml(x.username||'')}"><input data-field="url" placeholder="https://t.me/username" value="${escapeHtml(x.url||'')}"><input data-field="sort_order" type="number" placeholder="排序" value="${Number(x.sort_order||index+1)}"><label><input data-field="enabled" type="checkbox" ${x.enabled===false?'':'checked'} style="width:auto"> 启用</label><button class="danger" type="button" onclick="removeTelegramSpecialist(${index})">删除</button></div>`}
function renderTelegramSpecialists(){telegramSpecialists=telegramSpecialists.map((x,i)=>({...x,sort_order:Number(x.sort_order||i+1)}));$('telegramSpecialistRows').innerHTML=telegramSpecialists.map(specialistRow).join('')||'<div class="empty">尚未配置专员</div>'}
function syncTelegramSpecialistsFromDom(){telegramSpecialists=[...document.querySelectorAll('.specialistRow')].map((row,index)=>{const get=f=>row.querySelector(`[data-field="${f}"]`);return{id:telegramSpecialists[index]?.id||`tg-${Date.now()}-${index}`,name:get('name').value.trim(),username:get('username').value.trim(),url:get('url').value.trim(),sort_order:Number(get('sort_order').value||index+1),enabled:get('enabled').checked}})}
function addTelegramSpecialist(){syncTelegramSpecialistsFromDom();telegramSpecialists.push({id:`tg-${Date.now()}`,name:'',username:'',url:'',sort_order:telegramSpecialists.length+1,enabled:true});renderTelegramSpecialists()}
function removeTelegramSpecialist(index){syncTelegramSpecialistsFromDom();telegramSpecialists.splice(index,1);renderTelegramSpecialists()}
function applyConfiguredDepositMethods(x){const u=x?.usdt||{},o=$('manualDepUsdtOption');if(o){o.value='USDT_'+String(u.network||'TRC20').toUpperCase();o.textContent='USDT '+String(u.network||'TRC20').toUpperCase();o.disabled=!u.enabled}}
function renderWalletSettings(x){applyConfiguredDepositMethods(x);const u=x.usdt||{},i=x.inr||{};$('walletUsdtEnabled').checked=!!u.enabled;$('walletUsdtNetwork').value=u.network||'TRC20';$('walletUsdtAddress').value=u.address||'';$('walletUsdtMin').value=Number(u.min_amount||0);$('walletUsdtInstructions').value=u.instructions||'';$('walletUsdtShowCopy').checked=u.show_copy!==false;const qr=$('walletUsdtQrPreview');qr.classList.toggle('hidden',!u.qr_image_url);$('walletUsdtQrEmpty').classList.toggle('hidden',!!u.qr_image_url);if(u.qr_image_url)qr.src=u.qr_image_url;qr.dataset.url=u.qr_image_url||'';$('walletInrEnabled').checked=!!i.enabled;$('walletInrMin').value=Number(i.min_amount||0);$('walletInrHours').value=i.service_hours||'';$('walletInrButton').value=i.button_text||'';$('walletInrInstructions').value=i.instructions||'';telegramSpecialists=Array.isArray(i.specialists)?i.specialists:[];renderTelegramSpecialists()}
async function saveWalletSettings(){try{syncTelegramSpecialistsFromDom();let qr=$('walletUsdtQrPreview').dataset.url||'';const file=$('walletUsdtQrFile').files?.[0];if(file){
 const form=new FormData();
 form.append('image',file);
 const upload=await AuthManager.upload('/admin/uploads/banner',form);
 if(!upload.url)throw Error('二维码上传成功但没有返回地址');
 qr=upload.url;
}$('walletUsdtQrPreview').dataset.url=qr;const payload={usdt:{enabled:$('walletUsdtEnabled').checked,network:$('walletUsdtNetwork').value,address:$('walletUsdtAddress').value,qr_image_url:qr,min_amount:Number($('walletUsdtMin').value||0),instructions:$('walletUsdtInstructions').value,show_copy:$('walletUsdtShowCopy').checked},inr:{enabled:$('walletInrEnabled').checked,min_amount:Number($('walletInrMin').value||0),service_hours:$('walletInrHours').value,button_text:$('walletInrButton').value,instructions:$('walletInrInstructions').value,specialists:telegramSpecialists}};const x=await SettingsClient.saveWallet(payload);RefreshManager.clearDirty('walletSettings');toast(x.message);await refreshModule('walletSettings',true)}catch(e){toast(e.message)}}


const adminModules={
 dashboard:async()=>{const d=await api('/admin/dashboard');setText('sUsers',d.total_users);setText('sTodayUsers',d.today_users);setText('sTodayOrders',d.today_orders);setText('sTodayDepositCount',d.today_deposit_count);setText('sTodayDeposit',money(d.today_deposit_amount));setText('sTodayDepositUsers',d.today_deposit_users);setText('sTodayWithdrawalAmount',money(d.today_withdrawal_amount));setText('sPendingDeposit',d.pending_deposits);setText('sPendingWithdrawal',d.pending_withdrawals);setText('sReceiving',d.receiving_users);setText('sOrders',d.total_orders)},
 users:async()=>{const x=await api('/admin/users');users=x.users;renderUsers()},levels:async()=>{const x=await api('/admin/levels');levels=x.levels;options();renderLevels()},orders:async()=>renderOrders((await api('/admin/orders')).orders),accounts:async()=>renderAccounts((await api('/admin/payment-accounts')).accounts),deposits:async()=>{const [d,s]=await Promise.all([api('/admin/deposits'),SettingsClient.getWallet()]);applyConfiguredDepositMethods(s);renderDeposits(d.deposits)},withdrawals:async()=>renderWithdrawals((await api('/admin/withdrawals')).withdrawals),report:async()=>renderReport((await api('/admin/reports/deposits-daily')).rows),banners:async()=>renderBanners((await api('/admin/banners')).banners),company:async()=>renderCompany(await api('/company')),contacts:async()=>renderContacts((await api('/admin/contacts')).contacts),announcements:async()=>renderAnnouncements((await api('/admin/announcements')).announcements),logs:async()=>renderLogs((await api('/admin/audit-logs')).logs),settings:async()=>renderSettings(await api('/admin/settings')),walletSettings:async()=>renderWalletSettings(await SettingsClient.getWallet(true)),luckySeries:async()=>renderLuckySeries((await api('/admin/lucky-series')).series),testAccounts:async()=>renderTestAccounts((await api('/admin/test-accounts')).accounts),admins:async()=>loadAdmins(),dispatch:async()=>{const [ux,lx]=await Promise.all([api('/admin/users'),api('/admin/levels')]);users=ux.users;levels=lx.levels;options()},messages:async()=>{const x=await api('/admin/users');users=x.users;options()},security:async()=>true};
Object.entries(adminModules).forEach(([name,loader])=>RefreshManager.register(name,loader));
async function refreshModule(name,force=false){try{return await RefreshManager.refresh(name,{force})}catch(e){if(e.code==='AUTH_EXPIRED'){AuthManager.expire();RefreshManager.stop();showAdminLogin('登录状态已过期，请重新登录')}return false}}
async function load(force=false){const page=RefreshManager.activePage||'dashboard';const ok=await refreshModule(page,force);setText('adminLiveStatus',ok?'● 已更新 '+new Date().toLocaleTimeString():'● 等待重连或正在编辑');$('adminLiveStatus').classList.toggle('isWarning',!ok);if(page==='luckySeries'&&!$('lsSteps').children.length)buildLuckySteps(false)}
function showAdminApp(){
 $('login').classList.add('hidden');
 $('app').classList.remove('hidden');
 const page=pageFromLocation();
 openPage(page,{updateUrl:location.hash!=='#'+page,refresh:false});
 RefreshManager.start(()=>load(false),3000);
 load(true)
}
function showAdminLogin(message=''){$('app').classList.add('hidden');$('login').classList.remove('hidden');if(message)toast(message)}
async function manualAdminRefresh(){const page=RefreshManager.activePage||pageFromLocation();setText('adminLiveStatus','● 正在刷新');await refreshModule(page,true);setText('adminLiveStatus','● 已更新 '+new Date().toLocaleTimeString())}
async function restoreAdminSession(){setText('adminLiveStatus','● 正在恢复登录');if(await AuthManager.restore())showAdminApp();else showAdminLogin()}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&AuthManager.isAuthenticated())load(false)});window.addEventListener('focus',()=>{if(AuthManager.isAuthenticated())load(false)});
window.addEventListener('hashchange',()=>{const page=pageFromLocation();if(page!==RefreshManager.activePage)openPage(page,{updateUrl:false,refresh:true})});
window.addEventListener('popstate',()=>{const page=pageFromLocation();if(page!==RefreshManager.activePage)openPage(page,{updateUrl:false,refresh:true})});
document.addEventListener('input',e=>{if(e.target.closest('.page'))RefreshManager.markDirty(e.target.closest('.page').id)});document.addEventListener('change',e=>{if(e.target.closest('.page'))RefreshManager.markDirty(e.target.closest('.page').id)});
Object.assign(window,{cancelLuckySeries,resetAdminSecondary,searchMemberField,createTestAccount,editTestAccount,deleteTestAccount,verifyAdminTotp,buildLuckySteps,searchLuckyMember,createLuckySeries,completeLuckyStep,createAdminAccount,setupTotp,confirmTotp,changeSecondary,login,logout,openPage,editUser,adjustUser,directCredit,saveLevel,loadDispatchAccounts,dispatchOrder,cancelOrder,completeOrder,reviewAccount,toggleAccountReceiving,manualDeposit,creditDeposit,rejectDeposit,updateWithdrawal,previewBannerFile,createBanner,toggleBanner,deleteBanner,saveCompany,saveContact,createAnnouncement,toggleAnnouncement,deleteAnnouncement,sendMessage,manualAdminRefresh,saveWalletSettings,addTelegramSpecialist,removeTelegramSpecialist});
let adminBootStarted=false;
async function bootAdmin(){if(adminBootStarted)return;adminBootStarted=true;await restoreAdminSession()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bootAdmin,{once:true});else bootAdmin();

['settingShowName','settingShowPhone','settingShowEmail','settingShowReferral'].forEach(id=>document.getElementById(id)?.addEventListener('change',syncRegistrationSettingLocks));

document.getElementById('lsStepCount')?.addEventListener('change',()=>buildLuckySteps(true));
document.getElementById('lsStepCount')?.addEventListener('input',()=>buildLuckySteps(true));

document.addEventListener('DOMContentLoaded',()=>{buildLuckySteps(false)});
window.addEventListener('pageshow',()=>{if($('lsSteps')&&!document.querySelector('#lsSteps .luckyStepCard'))buildLuckySteps(false)});
