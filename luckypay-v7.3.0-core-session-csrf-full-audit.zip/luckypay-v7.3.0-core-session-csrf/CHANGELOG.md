# Changelog

## 7.3.0

- Rebuilt the administrator authentication client around one verified Session path.
- Administrator login now verifies `/api/me` before displaying the backend.
- F5 restoration uses the same verified Session path.
- Added rolling server Sessions, explicit cookie path, SameSite Lax, and proxy awareness.
- Unified JSON and FormData requests under AuthManager.
- Banner and wallet-QR uploads now receive automatic CSRF refresh-and-retry.
- Removed direct upload fetch calls that bypassed the shared CSRF client.
- Disabled stale administrator and API caching after deployments.
- Added release-blocking Session, F5, and CSRF upload regression tests.

## 7.2.1

- Only Lucky Series may open an automatic member popup.
