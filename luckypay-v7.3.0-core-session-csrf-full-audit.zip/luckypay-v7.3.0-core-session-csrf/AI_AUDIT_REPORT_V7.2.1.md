# V7.2.1 Lucky-Only Popup Audit

## Required behavior

Only the Lucky Series invitation may automatically open a frontend popup.

## Removed

- announcement popup creation
- ordinary-order popup creation
- welfare-order popup creation
- shared `opsModal`
- shared `opsPopupQueue`
- shared `activeOpsPopup`
- shared popup action and close handlers
- shared operation-popup CSS

## Retained

- announcement data and marquee display
- ordinary/welfare orders and actions in the Orders page
- dedicated Lucky modal
- Lucky automatic invitation
- Lucky join without balance validation
- current-stage balance validation and principal locking
- administrator stage settlement
- cancellation and principal refund
- carousel, member details, wallet, and other frontend sections

## Automated verification

The release gate verifies that announcement and order renderers cannot create popups, the shared popup system is absent, and the Lucky automatic popup path remains present.

All source-level release gates passed. Final browser confirmation is required after server deployment.
