# Baseline Change Policy

## Before any code modification

```bash
cd backend-api
npm run baseline:compare
```

The command must show no unapproved differences.

Create a filesystem backup before editing:

```bash
cd /root
tar -czf luckypay-before-change-$(date +%Y%m%d-%H%M%S).tar.gz luckypay-current
```

## During a change

- Do not edit protected frontend HTML/CSS unless explicit approval exists.
- Limit changes to the approved file list.
- Do not modify locked business rules as part of refactoring.
- Update API/database contracts when an explicitly approved feature changes.

## Before packaging

```bash
cd backend-api
npm run release:gate
npm test
```

Both commands must pass.

## Approved changes

Copy `baseline/APPROVED_CHANGES.example.json` to `baseline/APPROVED_CHANGES.json` and list only explicitly approved files.

Frontend changes additionally require `baseline/FRONTEND_CHANGE_APPROVAL.json`.

## Updating the baseline

Only after the product owner approves the completed behavior:

```bash
cd backend-api
npm run baseline:create
```

Commit the new snapshot with a new baseline version.
