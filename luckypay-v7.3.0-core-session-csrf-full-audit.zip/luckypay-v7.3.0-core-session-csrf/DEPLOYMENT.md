# Luckypay V7.3.0 Deployment

Preserve the V7.2.1 `.env`, especially `SESSION_SECRET`:

```bash
cd /root
unzip -o luckypay-v7.3.0-core-session-csrf-full-audit.zip
cp /root/luckypay-v7.2.1/.env /root/luckypay-v7.3.0-core-session-csrf/.env
```

For an upgrade, also preserve data and uploads:

```bash
cp -a /root/luckypay-v7.2.1/data /root/luckypay-v7.3.0-core-session-csrf/
cp -a /root/luckypay-v7.2.1/uploads /root/luckypay-v7.3.0-core-session-csrf/
```

Start:

```bash
cd /root/luckypay-v7.3.0-core-session-csrf
docker compose up -d --build
sleep 25
docker compose ps
curl http://127.0.0.1:3800/api/health
```

Expected version: `7.3.0`.

Then run:

```bash
docker compose exec api npm run release:gate
docker compose exec api npm test
```

Clear the old site cookies once, log in again, navigate to a non-dashboard page, press F5, upload a banner, and upload a wallet QR.
