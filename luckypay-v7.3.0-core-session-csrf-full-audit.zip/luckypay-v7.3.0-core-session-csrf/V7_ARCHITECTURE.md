# Luckypay V7 Architecture

## Objective

V7 reorganizes state synchronization without changing the approved business rules or visible interface.

## Member state flow

```text
SQLite database
   ↓
member-state-service
   ↓
GET /api/state
   ↓
memberStateStore
   ↓
Home / Orders / Wallet / Bonus / Profile
```

The member frontend no longer requires fourteen independent requests to complete successfully before anything renders.

## Unified state response

`GET /api/state` returns:

- dashboard and member information
- ordinary orders
- Lucky Series and all stage details
- wallet ledger
- deposits and withdrawals
- payment accounts
- company profile and contacts
- messages
- banners and announcements
- public settings
- wallet/recharge settings
- state version and generated time
- optional-section error list

The dashboard/member section is critical. Optional sections are isolated so one unavailable optional query cannot erase the whole member page.

## Lucky Series

Lucky enrichment is centralized in:

```text
backend-api/src/services/lucky-series-service.js
```

Both the member endpoint, administrator endpoint, and unified state endpoint use the same stage interpretation.

The locked rules remain:

- Create as PENDING
- Auto-popup controlled by administrator
- Join without balance validation
- Start current stage with balance validation and principal lock
- Settle through wallet-service
- Unlock only the next stage
- Display Stage 1 values in the invitation

## Compatibility

The original endpoints remain available:

- `/api/dashboard`
- `/api/orders`
- `/api/lucky-series`
- `/api/wallet/ledger`
- `/api/deposits`
- `/api/withdrawals`
- `/api/payment-accounts`
- `/api/banners`
- `/api/settings`
- `/api/wallet-settings`

V7 adds `/api/state`; it does not remove the existing API contracts.

## Frontend protection

The following files are byte-for-byte unchanged:

- frontend-user/index.html
- frontend-user/assets/app.css
- frontend-admin/index.html
- frontend-admin/assets/app.css

The existing visual design, layout, buttons, modal markup, and administrator interface remain intact.

## Mandatory verification

```bash
cd backend-api
npm run baseline:compare
npm run release:gate
npm test
```

`npm test` includes real temporary-SQLite HTTP flows for ordinary orders and Lucky Series.
