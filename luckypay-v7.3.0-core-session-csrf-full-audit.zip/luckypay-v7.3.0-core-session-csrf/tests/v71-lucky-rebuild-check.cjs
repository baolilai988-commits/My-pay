"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');

const route=fs.readFileSync(path.join(root,'backend-api/src/routes/lucky-series.js'),'utf8');
const service=fs.readFileSync(path.join(root,'backend-api/src/services/lucky-series-service.js'),'utf8');
const member=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const admin=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');
const state=fs.readFileSync(path.join(root,'backend-api/src/services/member-state-service.js'),'utf8');
const financial=fs.readFileSync(path.join(root,'backend-api/tests/financial-flow.js'),'utf8');

const failures=[];

for(const token of [
 'function actionState(series,current)',
 'can_complete:inProgress',
 "complete_reason:inProgress?'READY'",
 'can_join:pending',
 'can_start:available',
 'waiting_for_admin:inProgress',
 'function getMemberSeries',
 'function getAdminSeries'
])if(!service.includes(token))failures.push(`Lucky state interpreter missing: ${token}`);

for(const token of [
 "r.get('/lucky-series/:id'",
 "r.get('/admin/lucky-series/:id'",
 "r.post('/lucky-series/:id/join'",
 "r.post('/lucky-series/:id/start-current'",
 "r.post('/admin/lucky-series/:id/complete-step'",
 "r.post('/admin/lucky-series/:id/cancel'",
 'function settleCurrentStep',
 'NEXT_STAGE_UNLOCK_FAILED',
 "status='COMPLETED',locked_amount=0",
 "status='CANCELLED',locked_amount=0",
 'const user=requireMember(series.user_id)'
])if(!route.includes(token))failures.push(`Lucky backend rebuild missing: ${token}`);

const joinStart=route.indexOf("r.post('/lucky-series/:id/join'");
const startStart=route.indexOf("r.post('/lucky-series/:id/start-current'");
const adminStart=route.indexOf("r.get('/admin/lucky-series'",startStart);
const joinBlock=route.slice(joinStart,startStart);
const startBlock=route.slice(startStart,adminStart);

if(joinBlock.includes('wallet.lockPrincipal'))failures.push('Lucky join still locks principal');
if(!startBlock.includes('lockCurrentStep(user,series,step)'))failures.push('Lucky start does not lock current-stage principal');

for(const token of [
 'function luckyStatusLabel',
 'function renderLuckySeries(rows)',
 '完成第 ${current.step_no} 阶段并结算',
 "disabled title=\"${escapeHtml(completeReason)}\"",
 "onclick=\"completeLuckyStep",
 '确认完成当前阶段并立即结算本金、佣金和奖励'
])if(!admin.includes(token))failures.push(`Administrator Lucky controls missing: ${token}`);

for(const token of [
 'function luckySeriesCard',
 'function queueLuckyPopup',
 "async function joinLuckyFromModal()",
 'Join Lucky Series',
 'function safeRenderSection',
 "safeRenderSection('banners'",
 "safeRenderSection('Lucky Series'",
 'A Lucky data/rendering failure must never hide or clear the carousel'
])if(!member.includes(token))failures.push(`Member Lucky isolation missing: ${token}`);

if(!state.includes("schema_version:'7.1'"))failures.push('Member state schema is not V7.1');

for(const token of [
 "member.request('/api/state')",
 "assert.equal(x.body.schema_version,'7.1')",
 "admin.request(`/api/admin/lucky-series/${seriesId}/complete-step`",
 'assert.equal(refreshed.current_step_detail.status'
])if(!financial.includes(token))failures.push(`Financial flow coverage missing: ${token}`);

if(failures.length)throw Error(failures.join('\n'));
console.log('V7.1 Lucky Series rebuild checks passed');
