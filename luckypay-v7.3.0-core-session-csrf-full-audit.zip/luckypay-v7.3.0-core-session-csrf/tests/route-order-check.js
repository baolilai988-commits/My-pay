"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const app=fs.readFileSync(path.join(root,'backend-api/src/app.js'),'utf8');
const health=app.indexOf("app.get('/health',healthHandler)");
const apiHealth=app.indexOf("app.get('/api/health',healthHandler)");
if(health<0||apiHealth<0)throw Error('Missing public health endpoints');
for(const marker of [
 "app.use('/api',csrfProtection)",
 "app.use('/api',require('./routes/user'))",
 "app.use('/api',require('./routes/lucky-series'))",
 "app.use('/api/admin',require('./routes/admin'))"
]){
 const pos=app.indexOf(marker);
 if(pos<0)throw Error(`Missing middleware: ${marker}`);
 if(health>pos||apiHealth>pos)throw Error(`Health endpoint appears after protected middleware: ${marker}`);
}
if((app.match(/app\.get\('\/health'/g)||[]).length!==1)throw Error('Expected one /health endpoint');
if((app.match(/app\.get\('\/api\/health'/g)||[]).length!==1)throw Error('Expected one /api/health endpoint');
const nginx=fs.readFileSync(path.join(root,'nginx/default.conf'),'utf8');
if(!nginx.includes('location = /health'))throw Error('Nginx /health location missing');
if(!nginx.includes('proxy_pass http://api:3000/health'))throw Error('Nginx health proxy target incorrect');
const compose=fs.readFileSync(path.join(root,'docker-compose.yml'),'utf8');
if(!compose.includes("j.version==='7.3.0'"))throw Error('API healthcheck does not verify V7.3.0');
if(!compose.includes('http://127.0.0.1/health'))throw Error('Web healthcheck does not verify Nginx health path');
console.log('Health endpoints, middleware order, Nginx proxy and Compose checks passed');
