"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const db=fs.readFileSync(path.join(root,'backend-api/src/lib/db.js'),'utf8');
const sessions=fs.readFileSync(path.join(root,'backend-api/src/lib/session-store.js'),'utf8');
const state=fs.readFileSync(path.join(root,'backend-api/src/services/member-state-service.js'),'utf8');
const lucky=fs.readFileSync(path.join(root,'backend-api/src/services/lucky-series-service.js'),'utf8');
const schema=db+'\n'+sessions;

const required={
 users:['id','balance_inr','order_locked_inr','commission_wallet_inr','reward_usdt','is_test_account'],
 orders:['user_id','status','commission_inr','created_at'],
 lucky_series:['id','user_id','status','current_step','total_steps','joined_at','completed_at','created_at'],
 lucky_series_steps:['series_id','step_no','status','amount_inr','commission_inr','extra_reward_usdt'],
 wallet_ledger:['id','user_id'],
 http_sessions:['sid','updated_at'],
 system_settings:['updated_at'],
 messages:['id','user_id'],
 banners:['enabled','start_at','end_at','sort_order'],
 announcements:['enabled','start_at','end_at','sort_order']
};
const failures=[];
for(const [table,fields] of Object.entries(required)){
 const start=schema.indexOf(`CREATE TABLE IF NOT EXISTS ${table}`);
 if(start<0){failures.push(`State dependency table missing: ${table}`);continue}
 const next=schema.indexOf('CREATE TABLE IF NOT EXISTS ',start+10);
 const block=schema.slice(start,next<0?schema.length:next);
 for(const field of fields){
  const inCreate=new RegExp(`\\b${field}\\b`).test(block);
  const inMigration=db.includes(`column('${table}','${field}'`);
  if(!inCreate&&!inMigration)failures.push(`State dependency field missing: ${table}.${field}`);
 }
}
if(state.includes('accepted_at,created_at'))failures.push('State fingerprint references invalid lucky_series.accepted_at');
if(!state.includes('completed_at,joined_at,created_at'))failures.push('State fingerprint does not use lucky_series joined_at');
if(!lucky.includes('SELECT * FROM lucky_series_steps WHERE series_id=? ORDER BY step_no'))failures.push('Lucky step query missing');

if(failures.length)throw Error(failures.join('\n'));
console.log('V7 state-service database contracts passed');
