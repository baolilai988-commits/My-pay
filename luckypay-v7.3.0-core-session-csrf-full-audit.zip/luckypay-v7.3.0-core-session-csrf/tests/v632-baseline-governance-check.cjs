"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const required=[
 'baseline/BUSINESS_RULES_LOCKED.md',
 'baseline/FRONTEND_FEATURE_CATALOG.json',
 'baseline/API_DATABASE_CONTRACT.json',
 'baseline/PROTECTED_FRONTEND_HASHES.json',
 'baseline/BASELINE_SNAPSHOT.json',
 'baseline/RELEASE_GATES.md',
 'scripts/baseline/create-snapshot.cjs',
 'scripts/baseline/compare-snapshot.cjs',
 'scripts/baseline/verify-protected-frontend.cjs',
 'scripts/baseline/verify-feature-contracts.cjs',
 'scripts/baseline/release-gate.cjs',
 'backend-api/tests/financial-flow.js'
];
for(const rel of required)if(!fs.existsSync(path.join(root,rel)))throw Error(`Baseline governance file missing: ${rel}`);

const rules=fs.readFileSync(path.join(root,'baseline/BUSINESS_RULES_LOCKED.md'),'utf8');
for(const token of [
 'Joining does not check or freeze principal',
 'Starting the current stage checks and freezes',
 'Every wallet change goes through `wallet-service`',
 'Existing HTML, CSS, wording, buttons, and interaction require explicit approval'
])if(!rules.includes(token))throw Error(`Locked business rule missing: ${token}`);

const catalog=JSON.parse(fs.readFileSync(path.join(root,'baseline/FRONTEND_FEATURE_CATALOG.json'),'utf8'));
if(!catalog.locked)throw Error('Frontend catalog is not locked');
if(!catalog.member.mandatory_dom.includes('opsModal'))throw Error('Lucky modal is not mandatory');
if(!catalog.member.mandatory_runtime.includes('renderBanners'))throw Error('Carousel renderer is not mandatory');

const contract=JSON.parse(fs.readFileSync(path.join(root,'baseline/API_DATABASE_CONTRACT.json'),'utf8'));
if(contract.contracts.length<10)throw Error('Critical API contract coverage is incomplete');
if(!contract.database.wallet_ledger)throw Error('Wallet ledger database contract missing');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'backend-api/package.json'),'utf8'));
if(!String(pkg.scripts.test||'').includes('test:financial'))throw Error('Real financial-flow test is not part of npm test');

console.log('V7 baseline governance checks passed');
