"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const js=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');

const match=js.match(/Object\.assign\(window,\{([^}]*)\}\);/s);
if(!match)throw Error('Global export block missing');

const exportedNames=match[1].split(',').map(x=>x.trim()).filter(Boolean);
const declared=new Set([
 ...[...js.matchAll(/\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g)].map(x=>x[1]),
 ...[...js.matchAll(/\basync\s+function\s+([A-Za-z_$][\w$]*)\s*\(/g)].map(x=>x[1]),
 ...[...js.matchAll(/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/g)].map(x=>x[1])
]);

const missing=exportedNames.filter(x=>!declared.has(x));
if(missing.length)throw Error(`Undefined global exports: ${missing.join(', ')}`);
if(exportedNames.includes('saveSettings'))throw Error('Legacy saveSettings export remains');
console.log(`Global export integrity passed: ${exportedNames.length} exports, no undefined references`);
