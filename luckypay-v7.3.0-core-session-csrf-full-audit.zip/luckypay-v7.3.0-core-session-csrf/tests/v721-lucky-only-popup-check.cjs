"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'frontend-user/index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'frontend-user/assets/app.css'),'utf8');
const js=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const failures=[];

for(const token of ['id="luckyModal"','id="luckyJoinButton"','function showLuckyModal(series)','async function joinLuckyFromModal()'])
 if(!html.includes(token)&&!js.includes(token))failures.push(`Lucky-only popup requirement missing: ${token}`);

for(const token of ['id="opsModal"','opsPopupQueue=[]','activeOpsPopup=null','function enqueueOpsPopup','function showNextOpsPopup','function runOpsPopupAction'])
 if(html.includes(token)||js.includes(token))failures.push(`Removed shared popup feature remains: ${token}`);

if(css.includes('.opsModal')||css.includes('.opsDialog'))failures.push('Shared popup CSS remains');
if(!css.includes('.luckyModal')||!css.includes('.luckyDialog'))failures.push('Lucky modal CSS missing');

const announcementStart=js.indexOf('function renderAnnouncements(rows)');
const announcementEnd=js.indexOf('function processOrderPopups',announcementStart);
const announcementBlock=js.slice(announcementStart,announcementEnd);
if(announcementBlock.includes('showLuckyModal')||announcementBlock.includes('enqueueOpsPopup'))
 failures.push('Announcement renderer still creates a popup');

const orderStart=js.indexOf('function processOrderPopups(rows)');
const orderEnd=js.indexOf('function luckyMemberStatus',orderStart);
const orderBlock=js.slice(orderStart,orderEnd);
if(orderBlock.includes('showLuckyModal')||orderBlock.includes('enqueueOpsPopup'))
 failures.push('Ordinary/welfare order processing still creates a popup');

if(!announcementBlock.includes('announcementMarquee')||!announcementBlock.includes('marqueeTrack'))
 failures.push('Announcement marquee was removed together with popup');

if(!js.includes("safeRenderSection('Lucky Series'")||!js.includes('showLuckyModal(series)'))
 failures.push('Lucky automatic popup path missing');

if(failures.length)throw Error(failures.join('\n'));
console.log('V7.2.1 Lucky-only popup checks passed');
