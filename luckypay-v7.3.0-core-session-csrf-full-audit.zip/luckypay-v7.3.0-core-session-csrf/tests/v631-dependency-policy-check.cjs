"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'backend-api/package.json'),'utf8'));
for(const [name,version] of Object.entries(pkg.dependencies||{})){
 if(/^[~^><=*]/.test(version)&&!(/^\d+\.\d+\.\d+/.test(version)))throw Error(`Dependency is not exactly pinned: ${name}@${version}`);
 if(!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version))throw Error(`Dependency version is not exact semver: ${name}@${version}`);
}
const docker=fs.readFileSync(path.join(root,'backend-api/Dockerfile'),'utf8');
if(!docker.includes('package-lock.json'))throw Error('Dockerfile does not prefer package-lock.json');
console.log(`Dependency policy passed: ${Object.keys(pkg.dependencies).length} direct dependencies are exactly pinned`);
