"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'frontend-user/index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'frontend-user/assets/app.css'),'utf8');
const js=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const failures=[];
for(const token of ['id="luckyModal"','id="luckyJoinButton"','id="luckyCloseButton"'])
 if(!html.includes(token))failures.push(`DOM missing: ${token}`);
for(const token of ['.luckyModal','.luckyDialog','.luckyStats'])
 if(!css.includes(token))failures.push(`CSS missing: ${token}`);
for(const token of [
 'activeLuckyModal=null','luckyModalDismissed=new Set()',
 'function showLuckyModal(series)','function closeLuckyModal()',
 'async function joinLuckyFromModal()','showLuckyModal(series)',
 "$('luckyModal').classList.remove('hidden')"
])if(!js.includes(token))failures.push(`Runtime missing: ${token}`);
const queueStart=js.indexOf('function queueLuckyPopup(series)');
const queueEnd=js.indexOf('function renderLuckySeries',queueStart);
const queue=js.slice(queueStart,queueEnd);
if(queue.includes('enqueueOpsPopup'))failures.push('Lucky invitation still uses shared ops queue');
if(!queue.includes('showLuckyModal(series)'))failures.push('Lucky invitation does not use dedicated modal');
if(js.includes("sessionStorage.getItem('ops_popup_seen_'+series"))failures.push('Lucky popup still suppressed by shared sessionStorage key');
if(failures.length)throw Error(failures.join('\n'));
console.log('V7.2 dedicated Lucky modal conflict checks passed');
