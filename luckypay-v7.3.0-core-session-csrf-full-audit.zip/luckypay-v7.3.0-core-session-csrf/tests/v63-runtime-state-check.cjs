"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const js=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');

for(const name of ['activeLuckyModal','luckyModalDismissed','previousLuckyState','previousOrderState','walletSettings']){
 const declaration=new RegExp(`\\b(?:let|const|var)\\b[^;\\n]*\\b${name}\\b`);
 if(!declaration.test(js))throw Error(`Member runtime state is undeclared: ${name}`);
}
for(const removed of ['opsPopupQueue','activeOpsPopup']){
 const declaration=new RegExp(`\\b(?:let|const|var)\\b[^;\\n]*\\b${removed}\\b`);
 if(declaration.test(js))throw Error(`Removed shared popup state remains declared: ${removed}`);
}
if(/ReferenceError/.test(js))throw Error('Raw ReferenceError text should not be presented to members');
console.log('Member Lucky-only runtime-state declaration check passed');
