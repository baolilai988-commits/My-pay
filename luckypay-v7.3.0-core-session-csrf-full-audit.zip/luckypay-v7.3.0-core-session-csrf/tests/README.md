# V2 checks

Run:

```bash
find backend-api/src -name "*.js" -print0 | xargs -0 -n1 node --check
node --check frontend-user/assets/app.js
node --check frontend-admin/assets/app.js
node tests/static-check.js
```
