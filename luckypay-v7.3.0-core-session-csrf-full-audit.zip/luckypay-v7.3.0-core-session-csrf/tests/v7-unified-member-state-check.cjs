"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');

const userRoute=fs.readFileSync(path.join(root,'backend-api/src/routes/user.js'),'utf8');
const stateService=fs.readFileSync(path.join(root,'backend-api/src/services/member-state-service.js'),'utf8');
const luckyService=fs.readFileSync(path.join(root,'backend-api/src/services/lucky-series-service.js'),'utf8');
const luckyRoute=fs.readFileSync(path.join(root,'backend-api/src/routes/lucky-series.js'),'utf8');
const memberJs=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const financial=fs.readFileSync(path.join(root,'backend-api/tests/financial-flow.js'),'utf8');

const failures=[];
for(const token of [
 "r.get('/state'",
 "buildMemberState(req.session.user.id)"
])if(!userRoute.includes(token))failures.push(`Unified state route missing: ${token}`);

for(const token of [
 "schema_version:'7.1'",
 'state_version:stateFingerprint(userId)',
 'dashboard:critical',
 "orders:safeSection('orders'",
 "lucky:safeSection('lucky'",
 "wallet_settings:safeSection('wallet_settings'",
 'errors',
 'complete=errors.length===0'
])if(!stateService.includes(token))failures.push(`Unified state service feature missing: ${token}`);

for(const token of [
 'function enrichSeries',
 'function listMemberSeries',
 'function listAdminSeries'
])if(!luckyService.includes(token))failures.push(`Shared Lucky service missing: ${token}`);

if(/function enrich\(/.test(luckyRoute))failures.push('Lucky enrichment remains duplicated inside the route');
for(const token of ['listMemberSeries(req.session.user.id)','listAdminSeries()'])
 if(!luckyRoute.includes(token))failures.push(`Lucky route does not use shared service: ${token}`);

for(const token of [
 'memberStateStore={',
 'function applyMemberState(state)',
 "const state=await api('/state')",
 "!['7.0','7.1'].includes(state.schema_version)",
 'renderLuckySeries(series)',
 'renderBanners(state.banners?.banners||[])'
])if(!memberJs.includes(token))failures.push(`Member frontend unified-state integration missing: ${token}`);

if(memberJs.includes("Promise.all([api('/dashboard')"))
 failures.push('Legacy 14-request all-or-nothing refresh remains active');

for(const token of [
 "member.request('/api/state')",
 "assert.equal(x.body.schema_version,'7.1')",
 'x.body.lucky.series.find',
 'refreshed.current_step_detail'
])if(!financial.includes(token))failures.push(`Real financial test lacks unified-state coverage: ${token}`);

if(failures.length)throw Error(failures.join('\n'));
console.log('V7 unified member-state architecture checks passed');
