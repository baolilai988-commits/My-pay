"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const admin=fs.readFileSync(path.join(root,'backend-api/src/routes/admin.js'),'utf8');
const db=fs.readFileSync(path.join(root,'backend-api/src/lib/db.js'),'utf8');
const front=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');
const integration=fs.readFileSync(path.join(root,'backend-api/tests/integration.js'),'utf8');

for(const route of [
 "r.get('/test-accounts'",
 "r.post('/test-accounts'",
 "r.put('/test-accounts/:id'",
 "r.delete('/test-accounts/:id'"
])if(!admin.includes(route))throw Error(`Missing test-account route: ${route}`);

for(const call of [
 "api('/admin/test-accounts'",
 "api('/admin/test-accounts/'+id"
])if(!front.includes(call))throw Error(`Frontend test-account call missing: ${call}`);

if(!db.includes('CREATE TABLE IF NOT EXISTS schema_migrations'))throw Error('schema_migrations table missing');
if(!db.includes("runMigration(1,'v6_baseline_schema'"))throw Error('baseline migration missing');
if(!db.includes("runMigration(2,'announcement_content_sanitization'"))throw Error('sanitization migration missing');
if(db.includes("['announcements',['title_en','title_hi','body_en','body_hi']]"))throw Error('obsolete announcement fields remain');
if(!integration.includes("const VERSION='7.3.0'"))throw Error('integration test version is stale');
if(!integration.includes('/api/admin/test-accounts'))throw Error('integration test does not cover test-account API');
if(!integration.includes('schema_migrations'))throw Error('integration test does not verify migrations');
console.log('V7.3.0 frontend-backend-database interoperability structure checks passed');
