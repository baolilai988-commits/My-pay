"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const required=[
 'frontend-admin/assets/auth-manager.js',
 'frontend-admin/assets/refresh-manager.js',
 'frontend-admin/assets/settings-client.js',
 'frontend-user/index.html',
 'frontend-user/assets/app.js',
 'frontend-user/assets/app.css',
 'backend-api/src/services/wallet-service.js',
 'backend-api/src/services/settings-service.js',
 'backend-api/src/routes/lucky-series.js',
 'tests/v63-lucky-popup-mandatory-check.cjs',
 'tests/v63-runtime-state-check.cjs',
 'tests/v63-order-balance-check.cjs'
];
for(const rel of required)if(!fs.existsSync(path.join(root,rel)))throw Error(`Required release component missing: ${rel}`);

const admin=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');
for(const token of ['pageFromLocation','manualAdminRefresh','RefreshManager','AuthManager'])
 if(!admin.includes(token))throw Error(`Administrator regression feature missing: ${token}`);

const member=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const memberRequirements=[
 {label:'wallet settings source',ok:member.includes("api('/wallet-settings')")||member.includes("api('/state')")},
 {label:'banner renderer',ok:member.includes('renderBanners')},
 {label:'dashboard renderer',ok:member.includes('renderDashboard')},
 {label:'Lucky renderer',ok:member.includes('renderLuckySeries')}
];
for(const requirement of memberRequirements)if(!requirement.ok)throw Error(`Member regression feature missing: ${requirement.label}`);

console.log('V6.3 release gate passed: required architecture and user-facing features are present');
