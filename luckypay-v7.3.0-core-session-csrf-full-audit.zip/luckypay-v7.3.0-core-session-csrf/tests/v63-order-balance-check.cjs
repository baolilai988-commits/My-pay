"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const user=fs.readFileSync(path.join(root,'backend-api/src/routes/user.js'),'utf8');
const lucky=fs.readFileSync(path.join(root,'backend-api/src/routes/lucky-series.js'),'utf8');

for(const token of ['订单需要','当前可用','还需补充'])
 if(!user.includes(token))throw Error(`Detailed normal-order balance message missing: ${token}`);

if(!lucky.includes('当前阶段余额不足'))
 throw Error('Detailed Lucky-stage balance message missing');

const joinStart=lucky.indexOf("r.post('/lucky-series/:id/join'");
const startCurrent=lucky.indexOf("r.post('/lucky-series/:id/start-current'");
if(joinStart<0||startCurrent<0)throw Error('Lucky routes missing');

const joinBlock=lucky.slice(joinStart,startCurrent);
const startBlock=lucky.slice(startCurrent,lucky.indexOf("r.get('/admin/lucky-series'",startCurrent));

if(joinBlock.includes('lockCurrentStep(')||joinBlock.includes('wallet.lockPrincipal'))
 throw Error('Joining Lucky Series must not check or lock principal');

if(!startBlock.includes('lockCurrentStep(user,series,step)'))
 throw Error('Starting the current Lucky stage must call freezeStep');

const freezeStart=lucky.indexOf('function lockCurrentStep');
const freezeEnd=lucky.indexOf("r.get('/lucky-series'",freezeStart);
const freezeBlock=lucky.slice(freezeStart,freezeEnd);
if(!freezeBlock.includes('wallet.lockPrincipal'))
 throw Error('lockCurrentStep must check and lock principal through wallet-service');

console.log('Normal-order and Lucky-stage balance behavior checks passed');
