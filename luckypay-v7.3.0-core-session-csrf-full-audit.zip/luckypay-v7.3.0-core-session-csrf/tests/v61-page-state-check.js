"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const admin=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');
const user=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');

for(const token of ['function pageFromLocation()','location.hash','history.pushState','hashchange','popstate'])
 if(!admin.includes(token))throw Error(`Missing route-state feature: ${token}`);
if(!admin.includes("openPage(page,{updateUrl:location.hash!=='#'+page,refresh:false})"))
 throw Error('Admin application does not restore the current hash page before refresh');
if(!admin.includes("const page=RefreshManager.activePage||pageFromLocation()"))
 throw Error('Manual refresh is not locked to the current page');
if(!user.includes('walletSettings={usdt:{},inr:{specialists:[]}}'))
 throw Error('Member walletSettings runtime state is not declared');
console.log('V6.1 page routing, current-page refresh and member runtime-state checks passed');
