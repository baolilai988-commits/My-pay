"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const auth=fs.readFileSync(path.join(root,'frontend-admin/assets/auth-manager.js'),'utf8');
const admin=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');
const app=fs.readFileSync(path.join(root,'backend-api/src/app.js'),'utf8');
const nginx=fs.readFileSync(path.join(root,'nginx/default.conf'),'utf8');
const failures=[];

for(const token of [
 "credentials:'same-origin'",
 "cache:'no-store'",
 'async function verifySession()',
 "await request('/me')",
 'await verifySession()',
 'async function upload(url,formData)',
 "return request(url,{method:'POST',body:formData})",
 "if(response.status===403&&payload.error==='CSRF validation failed'&&!retried)"
])if(!auth.includes(token))failures.push(`AuthManager requirement missing: ${token}`);

if(auth.includes("headers={'Content-Type':'application/json'"))
 failures.push('AuthManager still forces JSON Content-Type on FormData');

for(const token of [
 "AuthManager.upload('/admin/uploads/banner',form)",
 'let adminBootStarted=false',
 'async function bootAdmin()',
 "document.addEventListener('DOMContentLoaded',bootAdmin,{once:true})"
])if(!admin.includes(token))failures.push(`Administrator runtime requirement missing: ${token}`);

if(admin.includes("fetch('/api/admin/uploads/banner'"))
 failures.push('Banner upload still bypasses AuthManager');

for(const token of [
 'rolling:true',
 "unset:'destroy'",
 'proxy:config.trustProxy>0',
 "sameSite:'lax'",
 "path:'/'"
])if(!app.includes(token))failures.push(`Session configuration missing: ${token}`);

for(const token of [
 'Cache-Control "no-store, no-cache, must-revalidate, max-age=0"',
 'proxy_no_cache 1',
 'proxy_cache_bypass 1',
 'add_header Cache-Control "no-store"'
])if(!nginx.includes(token))failures.push(`Nginx cache protection missing: ${token}`);

if(failures.length)throw Error(failures.join('\n'));
console.log('V7.3.0 core Session, F5 restore, and CSRF upload checks passed');
