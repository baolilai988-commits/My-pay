"use strict";
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
for(const f of ['frontend-user/assets/app.js','frontend-admin/assets/app.js']){
 const s=fs.readFileSync(path.join(root,f),'utf8'),funcs=[...s.matchAll(/function\s+([A-Za-z0-9_]+)\s*\(/g)].map(x=>x[1]),dup=[...new Set(funcs.filter((x,i)=>funcs.indexOf(x)!==i))];
 if(dup.length)throw Error(`${f}: duplicate functions ${dup.join(', ')}`);
 console.log(`${f}: ${funcs.length} named functions, no duplicates`);
}
