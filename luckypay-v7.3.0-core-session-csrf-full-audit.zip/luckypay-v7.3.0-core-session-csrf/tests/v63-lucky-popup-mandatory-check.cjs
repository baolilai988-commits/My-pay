"use strict";
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'frontend-user/index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'frontend-user/assets/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'frontend-user/assets/app.css'),'utf8');
const route=fs.readFileSync(path.join(root,'backend-api/src/routes/lucky-series.js'),'utf8');
const luckyService=fs.existsSync(path.join(root,'backend-api/src/services/lucky-series-service.js'))?fs.readFileSync(path.join(root,'backend-api/src/services/lucky-series-service.js'),'utf8'):'';
const luckyBackend=route+'\n'+luckyService;
const adminHtml=fs.readFileSync(path.join(root,'frontend-admin/index.html'),'utf8');
const adminJs=fs.readFileSync(path.join(root,'frontend-admin/assets/app.js'),'utf8');

const requiredDom=['id="luckyModal"','id="luckyJoinButton"','id="luckySecondaryButton"','id="luckySeriesList"'];
for(const token of requiredDom)if(!html.includes(token))throw Error(`Lucky popup DOM missing: ${token}`);

for(const token of ['.luckyModal','.luckyDialog','.luckyStats','.luckyAction'])
 if(!css.includes(token))throw Error(`Lucky popup CSS missing: ${token}`);

for(const token of [
 "previousLuckyState={}","previousOrderState={}",
 "function showLuckyModal(series)","async function joinLuckyFromModal()","async function joinLuckySeries","async function startLuckyStage",
 "const first=series.first_step_detail","Join Lucky Series"
])if(!js.includes(token))throw Error(`Lucky popup runtime feature missing: ${token}`);

for(const token of [
 "const wallet=require('../services/wallet-service')",
 "first_step_detail",
 "r.post('/lucky-series/:id/join'",
 "r.post('/lucky-series/:id/start-current'",
 "wallet.lockPrincipal"
])if(!luckyBackend.includes(token))throw Error(`Lucky backend feature missing: ${token}`);

for(const token of ['id="lsAutoPopup"','id="lsAllowClose"'])
 if(!adminHtml.includes(token))throw Error(`Lucky administrator control missing: ${token}`);

for(const token of ["auto_popup:$('lsAutoPopup').checked","allow_close:$('lsAllowClose').checked"])
 if(!adminJs.includes(token))throw Error(`Lucky administrator payload missing: ${token}`);

console.log('Mandatory Lucky popup DOM, CSS, runtime, API and administrator-control regression checks passed');
