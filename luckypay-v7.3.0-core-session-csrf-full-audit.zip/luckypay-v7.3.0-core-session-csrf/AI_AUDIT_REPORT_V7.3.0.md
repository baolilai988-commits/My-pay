# Luckypay V7.3.0 Core Session and CSRF Audit

## Root causes

Two administrator file-upload paths bypassed the common API client:

- homepage banner upload
- wallet USDT QR upload

They manually attached a cached CSRF token but did not share the normal 403 token-refresh-and-retry path. This explains why ordinary administrator actions could work while uploads returned `CSRF validation failed`.

Administrator login also displayed the backend immediately after the login response without reading the regenerated Session back through `/api/me`. This allowed a false logged-in screen when the Session cookie was not actually reusable; pressing F5 then returned to login.

Cached administrator JavaScript could keep an older authentication implementation after deployment.

## Repairs

- One AuthManager now handles JSON and FormData.
- Both banner and QR uploads use `AuthManager.upload`.
- FormData Content-Type is left to the browser.
- CSRF 403 automatically obtains a fresh token and retries once.
- Login and TOTP verification must pass `/api/me` before the application opens.
- F5 restoration uses the same Session verification.
- Server Sessions use rolling expiry, explicit `/` path, SameSite Lax, and proxy awareness.
- Nginx disables stale caching for administrator assets and API responses.
- Administrator bootstrap is guarded against duplicate initialization.

## Verification

Source syntax, Session configuration, upload paths, F5 restoration, Lucky-only popup behavior, Lucky lifecycle, API/database contracts, baseline comparison, and the mandatory release gate all passed.

Actual server/browser verification remains required after deployment.
